------------------------------------------------------------------------------------------
-- CalcStat file
-- Written by Giseldah
-- Version 2.3.1
-- ****************************** Start CalcStat ******************************

-- Floating point numbers bring errors into the calculation, both inside the Lotro-client and in this function collection. This is why a 100% match with the stats in Lotro is impossible.
-- Anyway, to compensate for some errors, we use a calculation deviation correction value. This makes for instance 24.49999999 round to 25, as it's assumed that 24.5 was intended as outcome of a formula.
DblCalcDev = 0.00000001;

function CalcStat(SName, SLvl, SParam)

	-- process parameters and parameter defaults

	if type(SName) ~= "string" then
		return "Missing stat name";
	end
	local SN = string.match(SName:upper(),"^%s*(-?%a+%d*%a+)%s*$"); -- allow nested digits in stat name and a starting -
	if SN == nil then
		SN = string.match(SName,"^%s*(-?%a+)%s*$"); -- to allow single character stat name
		if SN == nil then
			return "Illegal stat name";
		end
	end
	SN = string.upper(SN);

	local L = 1; -- default L
	if type(SLvl) == "number" then
		L = SLvl;
	elseif type(SLvl) ~= "nil" then
		return "Illegal level";
	end
	local Lm = L-DblCalcDev;
	local Lp = L+DblCalcDev;

	local N = 1; -- default N
	local C = ""; -- default C
	if type(SParam) == "number" then
		N = SParam;
	elseif type(SParam) == "string" then
		C = SParam;
	elseif type(SParam) ~= "nil" then
		return "Illegal N or C";
	end

	-- binary search tree (generated code)

	if SN < "MINSTRELCDBASEWILL" then
		if SN < "CREEPAUDACITYMELDMGP" then
			if SN < "BRWAGGPOSTUREPHYMIT" then
				if SN < "BEORNINGCDBASEWILL" then
					if SN < "AWARDILVLF" then
						if SN < "ARMQTYMP" then
							if SN < "ARMOURADJBYTYPE" then
								if SN < "ADJUMBARTRAITMIT" then
									if SN < "ACIDMITT" then
										if SN > "-VERSION" then
											if SN == "ACIDMIT" then
												return CalcStat("DmgTypeMit",L,N);
											else
												return 0;
											end
										elseif SN == "-VERSION" then
											return "2.3.1f";
										else
											return 0;
										end
									elseif SN > "ACIDMITT" then
										if SN < "ADJUMBARITEMMIT" then
											if SN == "ADJUMBARITEM" then
												if Lm <= 499 then
													return 1;
												else
													return 0.9;
												end
											else
												return 0;
											end
										elseif SN > "ADJUMBARITEMMIT" then
											if SN == "ADJUMBARTRAIT" then
												if Lm <= 140 then
													return 1;
												elseif Lm <= 150 then
													return 0.9;
												else
													return 1;
												end
											else
												return 0;
											end
										else
											if Lm <= 499 then
												return 1;
											elseif Lm <= 500 then
												return 0.78;
											else
												return 0.7;
											end
										end
									else
										return CalcStat("DmgTypeMitT",L,N);
									end
								elseif SN > "ADJUMBARTRAITMIT" then
									if SN < "ARMCATMP" then
										if SN < "AGILITYC" then
											if SN == "AGILITY" then
												return CalcStat("Main",L,N);
											else
												return 0;
											end
										elseif SN > "AGILITYC" then
											if SN == "AGILITYT" then
												return CalcStat("MainT",L,N);
											else
												return 0;
											end
										else
											return CalcStat("MainC",L,N);
										end
									elseif SN > "ARMCATMP" then
										if SN < "ARMOUR" then
											if SN == "ARMCATPROGB" then
												if Lm <= 0 then
													return 0;
												elseif Lm <= 1 then
													return CalcStat("ProgBArmourHeavy",N);
												elseif Lm <= 2 then
													return CalcStat("ProgBArmourMedium",N);
												else
													return CalcStat("ProgBArmourLight",N);
												end
											else
												return 0;
											end
										elseif SN > "ARMOUR" then
											if SN == "ARMOURADJ" then
												return CalcStat("ArmourAdjByType",ArmCodeIndex(C,2),L);
											else
												return 0;
											end
										else
											return RoundDblDown(StatLinInter("ArmourPntMP","ItemPntS","ArmourProgB","ArmourAdj",L,C,0));
										end
									else
										return CalcStat("PntMPArmour",L);
									end
								else
									if Lm <= 140 then
										return 1;
									elseif Lm <= 141 then
										return 0.78;
									else
										return 0.7;
									end
								end
							elseif SN > "ARMOURADJBYTYPE" then
								if SN < "ARMOURPENT" then
									if SN < "ARMOURC" then
										if SN < "ARMOURADJTYPEOTHER" then
											if SN == "ARMOURADJTYPECLOAK" then
												return CalcStat("AdjUmbarItemMit",L);
											else
												return 0;
											end
										elseif SN > "ARMOURADJTYPEOTHER" then
											if SN == "ARMOURADJTYPESHIELD" then
												return CalcStat("AdjUmbarItemMit",L);
											else
												return 0;
											end
										else
											return CalcStat("AdjUmbarItemMit",L);
										end
									elseif SN > "ARMOURC" then
										if SN < "ARMOURLOW" then
											if SN == "ARMOURCRAW" then
												return StatLinInter("PntMPArmourC","CreepPntS","ProgBArmourC","",L,N,99);
											else
												return 0;
											end
										elseif SN > "ARMOURLOW" then
											if SN == "ARMOURLOWPNTMP" then
												return CalcStat("ArmTypeMP",ArmCodeIndex(C,2))*CalcStat("ArmQtyLowMP",ArmCodeIndex(C,2))*CalcStat("ArmCatMP",ArmCodeIndex(C,1));
											else
												return 0;
											end
										else
											return RoundDblDown(StatLinInter("ArmourLowPntMP","ItemPntS","ArmourProgB","ArmourAdj",L,C,0));
										end
									else
										return StatLinInter("PntMPArmourC","CreepPntS","ProgBArmourC","",L,N,0);
									end
								elseif SN > "ARMOURPENT" then
									if SN < "ARMQTYCOMMMP" then
										if SN < "ARMOURPROGB" then
											if SN == "ARMOURPNTMP" then
												return CalcStat("ArmTypeMP",ArmCodeIndex(C,2))*CalcStat("ArmQtyMP",ArmCodeIndex(C,3),ArmCodeIndex(C,2))*CalcStat("ArmCatMP",ArmCodeIndex(C,1));
											else
												return 0;
											end
										elseif SN > "ARMOURPROGB" then
											if SN == "ARMOURT" then
												return StatLinInter("PntMPArmourT","TraitPntS","ProgBArmour","AdjUmbarTraitMit",L,N,0);
											else
												return 0;
											end
										else
											return CalcStat("ArmCatProgB",ArmCodeIndex(C,1),L);
										end
									elseif SN > "ARMQTYCOMMMP" then
										if SN < "ARMQTYINCOMPMP" then
											if SN == "ARMQTYEPICMP" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({1,1,1,1,1,1.002,1,1},L);
												end
											else
												return 0;
											end
										elseif SN > "ARMQTYINCOMPMP" then
											if SN == "ARMQTYLOWMP" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({0.3635,0.3635,0.3635,0.3635,0.3635,0.36215,0.3635,0.3635},L);
												end
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											else
												return DataTableValue({28/30,28/30,0.95,0.95,0.94,0.948,0.95,0.95},L);
											end
										end
									else
										if Lm <= 0 then
											return 0;
										else
											return DataTableValue({22/30,22/30,0.8,0.8,0.76,0.804,0.8,0.7},L);
										end
									end
								else
									return StatLinInter("PntMPArmourPenT","TraitPntS","ProgBArmour","",L,N,0);
								end
							else
								if 3 <= Lp and Lm <= 3 then
									return CalcStat("ArmourAdjTypeCloak",N);
								elseif 8 <= Lp and Lm <= 8 then
									return CalcStat("ArmourAdjTypeShield",N);
								else
									return CalcStat("ArmourAdjTypeOther",N);
								end
							end
						elseif SN > "ARMQTYMP" then
							if SN < "AWARDILVLCC" then
								if SN < "AWARDILVLAC" then
									if SN < "AUTOLVLTOILVL" then
										if SN < "ARMQTYUNCOMMP" then
											if SN == "ARMQTYRAREMP" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({26/30,26/30,0.9,0.9,0.88,0.9,0.9,0.8},L);
												end
											else
												return 0;
											end
										elseif SN > "ARMQTYUNCOMMP" then
											if SN == "ARMTYPEMP" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({9,9,20,30,15,25,12,32.726},L);
												end
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											else
												return DataTableValue({22/30,22/30,0.85,0.85,0.82,0.852,0.85,0.75},L);
											end
										end
									elseif SN > "AUTOLVLTOILVL" then
										if SN < "AWARDILVLAA" then
											if SN == "AWARDILVLA" then
												if Lm <= 75 then
													return L;
												elseif Lm <= 94 then
													return 5*L-304;
												elseif Lm <= 95 then
													return 173;
												elseif Lm <= 100 then
													return 5*L-304;
												elseif Lm <= 101 then
													return 197;
												elseif Lm <= 104 then
													return 4*L-206;
												elseif Lm <= 105 then
													return 218;
												elseif Lm <= 110 then
													return RoundDbl(LinFmod(1,295,303.8,106,110,L));
												elseif Lm <= 115 then
													return 304;
												elseif Lm <= 119 then
													return RoundDbl(LinFmod(1,345,357,116,119,L));
												elseif Lm <= 120 then
													return 359;
												elseif Lm <= 130 then
													return 395;
												elseif Lm <= 140 then
													return RoundDbl(LinFmod(1,445.4,455.4,131,140,L));
												elseif Lm <= 150 then
													return RoundDbl(LinFmod(1,479.4,491.4,141,150,L));
												else
													return CalcStat("AwardILvlA",150);
												end
											else
												return 0;
											end
										elseif SN > "AWARDILVLAA" then
											if SN == "AWARDILVLAB" then
												if 75 <= Lp and Lm <= 75 then
													return CalcStat("AwardILvlA",L)+1;
												else
													return CalcStat("AwardILvlA",L);
												end
											else
												return 0;
											end
										else
											if 75 <= Lp and Lm <= 75 then
												return CalcStat("AwardILvlA",L)+3;
											else
												return CalcStat("AwardILvlA",L);
											end
										end
									else
										return CalcStat("AwardILvlCC",L);
									end
								elseif SN > "AWARDILVLAC" then
									if SN < "AWARDILVLBOLD" then
										if SN < "AWARDILVLB" then
											if SN == "AWARDILVLAOLD" then
												return CalcStat("AwardILvlA",L);
											else
												return 0;
											end
										elseif SN > "AWARDILVLB" then
											if SN == "AWARDILVLBA" then
												return CalcStat("AwardILvlB",L);
											else
												return 0;
											end
										else
											if Lm <= 4 then
												return CalcStat("AwardILvlA",1);
											elseif Lm <= 50 then
												return CalcStat("AwardILvlA",L-4);
											elseif Lm <= 54 then
												return CalcStat("AwardILvlA",51);
											elseif Lm <= 75 then
												return CalcStat("AwardILvlA",L-4);
											elseif Lm <= 95 then
												return CalcStat("AwardILvlA",L)+4;
											else
												return CalcStat("AwardILvlA",L);
											end
										end
									elseif SN > "AWARDILVLBOLD" then
										if SN < "AWARDILVLCA" then
											if SN == "AWARDILVLC" then
												if Lm <= 75 then
													return CalcStat("AwardILvlB",L);
												else
													return CalcStat("AwardILvlA",L);
												end
											else
												return 0;
											end
										elseif SN > "AWARDILVLCA" then
											if SN == "AWARDILVLCB" then
												if 96 <= Lp and Lm <= 99 then
													return CalcStat("AwardILvlC",L)+4;
												elseif 100 <= Lp and Lm <= 100 then
													return CalcStat("AwardILvlC",L)+6;
												else
													return CalcStat("AwardILvlC",L);
												end
											else
												return 0;
											end
										else
											if 96 <= Lp and Lm <= 100 then
												return CalcStat("AwardILvlC",L)+4;
											else
												return CalcStat("AwardILvlC",L);
											end
										end
									else
										return CalcStat("AwardILvlB",L);
									end
								else
									if 75 <= Lp and Lm <= 75 then
										return CalcStat("AwardILvlA",L)+2;
									else
										return CalcStat("AwardILvlA",L);
									end
								end
							elseif SN > "AWARDILVLCC" then
								if SN < "AWARDILVLDF" then
									if SN < "AWARDILVLDB" then
										if SN < "AWARDILVLD" then
											if SN == "AWARDILVLCD" then
												if 101 <= Lp and Lm <= 105 then
													return CalcStat("AwardILvlC",L)+4;
												else
													return CalcStat("AwardILvlC",L);
												end
											else
												return 0;
											end
										elseif SN > "AWARDILVLD" then
											if SN == "AWARDILVLDA" then
												if 106 <= Lp and Lm <= 115 then
													return RoundDbl(LinFmod(1,300,336.5,106,115,L));
												else
													return CalcStat("AwardILvlD",L);
												end
											else
												return 0;
											end
										else
											if Lm <= 105 then
												return CalcStat("AwardILvlC",L);
											elseif Lm <= 115 then
												return 300;
											else
												return CalcStat("AwardILvlA",L);
											end
										end
									elseif SN > "AWARDILVLDB" then
										if SN < "AWARDILVLDD" then
											if SN == "AWARDILVLDC" then
												if 106 <= Lp and Lm <= 110 then
													return RoundDbl(LinFmod(1,300,320,106,115,L));
												elseif 111 <= Lp and Lm <= 115 then
													return CalcStat("AwardILvlDC",110);
												else
													return CalcStat("AwardILvlD",L);
												end
											else
												return 0;
											end
										elseif SN > "AWARDILVLDD" then
											if SN == "AWARDILVLDE" then
												if 106 <= Lp and Lm <= 115 then
													return RoundDbl(LinFmod(1,300.4,326.4,106,115,L));
												else
													return CalcStat("AwardILvlD",L);
												end
											else
												return 0;
											end
										else
											if 106 <= Lp and Lm <= 114 then
												return RoundDbl(LinFmod(1,300,327,106,115,L));
											elseif 115 <= Lp and Lm <= 115 then
												return CalcStat("AwardILvlD",115)+30;
											else
												return CalcStat("AwardILvlD",L);
											end
										end
									else
										if 106 <= Lp and Lm <= 115 then
											return RoundDbl(LinFmod(1,300,345,106,115,L));
										else
											return CalcStat("AwardILvlD",L);
										end
									end
								elseif SN > "AWARDILVLDF" then
									if SN < "AWARDILVLEB" then
										if SN < "AWARDILVLE" then
											if SN == "AWARDILVLDG" then
												if 106 <= Lp and Lm <= 114 then
													return RoundDbl(LinFmod(1,300,336,106,115,L));
												elseif 115 <= Lp and Lm <= 115 then
													return CalcStat("AwardILvlD",115)+40;
												else
													return CalcStat("AwardILvlD",L);
												end
											else
												return 0;
											end
										elseif SN > "AWARDILVLE" then
											if SN == "AWARDILVLEA" then
												if 116 <= Lp and Lm <= 119 then
													return RoundDbl(LinFmod(1,350,378,116,120,L));
												elseif 120 <= Lp and Lm <= 120 then
													return CalcStat("AwardILvlE",120)+26;
												else
													return CalcStat("AwardILvlE",L);
												end
											else
												return 0;
											end
										else
											if Lm <= 115 then
												return CalcStat("AwardILvlC",L);
											elseif Lm <= 120 then
												return 350;
											else
												return CalcStat("AwardILvlA",L);
											end
										end
									elseif SN > "AWARDILVLEB" then
										if SN < "AWARDILVLED" then
											if SN == "AWARDILVLEC" then
												if 116 <= Lp and Lm <= 120 then
													return RoundDbl(LinFmod(1,350,382,116,120,L));
												else
													return CalcStat("AwardILvlE",L);
												end
											else
												return 0;
											end
										elseif SN > "AWARDILVLED" then
											if SN == "AWARDILVLEE" then
												if 116 <= Lp and Lm <= 119 then
													return RoundDbl(LinFmod(1,350,366,116,120,L));
												elseif 120 <= Lp and Lm <= 120 then
													return CalcStat("AwardILvlE",120)+14;
												else
													return CalcStat("AwardILvlE",L);
												end
											else
												return 0;
											end
										else
											if 116 <= Lp and Lm <= 120 then
												return RoundDbl(LinFmod(1,350,370,116,120,L));
											else
												return CalcStat("AwardILvlE",L);
											end
										end
									else
										if 116 <= Lp and Lm <= 119 then
											return RoundDbl(LinFmod(1,350,390,116,120,L));
										elseif 120 <= Lp and Lm <= 120 then
											return CalcStat("AwardILvlE",120)+38;
										else
											return CalcStat("AwardILvlE",L);
										end
									end
								else
									if 106 <= Lp and Lm <= 110 then
										return CalcStat("AwardILvlDF",111);
									elseif 111 <= Lp and Lm <= 115 then
										return RoundDbl(LinFmod(1,299.5,320.5,106,115,L));
									else
										return CalcStat("AwardILvlD",L);
									end
								end
							else
								return CalcStat("AwardILvlC",L);
							end
						else
							if Lm <= 0 then
								return 0;
							elseif Lm <= 1 then
								return CalcStat("ArmQtyCommMP",N);
							elseif Lm <= 2 then
								return CalcStat("ArmQtyUncomMP",N);
							elseif Lm <= 3 then
								return CalcStat("ArmQtyRareMP",N);
							elseif Lm <= 4 then
								return CalcStat("ArmQtyIncompMP",N);
							else
								return CalcStat("ArmQtyEpicMP",N);
							end
						end
					elseif SN > "AWARDILVLF" then
						if SN < "BASEMORALE" then
							if SN < "AWARDILVLJB" then
								if SN < "AWARDILVLGD" then
									if SN < "AWARDILVLG" then
										if SN > "AWARDILVLFA" then
											if SN == "AWARDILVLFB" then
												if Lm <= 140 then
													return CalcStat("AwardILvlF",L);
												elseif Lm <= 150 then
													return RoundDbl(LinFmod(1,500.4,510.4,141,150,L));
												else
													return CalcStat("AwardILvlFB",150);
												end
											else
												return 0;
											end
										elseif SN == "AWARDILVLFA" then
											if Lm <= 140 then
												return CalcStat("AwardILvlF",L);
											else
												return 500;
											end
										else
											return 0;
										end
									elseif SN > "AWARDILVLG" then
										if SN < "AWARDILVLGB" then
											if SN == "AWARDILVLGA" then
												if 121 <= Lp and Lm <= 130 then
													return RoundDbl(LinFmod(1,400.4,412.4,121,130,L));
												else
													return CalcStat("AwardILvlG",L);
												end
											else
												return 0;
											end
										elseif SN > "AWARDILVLGB" then
											if SN == "AWARDILVLGC" then
												if 121 <= Lp and Lm <= 130 then
													return RoundDbl(LinFmod(1,400.4,408.3,121,130,L));
												else
													return CalcStat("AwardILvlG",L);
												end
											else
												return 0;
											end
										else
											if 121 <= Lp and Lm <= 130 then
												return RoundDbl(LinFmod(1,400.4,418.4,121,130,L));
											else
												return CalcStat("AwardILvlG",L);
											end
										end
									else
										if Lm <= 120 then
											return CalcStat("AwardILvlC",L);
										elseif Lm <= 130 then
											return 400;
										else
											return CalcStat("AwardILvlA",L);
										end
									end
								elseif SN > "AWARDILVLGD" then
									if SN < "AWARDILVLI" then
										if SN < "AWARDILVLGF" then
											if SN == "AWARDILVLGE" then
												if 121 <= Lp and Lm <= 130 then
													return RoundDbl(LinFmod(1,400.4,434.4,121,130,L));
												else
													return CalcStat("AwardILvlG",L);
												end
											else
												return 0;
											end
										elseif SN > "AWARDILVLGF" then
											if SN == "AWARDILVLH" then
												if Lm <= 4 then
													return CalcStat("AwardILvlA",1);
												elseif Lm <= 50 then
													return CalcStat("AwardILvlA",L-4);
												elseif Lm <= 54 then
													return CalcStat("AwardILvlA",51);
												elseif Lm <= 75 then
													return CalcStat("AwardILvlA",L-4);
												else
													return L-4;
												end
											else
												return 0;
											end
										else
											if 121 <= Lp and Lm <= 130 then
												return RoundDbl(LinFmod(1,400.4,440.4,121,130,L));
											else
												return CalcStat("AwardILvlG",L);
											end
										end
									elseif SN > "AWARDILVLI" then
										if SN < "AWARDILVLJ" then
											if SN == "AWARDILVLIA" then
												if Lm <= 44 then
													return CalcStat("AwardILvlI",L);
												elseif Lm <= 55 then
													return RoundDblDown((L-45)/6)+51;
												elseif Lm <= 90 then
													return CalcStat("AwardILvlI",L);
												elseif Lm <= 104 then
													return RoundDblDown((L-91)/5)*25+165;
												elseif Lm <= 105 then
													return CalcStat("LvlToILvl",L);
												elseif Lm <= 110 then
													return CalcStat("LvlToILvl",106)+15;
												elseif Lm <= 115 then
													return CalcStat("LvlToILvl",115)-20;
												elseif Lm <= 120 then
													return CalcStat("LvlToILvl",116)+15;
												elseif Lm <= 125 then
													return CalcStat("LvlToILvl",121)+15;
												elseif Lm <= 130 then
													return CalcStat("LvlToILvl",130)-20;
												elseif Lm <= 135 then
													return CalcStat("LvlToILvl",131)+15;
												elseif Lm <= 140 then
													return CalcStat("LvlToILvl",140)-4;
												elseif Lm <= 150 then
													return CalcStat("LvlToILvl",141)+15;
												else
													return CalcStat("AwardILvlIA",150);
												end
											else
												return 0;
											end
										elseif SN > "AWARDILVLJ" then
											if SN == "AWARDILVLJA" then
												if 131 <= Lp and Lm <= 140 then
													return RoundDbl(LinFmod(1,450.4,465.4,131,140,L));
												else
													return CalcStat("AwardILvlJ",L);
												end
											else
												return 0;
											end
										else
											if Lm <= 130 then
												return CalcStat("AwardILvlC",L);
											elseif Lm <= 140 then
												return RoundDbl(LinFmod(1,450.4,460.4,131,140,L));
											else
												return CalcStat("AwardILvlA",L);
											end
										end
									else
										if Lm <= 44 then
											return 1;
										elseif Lm <= 55 then
											return 52;
										elseif Lm <= 75 then
											return RoundDblDown((L-56)/5)*5+60;
										elseif Lm <= 85 then
											return RoundDblDown((L-76)/5)*29+100;
										elseif Lm <= 95 then
											return RoundDblDown((L-86)/5)*20+155;
										elseif Lm <= 100 then
											return RoundDblDown((L-96)/4)*10+190;
										elseif Lm <= 105 then
											return RoundDblDown((L-101)/4)*35+215;
										elseif Lm <= 110 then
											return CalcStat("LvlToILvl",106)+15;
										elseif Lm <= 115 then
											return CalcStat("LvlToILvl",115);
										elseif Lm <= 119 then
											return CalcStat("LvlToILvl",116)+15;
										elseif Lm <= 120 then
											return CalcStat("LvlToILvl",120);
										elseif Lm <= 125 then
											return CalcStat("LvlToILvl",121)+15;
										elseif Lm <= 130 then
											return CalcStat("LvlToILvl",130);
										elseif Lm <= 135 then
											return CalcStat("LvlToILvl",131)+15;
										elseif Lm <= 140 then
											return CalcStat("LvlToILvl",140);
										elseif Lm <= 145 then
											return CalcStat("LvlToILvl",141)+15;
										elseif Lm <= 150 then
											return CalcStat("LvlToILvl",150);
										else
											return CalcStat("AwardILvlI",150);
										end
									end
								else
									if 121 <= Lp and Lm <= 130 then
										return RoundDbl(LinFmod(1,400.4,426.4,121,130,L));
									else
										return CalcStat("AwardILvlG",L);
									end
								end
							elseif SN > "AWARDILVLJB" then
								if SN < "BALANCEOFMANEVADE" then
									if SN < "AWARDLVLTOILVL" then
										if SN < "AWARDILVLJD" then
											if SN == "AWARDILVLJC" then
												if 131 <= Lp and Lm <= 140 then
													return RoundDbl(LinFmod(1,450.4,475.4,131,140,L));
												else
													return CalcStat("AwardILvlJ",L);
												end
											else
												return 0;
											end
										elseif SN > "AWARDILVLJD" then
											if SN == "AWARDLVLCAP" then
												return 150;
											else
												return 0;
											end
										else
											if 131 <= Lp and Lm <= 140 then
												return RoundDbl(LinFmod(1,450.4,480.4,131,140,L));
											else
												return CalcStat("AwardILvlJ",L);
											end
										end
									elseif SN > "AWARDLVLTOILVL" then
										if SN < "AXEARMRENDPOS" then
											if SN == "AXEARMOURREND" then
												return -CalcStat("AxeArmRendPos",L);
											else
												return 0;
											end
										elseif SN > "AXEARMRENDPOS" then
											if SN == "BALANCEOFMANBLOCK" then
												return CalcStat("BlockT",L,0.8);
											else
												return 0;
											end
										else
											if Lm <= 7 then
												return RoundDbl(LinFmod(1,0.5,3.25,1,7,L));
											elseif Lm <= 14 then
												return RoundDbl(LinFmod(1,3.75,8.5,8,14,L));
											elseif Lm <= 30 then
												return RoundDbl(LinFmod(1,9,24.7,15,30,L));
											elseif Lm <= 39 then
												return RoundDbl(LinFmod(1,26.5,37,31,39,L));
											elseif Lm <= 50 then
												return RoundDbl(LinFmod(1,38.5,53,40,50,L));
											elseif Lm <= 52 then
												return 53;
											elseif Lm <= 60 then
												return RoundDbl(LinFmod(1,53.2,64.8,53,60,L));
											elseif Lm <= 77 then
												return RoundDbl(LinFmod(1,66.15,94.8,61,77,L));
											elseif Lm <= 113 then
												return RoundDbl(RoundDbl(L/3-0.5)*1.95+44.1);
											elseif Lm <= 141 then
												return 116;
											elseif Lm <= 181 then
												return RoundDbl(RoundDbl(L/4)*2+46);
											elseif Lm <= 217 then
												return RoundDbl(RoundDbl(L/4)*2+45);
											elseif Lm <= 221 then
												return 153;
											elseif Lm <= 299 then
												return 155;
											elseif Lm <= 308 then
												return RoundDbl(RoundDbl(L/2.6-0.4)*2-73);
											elseif Lm <= 317 then
												return RoundDbl(RoundDbl(L/2.74-0.75)*2-60);
											elseif Lm <= 325 then
												return 172;
											elseif Lm <= 326 then
												return 174;
											elseif Lm <= 599 then
												return ExpFmod(CalcStat("AxeArmRendPos",326),327,1,L,1);
											else
												return CalcStat("AxeArmRendPos",599);
											end
										end
									else
										return CalcStat("AwardILvlC",L);
									end
								elseif SN > "BALANCEOFMANEVADE" then
									if SN < "BASEFATE" then
										if SN < "BASEAGILITY" then
											if SN == "BALANCEOFMANPARRY" then
												return CalcStat("ParryT",L,0.8);
											else
												return 0;
											end
										elseif SN > "BASEAGILITY" then
											if SN == "BASEARMOUR" then
												if Lm <= 50 then
													return RoundDblUp(LinFmod(1,1,10,1,50,L)*N);
												elseif Lm <= 60 then
													return RoundDblUp(LinFmod(1,10,15,50,60,L)*N);
												elseif Lm <= 65 then
													return RoundDblUp(LinFmod(1,15,20,60,65,L)*N);
												elseif Lm <= 75 then
													return RoundDblUp(LinFmod(1,20,30,65,75,L)*N);
												elseif Lm <= 85 then
													return RoundDblUp(LinFmod(1,30,45,75,85,L)*N);
												elseif Lm <= 95 then
													return RoundDblUp(LinFmod(1,45,65,85,95,L)*N);
												elseif Lm <= 100 then
													return RoundDblUp(LinFmod(1,65,100,95,100,L)*N);
												elseif Lm <= 105 then
													return RoundDblUp(LinFmod(1,100,130,100,105,L)*N);
												elseif Lm <= 115 then
													return RoundDblUp(LinFmod(1,143,200,106,115,L,0)*N);
												elseif Lm <= 120 then
													return RoundDblUp(LinFmod(1,230,250,116,120,L,0)*N);
												elseif Lm <= 130 then
													return RoundDblUp(LinFmod(1,288,380,121,130,L,0)*N);
												elseif Lm <= 140 then
													return RoundDblUp(LinFmod(1,440,750,131,140,L,0)*N);
												else
													return CalcStat("BaseArmour",140,N);
												end
											else
												return 0;
											end
										else
											return CalcStat("BaseMain",L,N);
										end
									elseif SN > "BASEFATE" then
										if SN < "BASEMAINPROG" then
											if SN == "BASEMAIN" then
												if Lm <= 50 then
													return RoundDbl(CalcStat("BaseMainProg",L)*1*N);
												elseif Lm <= 95 then
													return RoundDbl(CalcStat("BaseMainProg",L)*1*N);
												else
													return RoundDbl(CalcStat("BaseMainProg",L)*1*N);
												end
											else
												return 0;
											end
										elseif SN > "BASEMAINPROG" then
											if SN == "BASEMIGHT" then
												return CalcStat("BaseMain",L,N);
											else
												return 0;
											end
										else
											if Lm <= 95 then
												return CalcStat("StdProg",L,1.0);
											elseif Lm <= 140 then
												return RoundDbl(CalcStat("StdProg",L,1.0));
											else
												return RoundDbl(LinFmod(1,780,1360,141,150,L));
											end
										end
									else
										if Lm <= 50 then
											return RoundDbl(CalcStat("ProgBEnergy",L)*3.5);
										elseif Lm <= 95 then
											return RoundDbl(CalcStat("ProgBEnergy",L)*3.5);
										else
											return RoundDbl(CalcStat("BasePower",L)*0.7);
										end
									end
								else
									return CalcStat("EvadeT",L,1.0);
								end
							else
								if 131 <= Lp and Lm <= 140 then
									return RoundDbl(LinFmod(1,450.4,470.4,131,140,L));
								else
									return CalcStat("AwardILvlJ",L);
								end
							end
						elseif SN > "BASEMORALE" then
							if SN < "BEORNINGCDAGILITYTOOUTHEAL" then
								if SN < "BEOEMISSARYFATE" then
									if SN < "BATTLELOREMAS" then
										if SN < "BASEVITALITY" then
											if SN == "BASEPOWER" then
												if Lm <= 50 then
													return RoundDblDown(CalcStat("ProgBEnergy",L)*5);
												elseif Lm <= 95 then
													return RoundDblDown(CalcStat("ProgBEnergy",L)*5);
												else
													return RoundDbl(CalcStat("ProgBEnergy",L)*5);
												end
											else
												return 0;
											end
										elseif SN > "BASEVITALITY" then
											if SN == "BASEWILL" then
												return CalcStat("BaseMain",L,N);
											else
												return 0;
											end
										else
											if Lm <= 50 then
												return RoundDbl(CalcStat("ProgBHealth",L)*0.75);
											elseif Lm <= 95 then
												return RoundDbl(CalcStat("ProgBHealth",L)*0.75);
											else
												return RoundDbl(CalcStat("BaseMorale",L)*0.15);
											end
										end
									elseif SN > "BATTLELOREMAS" then
										if SN < "BATTLELORETACMAS" then
											if SN == "BATTLELOREPHYMAS" then
												return CalcStat("BattleLoreMas",L);
											else
												return 0;
											end
										elseif SN > "BATTLELORETACMAS" then
											if SN == "BEOBEARFORMCRITDEF" then
												return CalcStat("CritDefT",L,0.4);
											else
												return 0;
											end
										else
											return CalcStat("BattleLoreMas",L);
										end
									else
										if Lm <= 105 then
											return CalcStat("Mastery",L,2.5);
										elseif Lm <= 119 then
											return CalcStat("MasteryT",L,1.2);
										elseif Lm <= 120 then
											return CalcStat("MasteryT",L,1.6);
										elseif Lm <= 129 then
											return CalcStat("MasteryT",L,1.2);
										elseif Lm <= 130 then
											return CalcStat("MasteryT",L,1.6);
										elseif Lm <= 139 then
											return CalcStat("MasteryT",L,1.2);
										else
											return CalcStat("MasteryT",L,1.6);
										end
									end
								elseif SN > "BEOEMISSARYFATE" then
									if SN < "BEOMIGHTOFTHEWILDMIGHT" then
										if SN < "BEOFERALPRESFATE" then
											if SN == "BEOFATE" then
												return CalcStat("FateT",L,CalcStat("Trait567810Choice",N)*0.4);
											else
												return 0;
											end
										elseif SN > "BEOFERALPRESFATE" then
											if SN == "BEOFEWINNUMBERFATE" then
												return -CalcStat("FateT",L,0.4);
											else
												return 0;
											end
										else
											return CalcStat("FateT",L,1.0);
										end
									elseif SN > "BEOMIGHTOFTHEWILDMIGHT" then
										if SN < "BEORNINGCDAGILITYTOEVADE" then
											if SN == "BEORNINGCDAGILITYTOCRITHIT" then
												return 2;
											else
												return 0;
											end
										elseif SN > "BEORNINGCDAGILITYTOEVADE" then
											if SN == "BEORNINGCDAGILITYTOFINESSE" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return CalcStat("MightT",L,1.0);
									end
								else
									return CalcStat("FateT",L,1.0);
								end
							elseif SN > "BEORNINGCDAGILITYTOOUTHEAL" then
								if SN < "BEORNINGCDBASEICMR" then
									if SN < "BEORNINGCDARMOURTOTACMIT" then
										if SN < "BEORNINGCDARMOURTOCOMPHYMIT" then
											if SN == "BEORNINGCDAGILITYTOPHYMAS" then
												return 2;
											else
												return 0;
											end
										elseif SN > "BEORNINGCDARMOURTOCOMPHYMIT" then
											if SN == "BEORNINGCDARMOURTONONPHYMIT" then
												return 0.2;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "BEORNINGCDARMOURTOTACMIT" then
										if SN < "BEORNINGCDBASEAGILITY" then
											if SN == "BEORNINGCDARMOURTYPE" then
												return 3;
											else
												return 0;
											end
										elseif SN > "BEORNINGCDBASEAGILITY" then
											if SN == "BEORNINGCDBASEFATE" then
												return CalcStat("ClassBaseFate",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseAgilityM",L);
										end
									else
										return 0.2;
									end
								elseif SN > "BEORNINGCDBASEICMR" then
									if SN < "BEORNINGCDBASENCMR" then
										if SN < "BEORNINGCDBASEMIGHT" then
											if SN == "BEORNINGCDBASEICPR" then
												return CalcStat("ClassBaseICPR",L);
											else
												return 0;
											end
										elseif SN > "BEORNINGCDBASEMIGHT" then
											if SN == "BEORNINGCDBASEMORALE" then
												return CalcStat("ClassBaseMorale",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseMightM",L);
										end
									elseif SN > "BEORNINGCDBASENCMR" then
										if SN < "BEORNINGCDBASEPOWER" then
											if SN == "BEORNINGCDBASENCPR" then
												return CalcStat("ClassBaseNCPR",L);
											else
												return 0;
											end
										elseif SN > "BEORNINGCDBASEPOWER" then
											if SN == "BEORNINGCDBASEVITALITY" then
												return CalcStat("ClassBaseVitality",L);
											else
												return 0;
											end
										else
											return 10;
										end
									else
										return CalcStat("ClassBaseNCMRM",L);
									end
								else
									return CalcStat("ClassBaseICMRM",L);
								end
							else
								return 2;
							end
						else
							if Lm <= 50 then
								return RoundDblDown(CalcStat("ProgBHealth",L)*5);
							elseif Lm <= 95 then
								return RoundDbl(CalcStat("ProgBHealth",L)*5);
							else
								return RoundDbl(CalcStat("ProgBHealth",L)*5,-1);
							end
						end
					else
						if Lm <= 40 then
							return LinFmod(1,1,40,1,40,L);
						elseif Lm <= 41 then
							return CalcStat("AwardILvlF",L-1);
						elseif Lm <= 49 then
							return LinFmod(1,41,48,42,49,L);
						elseif Lm <= 50 then
							return CalcStat("AwardILvlF",L-1);
						elseif Lm <= 55 then
							return LinFmod(1,51,55,51,55,L);
						elseif Lm <= 56 then
							return CalcStat("AwardILvlF",L-1);
						elseif Lm <= 59 then
							return LinFmod(1,56,58,57,59,L);
						elseif Lm <= 60 then
							return CalcStat("AwardILvlF",L-1);
						elseif Lm <= 64 then
							return RoundDbl(LinFmod(1,60.6,63,61,64,L));
						elseif Lm <= 65 then
							return CalcStat("AwardILvlF",L-1);
						elseif Lm <= 70 then
							return LinFmod(1,66,70,66,70,L);
						elseif Lm <= 71 then
							return CalcStat("AwardILvlF",L-1);
						elseif Lm <= 74 then
							return LinFmod(1,71,73,72,74,L);
						elseif Lm <= 75 then
							return CalcStat("AwardILvlF",L-1);
						elseif Lm <= 85 then
							return RoundDbl(LinFmod(1,80.4,123.4,76,85,L));
						elseif Lm <= 94 then
							return RoundDbl(LinFmod(1,130,169,86,94,L));
						elseif Lm <= 100 then
							return RoundDbl(LinFmod(1,175,198.4,95,100,L));
						elseif Lm <= 104 then
							return LinFmod(1,201,213,101,104,L);
						elseif Lm <= 105 then
							return 220;
						elseif Lm <= 114 then
							return RoundDbl(LinFmod(1,300,323,106,114,L));
						elseif Lm <= 115 then
							return 324;
						elseif Lm <= 119 then
							return RoundDbl(LinFmod(1,349.6,368.4,116,120,L));
						elseif Lm <= 120 then
							return 380;
						elseif Lm <= 125 then
							return RoundDbl(LinFmod(1,400.4,416.4,121,125,L));
						elseif Lm <= 129 then
							return RoundDbl(LinFmod(1,418.4,430.4,126,129,L));
						elseif Lm <= 130 then
							return 432;
						elseif Lm <= 135 then
							return RoundDbl(LinFmod(1,450.4,463.8,131,135,L));
						elseif Lm <= 138 then
							return RoundDbl(LinFmod(1,466,472.5,136,138,L));
						else
							return 475;
						end
					end
				elseif SN > "BEORNINGCDBASEWILL" then
					if SN < "BRATDEVHIT" then
						if SN < "BEORNINGRDTRAITMIGHT" then
							if SN < "BEORNINGCDPHYMITTOCOMPHYMIT" then
								if SN < "BEORNINGCDFATETONCMR" then
									if SN < "BEORNINGCDCALCTYPETACMIT" then
										if SN > "BEORNINGCDCALCTYPECOMPHYMIT" then
											if SN == "BEORNINGCDCALCTYPENONPHYMIT" then
												return 14;
											else
												return 0;
											end
										elseif SN == "BEORNINGCDCALCTYPECOMPHYMIT" then
											return 14;
										else
											return 0;
										end
									elseif SN > "BEORNINGCDCALCTYPETACMIT" then
										if SN < "BEORNINGCDFATETOICMR" then
											if SN == "BEORNINGCDCANBLOCK" then
												if Lm <= 5 then
													return 0;
												else
													return 1;
												end
											else
												return 0;
											end
										elseif SN > "BEORNINGCDFATETOICMR" then
											if SN == "BEORNINGCDFATETOMORALE" then
												return 2.5;
											else
												return 0;
											end
										else
											return 0.04;
										end
									else
										return 27;
									end
								elseif SN > "BEORNINGCDFATETONCMR" then
									if SN < "BEORNINGCDMIGHTTOPARRY" then
										if SN < "BEORNINGCDMIGHTTOEVADE" then
											if SN == "BEORNINGCDMIGHTTOCRITHIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "BEORNINGCDMIGHTTOEVADE" then
											if SN == "BEORNINGCDMIGHTTOOUTHEAL" then
												return 3;
											else
												return 0;
											end
										else
											return 2;
										end
									elseif SN > "BEORNINGCDMIGHTTOPARRY" then
										if SN < "BEORNINGCDMIGHTTOPHYMIT" then
											if SN == "BEORNINGCDMIGHTTOPHYMAS" then
												return 3;
											else
												return 0;
											end
										elseif SN > "BEORNINGCDMIGHTTOPHYMIT" then
											if SN == "BEORNINGCDMIGHTTOTACMIT" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 1;
									end
								else
									return 0.12;
								end
							elseif SN > "BEORNINGCDPHYMITTOCOMPHYMIT" then
								if SN < "BEORNINGCDWILLTOPHYMAS" then
									if SN < "BEORNINGCDVITALITYTOMORALE" then
										if SN < "BEORNINGCDTACMASTOOUTHEAL" then
											if SN == "BEORNINGCDPHYMITTONONPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "BEORNINGCDTACMASTOOUTHEAL" then
											if SN == "BEORNINGCDVITALITYTOICMR" then
												return 0.012;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "BEORNINGCDVITALITYTOMORALE" then
										if SN < "BEORNINGCDWILLTOFINESSE" then
											if SN == "BEORNINGCDVITALITYTONCMR" then
												return 0.12;
											else
												return 0;
											end
										elseif SN > "BEORNINGCDWILLTOFINESSE" then
											if SN == "BEORNINGCDWILLTOOUTHEAL" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 4.5;
									end
								elseif SN > "BEORNINGCDWILLTOPHYMAS" then
									if SN < "BEORNINGRDPSVONEFATE" then
										if SN < "BEORNINGCDWILLTORESIST" then
											if SN == "BEORNINGCDWILLTOPHYMIT" then
												return 1.5;
											else
												return 0;
											end
										elseif SN > "BEORNINGCDWILLTORESIST" then
											if SN == "BEORNINGCDWILLTOTACMIT" then
												return 1.5;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "BEORNINGRDPSVONEFATE" then
										if SN < "BEORNINGRDPSVTWONAME" then
											if SN == "BEORNINGRDPSVONENAME" then
												return "Emissary";
											else
												return 0;
											end
										elseif SN > "BEORNINGRDPSVTWONAME" then
											if SN == "BEORNINGRDTRAITFATE" then
												return CalcStat("BeoFewinNumberFate",L);
											else
												return 0;
											end
										else
											return "";
										end
									else
										return CalcStat("BeoEmissaryFate",L);
									end
								else
									return 1;
								end
							else
								return 1;
							end
						elseif SN > "BEORNINGRDTRAITMIGHT" then
							if SN < "BLOCKPRATPC" then
								if SN < "BLACKARROWCDHASPOWER" then
									if SN < "BLACKARROWCANBLOCK" then
										if SN < "BEOTHICKHIDEVITALITY" then
											if SN == "BEORNINGRDTRAITVITALITY" then
												return CalcStat("BeoThickHideVitality",L);
											else
												return 0;
											end
										elseif SN > "BEOTHICKHIDEVITALITY" then
											if SN == "BEOVITALITYINCREASE" then
												return CalcStat("VitalityT",L,CalcStat("Trait567810Choice",N)*0.4);
											else
												return 0;
											end
										else
											return CalcStat("VitalityT",L,1.0);
										end
									elseif SN > "BLACKARROWCANBLOCK" then
										if SN < "BLACKARROWCDCALCTYPENONPHYMIT" then
											if SN == "BLACKARROWCDCALCTYPECOMPHYMIT" then
												return 13;
											else
												return 0;
											end
										elseif SN > "BLACKARROWCDCALCTYPENONPHYMIT" then
											if SN == "BLACKARROWCDCALCTYPETACMIT" then
												return 27;
											else
												return 0;
											end
										else
											return 14;
										end
									else
										return 1;
									end
								elseif SN > "BLACKARROWCDHASPOWER" then
									if SN < "BLOCKPPRAT" then
										if SN < "BLOCKC" then
											if SN == "BLOCK" then
												return CalcStat("BPE",L,N);
											else
												return 0;
											end
										elseif SN > "BLOCKC" then
											if SN == "BLOCKPBONUS" then
												return CalcStat("BPEPBonus",L);
											else
												return 0;
											end
										else
											return CalcStat("BPEC",L,N);
										end
									elseif SN > "BLOCKPPRAT" then
										if SN < "BLOCKPRATPA" then
											if SN == "BLOCKPRATP" then
												return CalcStat("BPEPRatP",L,N);
											else
												return 0;
											end
										elseif SN > "BLOCKPRATPA" then
											if SN == "BLOCKPRATPB" then
												return CalcStat("BPEPRatPB",L);
											else
												return 0;
											end
										else
											return CalcStat("BPEPRatPA",L);
										end
									else
										return CalcStat("BPEPPRat",L,N);
									end
								else
									return 1;
								end
							elseif SN > "BLOCKPRATPC" then
								if SN < "BPEPRATP" then
									if SN < "BPE" then
										if SN < "BLOCKPRATPCAPR" then
											if SN == "BLOCKPRATPCAP" then
												return CalcStat("BPEPRatPCap",L);
											else
												return 0;
											end
										elseif SN > "BLOCKPRATPCAPR" then
											if SN == "BLOCKT" then
												return CalcStat("BPET",L,N);
											else
												return 0;
											end
										else
											return CalcStat("BPEPRatPCapR",L);
										end
									elseif SN > "BPE" then
										if SN < "BPEPBONUS" then
											if SN == "BPEC" then
												return StatLinInter("PntMPBPEC","CreepPntS","ProgBBPEC","",L,N,0);
											else
												return 0;
											end
										elseif SN > "BPEPBONUS" then
											if SN == "BPEPPRAT" then
												return CalcRatAB(CalcStat("BPEPRatPA",L),CalcStat("BPEPRatPB",L),CalcStat("BPEPRatPCapR",L),N);
											else
												return 0;
											end
										else
											return 0;
										end
									else
										return StatLinInter("PntMPBPE","ItemPntS","ProgBBPE","AdjUmbarItem",L,N,0);
									end
								elseif SN > "BPEPRATP" then
									if SN < "BPEPRATPCAP" then
										if SN < "BPEPRATPB" then
											if SN == "BPEPRATPA" then
												return 39;
											else
												return 0;
											end
										elseif SN > "BPEPRATPB" then
											if SN == "BPEPRATPC" then
												return 0.5;
											else
												return 0;
											end
										else
											return CalcStat("BRatRounded",L,"BRatStandard");
										end
									elseif SN > "BPEPRATPCAP" then
										if SN < "BPET" then
											if SN == "BPEPRATPCAPR" then
												return CalcStat("BPEPRatPB",L)*CalcStat("BPEPRatPC",L);
											else
												return 0;
											end
										elseif SN > "BPET" then
											if SN == "BRATCRITMAGN" then
												return CalcStat("StdProg",L,600);
											else
												return 0;
											end
										else
											return StatLinInter("PntMPBPE","TraitPntS","ProgBBPE","AdjUmbarTrait",L,N,0);
										end
									else
										return 13;
									end
								else
									return CalcPercAB(CalcStat("BPEPRatPA",L),CalcStat("BPEPRatPB",L),CalcStat("BPEPRatPCap",L),N);
								end
							else
								return CalcStat("BPEPRatPC",L);
							end
						else
							return CalcStat("BeoMightoftheWildMight",L);
						end
					elseif SN > "BRATDEVHIT" then
						if SN < "BRAWLERCDCALCTYPECOMPHYMIT" then
							if SN < "BRAWLERCDAGILITYTOPHYMAS" then
								if SN < "BRATPARTBPE" then
									if SN < "BRATMITIGATIONS" then
										if SN > "BRATEXTRA" then
											if SN == "BRATMITHEAVY" then
												return CalcStat("BRatStandard",L);
											else
												return 0;
											end
										elseif SN == "BRATEXTRA" then
											return CalcStat("StdProg",L,300);
										else
											return 0;
										end
									elseif SN > "BRATMITIGATIONS" then
										if SN < "BRATMITMEDIUM" then
											if SN == "BRATMITLIGHT" then
												return CalcStat("BRatMitigations",L,0.666);
											else
												return 0;
											end
										elseif SN > "BRATMITMEDIUM" then
											if SN == "BRATOUTHEAL" then
												return CalcStat("StdProg",L,450);
											else
												return 0;
											end
										else
											return CalcStat("BRatMitigations",L,0.833);
										end
									else
										if Lm <= 50 then
											return LinFmod(1,(N*CalcStat("BRatStandard",1))*7/6-50.4,N*CalcStat("BRatStandard",50),1,50,L,"P");
										else
											return StatLinInter("","StdPntS","BRatStandard","",L,N,3);
										end
									end
								elseif SN > "BRATPARTBPE" then
									if SN < "BRAWLERCDAGILITYTOCRITHIT" then
										if SN < "BRATROUNDED" then
											if SN == "BRATPROGB" then
												if Lm <= 50 then
													return RoundDbl(CalcStat(C,L));
												else
													return CalcStat(C,L);
												end
											else
												return 0;
											end
										elseif SN > "BRATROUNDED" then
											if SN == "BRATSTANDARD" then
												return CalcStat("StdProg",L,200);
											else
												return 0;
											end
										else
											if Lm <= 50 then
												return RoundDbl(CalcStat(C,L));
											elseif Lm <= 105 then
												return RoundDbl(CalcStat(C,L),-1);
											elseif Lm <= 115 then
												return RoundDbl(CalcStat(C,L),-2);
											elseif Lm <= 130 then
												return RoundDbl(CalcStat(C,L),-1);
											elseif Lm <= 150 then
												return RoundDbl(CalcStat(C,L),-2);
											else
												return RoundDbl(CalcStat(C,L));
											end
										end
									elseif SN > "BRAWLERCDAGILITYTOCRITHIT" then
										if SN < "BRAWLERCDAGILITYTOFINESSE" then
											if SN == "BRAWLERCDAGILITYTOEVADE" then
												return 2;
											else
												return 0;
											end
										elseif SN > "BRAWLERCDAGILITYTOFINESSE" then
											if SN == "BRAWLERCDAGILITYTOOUTHEAL" then
												return 2;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 2;
									end
								else
									return CalcStat("StdProg",L,350);
								end
							elseif SN > "BRAWLERCDAGILITYTOPHYMAS" then
								if SN < "BRAWLERCDBASEICPR" then
									if SN < "BRAWLERCDARMOURTYPE" then
										if SN < "BRAWLERCDARMOURTONONPHYMIT" then
											if SN == "BRAWLERCDARMOURTOCOMPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "BRAWLERCDARMOURTONONPHYMIT" then
											if SN == "BRAWLERCDARMOURTOTACMIT" then
												return 0.2;
											else
												return 0;
											end
										else
											return 0.2;
										end
									elseif SN > "BRAWLERCDARMOURTYPE" then
										if SN < "BRAWLERCDBASEFATE" then
											if SN == "BRAWLERCDBASEAGILITY" then
												return CalcStat("ClassBaseAgilityM",L);
											else
												return 0;
											end
										elseif SN > "BRAWLERCDBASEFATE" then
											if SN == "BRAWLERCDBASEICMR" then
												return CalcStat("ClassBaseICMRL",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseFate",L);
										end
									else
										return 3;
									end
								elseif SN > "BRAWLERCDBASEICPR" then
									if SN < "BRAWLERCDBASENCPR" then
										if SN < "BRAWLERCDBASEMORALE" then
											if SN == "BRAWLERCDBASEMIGHT" then
												return CalcStat("ClassBaseMightH",L);
											else
												return 0;
											end
										elseif SN > "BRAWLERCDBASEMORALE" then
											if SN == "BRAWLERCDBASENCMR" then
												return CalcStat("ClassBaseNCMRL",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseMorale",L);
										end
									elseif SN > "BRAWLERCDBASENCPR" then
										if SN < "BRAWLERCDBASEVITALITY" then
											if SN == "BRAWLERCDBASEPOWER" then
												return CalcStat("ClassBasePower",L);
											else
												return 0;
											end
										elseif SN > "BRAWLERCDBASEVITALITY" then
											if SN == "BRAWLERCDBASEWILL" then
												return CalcStat("ClassBaseWillL",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseVitality",L);
										end
									else
										return CalcStat("ClassBaseNCPR",L);
									end
								else
									return CalcStat("ClassBaseICPR",L);
								end
							else
								return 2;
							end
						elseif SN > "BRAWLERCDCALCTYPECOMPHYMIT" then
							if SN < "BRAWLERCDVITALITYTOICMR" then
								if SN < "BRAWLERCDMIGHTTOOUTHEAL" then
									if SN < "BRAWLERCDFATETOPOWER" then
										if SN < "BRAWLERCDCALCTYPETACMIT" then
											if SN == "BRAWLERCDCALCTYPENONPHYMIT" then
												return 14;
											else
												return 0;
											end
										elseif SN > "BRAWLERCDCALCTYPETACMIT" then
											if SN == "BRAWLERCDFATETONCPR" then
												return 0.07;
											else
												return 0;
											end
										else
											return 27;
										end
									elseif SN > "BRAWLERCDFATETOPOWER" then
										if SN < "BRAWLERCDMIGHTTOCRITHIT" then
											if SN == "BRAWLERCDHASPOWER" then
												return 1;
											else
												return 0;
											end
										elseif SN > "BRAWLERCDMIGHTTOCRITHIT" then
											if SN == "BRAWLERCDMIGHTTOEVADE" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 1;
									end
								elseif SN > "BRAWLERCDMIGHTTOOUTHEAL" then
									if SN < "BRAWLERCDMIGHTTOTACMIT" then
										if SN < "BRAWLERCDMIGHTTOPHYMAS" then
											if SN == "BRAWLERCDMIGHTTOPARRY" then
												return 1;
											else
												return 0;
											end
										elseif SN > "BRAWLERCDMIGHTTOPHYMAS" then
											if SN == "BRAWLERCDMIGHTTOPHYMIT" then
												return 1;
											else
												return 0;
											end
										else
											return 3;
										end
									elseif SN > "BRAWLERCDMIGHTTOTACMIT" then
										if SN < "BRAWLERCDPHYMITTONONPHYMIT" then
											if SN == "BRAWLERCDPHYMITTOCOMPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "BRAWLERCDPHYMITTONONPHYMIT" then
											if SN == "BRAWLERCDTACMASTOOUTHEAL" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 1;
									end
								else
									return 3;
								end
							elseif SN > "BRAWLERCDVITALITYTOICMR" then
								if SN < "BRAWLERCDWILLTOTACMIT" then
									if SN < "BRAWLERCDWILLTOOUTHEAL" then
										if SN < "BRAWLERCDVITALITYTONCMR" then
											if SN == "BRAWLERCDVITALITYTOMORALE" then
												return 4.5;
											else
												return 0;
											end
										elseif SN > "BRAWLERCDVITALITYTONCMR" then
											if SN == "BRAWLERCDWILLTOFINESSE" then
												return 1;
											else
												return 0;
											end
										else
											return 0.12;
										end
									elseif SN > "BRAWLERCDWILLTOOUTHEAL" then
										if SN < "BRAWLERCDWILLTOPHYMIT" then
											if SN == "BRAWLERCDWILLTOPHYMAS" then
												return 1;
											else
												return 0;
											end
										elseif SN > "BRAWLERCDWILLTOPHYMIT" then
											if SN == "BRAWLERCDWILLTORESIST" then
												return 1;
											else
												return 0;
											end
										else
											return 1.5;
										end
									else
										return 1;
									end
								elseif SN > "BRAWLERCDWILLTOTACMIT" then
									if SN < "BRGREVWEAKNFINESSE" then
										if SN < "BRGALLINONEXPFINESSE" then
											if SN == "BRGALLINFINESSE" then
												return CalcStat("Finesse",L,2);
											else
												return 0;
											end
										elseif SN > "BRGALLINONEXPFINESSE" then
											if SN == "BRGREVWEAKNCRITDEF" then
												return -CalcStat("CritDefT",L,0.4);
											else
												return 0;
											end
										else
											return -CalcStat("Finesse",L,2);
										end
									elseif SN > "BRGREVWEAKNFINESSE" then
										if SN < "BRGTRICKCNTDEFBPE" then
											if SN == "BRGREVWEAKNRESIST" then
												return -CalcStat("ResistT",L,0.4);
											else
												return 0;
											end
										elseif SN > "BRGTRICKCNTDEFBPE" then
											if SN == "BRGTRICKCNTDEFCRITDEF" then
												return -CalcStat("CritDefT",L,0.8);
											else
												return 0;
											end
										else
											return -CalcStat("BPET",L,1.2);
										end
									else
										return -CalcStat("FinesseT",L,0.4);
									end
								else
									return 1.5;
								end
							else
								return 0.012;
							end
						else
							return 14;
						end
					else
						return CalcStat("StdProg",L,400);
					end
				else
					return CalcStat("ClassBaseWillM",L);
				end
			elseif SN > "BRWAGGPOSTUREPHYMIT" then
				if SN < "CHAMPIONCDCALCTYPECOMPHYMIT" then
					if SN < "CAPTAINCDAGILITYTOTACMAS" then
						if SN < "BURGLARCDBASENCPR" then
							if SN < "BURGLARCDAGILITYTOOUTHEAL" then
								if SN < "BRWRETPRECISIONFINESSE" then
									if SN < "BRWINNSTRPRECISIONCRITHIT" then
										if SN > "BRWDEFPOSTUREPHYMAS" then
											if SN == "BRWINNSTRCLEVTECHFINESSE" then
												return CalcStat("FinesseT",L,CalcStat("Trait13510Choice",N)*0.2);
											else
												return 0;
											end
										elseif SN == "BRWDEFPOSTUREPHYMAS" then
											return -CalcStat("PhyMasT",L,4);
										else
											return 0;
										end
									elseif SN > "BRWINNSTRPRECISIONCRITHIT" then
										if SN < "BRWMIGHTINCREASE" then
											if SN == "BRWMAELSTROMMIGHT" then
												return CalcStat("MightT",L,2);
											else
												return 0;
											end
										elseif SN > "BRWMIGHTINCREASE" then
											if SN == "BRWRETINTENSITYCRITHIT" then
												return CalcStat("CritHitT",L,CalcStat("Trait234Choice",N));
											else
												return 0;
											end
										else
											return CalcStat("MightT",L,CalcStat("Trait567810Choice",N)*0.4);
										end
									else
										return CalcStat("CritHitT",L,CalcStat("Trait13510Choice",N)*0.2);
									end
								elseif SN > "BRWRETPRECISIONFINESSE" then
									if SN < "BRWTACMIT" then
										if SN < "BRWSHAREISHEAVYCRITHIT" then
											if SN == "BRWSHAREISBALANCEFINESSE" then
												return CalcStat("BrwInnStrClevTechFinesse",L,3);
											else
												return 0;
											end
										elseif SN > "BRWSHAREISHEAVYCRITHIT" then
											if SN == "BRWSHATTFISTARMOUR" then
												return -CalcStat("ArmourT",L,1.6);
											else
												return 0;
											end
										else
											return CalcStat("BrwInnStrPrecisionCritHit",L,3);
										end
									elseif SN > "BRWTACMIT" then
										if SN < "BURGLARCDAGILITYTOCRITHIT" then
											if SN == "BRWVITALITYINCREASE" then
												return CalcStat("VitalityT",L,CalcStat("Trait567810Choice",N)*0.4);
											else
												return 0;
											end
										elseif SN > "BURGLARCDAGILITYTOCRITHIT" then
											if SN == "BURGLARCDAGILITYTOEVADE" then
												return 2;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return CalcStat("TacMitT",L,CalcStat("Trait12345Choice",N)*0.4);
									end
								else
									return CalcStat("FinesseT",L,CalcStat("Trait234Choice",N));
								end
							elseif SN > "BURGLARCDAGILITYTOOUTHEAL" then
								if SN < "BURGLARCDARMOURTYPE" then
									if SN < "BURGLARCDAGILITYTOTACMIT" then
										if SN < "BURGLARCDAGILITYTOPHYMAS" then
											if SN == "BURGLARCDAGILITYTOPARRY" then
												return 1;
											else
												return 0;
											end
										elseif SN > "BURGLARCDAGILITYTOPHYMAS" then
											if SN == "BURGLARCDAGILITYTOPHYMIT" then
												return 1;
											else
												return 0;
											end
										else
											return 3;
										end
									elseif SN > "BURGLARCDAGILITYTOTACMIT" then
										if SN < "BURGLARCDARMOURTONONPHYMIT" then
											if SN == "BURGLARCDARMOURTOCOMPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "BURGLARCDARMOURTONONPHYMIT" then
											if SN == "BURGLARCDARMOURTOTACMIT" then
												return 0.2;
											else
												return 0;
											end
										else
											return 0.2;
										end
									else
										return 1;
									end
								elseif SN > "BURGLARCDARMOURTYPE" then
									if SN < "BURGLARCDBASEICPR" then
										if SN < "BURGLARCDBASEFATE" then
											if SN == "BURGLARCDBASEAGILITY" then
												return CalcStat("ClassBaseAgilityH",L);
											else
												return 0;
											end
										elseif SN > "BURGLARCDBASEFATE" then
											if SN == "BURGLARCDBASEICMR" then
												return CalcStat("ClassBaseICMRL",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseFate",L);
										end
									elseif SN > "BURGLARCDBASEICPR" then
										if SN < "BURGLARCDBASEMORALE" then
											if SN == "BURGLARCDBASEMIGHT" then
												return CalcStat("ClassBaseMightM",L);
											else
												return 0;
											end
										elseif SN > "BURGLARCDBASEMORALE" then
											if SN == "BURGLARCDBASENCMR" then
												return CalcStat("ClassBaseNCMRL",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseMorale",L);
										end
									else
										return CalcStat("ClassBaseICPR",L);
									end
								else
									return 2;
								end
							else
								return 3;
							end
						elseif SN > "BURGLARCDBASENCPR" then
							if SN < "BURGLARCDPHYMITTONONPHYMIT" then
								if SN < "BURGLARCDFATETOPOWER" then
									if SN < "BURGLARCDCALCTYPECOMPHYMIT" then
										if SN < "BURGLARCDBASEVITALITY" then
											if SN == "BURGLARCDBASEPOWER" then
												return CalcStat("ClassBasePower",L);
											else
												return 0;
											end
										elseif SN > "BURGLARCDBASEVITALITY" then
											if SN == "BURGLARCDBASEWILL" then
												return CalcStat("ClassBaseWillL",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseVitality",L);
										end
									elseif SN > "BURGLARCDCALCTYPECOMPHYMIT" then
										if SN < "BURGLARCDCALCTYPETACMIT" then
											if SN == "BURGLARCDCALCTYPENONPHYMIT" then
												return 13;
											else
												return 0;
											end
										elseif SN > "BURGLARCDCALCTYPETACMIT" then
											if SN == "BURGLARCDFATETONCPR" then
												return 0.07;
											else
												return 0;
											end
										else
											return 26;
										end
									else
										return 13;
									end
								elseif SN > "BURGLARCDFATETOPOWER" then
									if SN < "BURGLARCDMIGHTTOFINESSE" then
										if SN < "BURGLARCDMIGHTTOCRITHIT" then
											if SN == "BURGLARCDHASPOWER" then
												return 1;
											else
												return 0;
											end
										elseif SN > "BURGLARCDMIGHTTOCRITHIT" then
											if SN == "BURGLARCDMIGHTTOEVADE" then
												return 1;
											else
												return 0;
											end
										else
											return 1.5;
										end
									elseif SN > "BURGLARCDMIGHTTOFINESSE" then
										if SN < "BURGLARCDMIGHTTOPHYMAS" then
											if SN == "BURGLARCDMIGHTTOOUTHEAL" then
												return 2;
											else
												return 0;
											end
										elseif SN > "BURGLARCDMIGHTTOPHYMAS" then
											if SN == "BURGLARCDPHYMITTOCOMPHYMIT" then
												return 1;
											else
												return 0;
											end
										else
											return 2;
										end
									else
										return 1.5;
									end
								else
									return 1;
								end
							elseif SN > "BURGLARCDPHYMITTONONPHYMIT" then
								if SN < "BURGLARCDWILLTOPHYMAS" then
									if SN < "BURGLARCDVITALITYTONCMR" then
										if SN < "BURGLARCDVITALITYTOICMR" then
											if SN == "BURGLARCDTACMASTOOUTHEAL" then
												return 1;
											else
												return 0;
											end
										elseif SN > "BURGLARCDVITALITYTOICMR" then
											if SN == "BURGLARCDVITALITYTOMORALE" then
												return 4.5;
											else
												return 0;
											end
										else
											return 0.012;
										end
									elseif SN > "BURGLARCDVITALITYTONCMR" then
										if SN < "BURGLARCDWILLTOFINESSE" then
											if SN == "BURGLARCDWILLTOCRITHIT" then
												return 0.5;
											else
												return 0;
											end
										elseif SN > "BURGLARCDWILLTOFINESSE" then
											if SN == "BURGLARCDWILLTOOUTHEAL" then
												return 2;
											else
												return 0;
											end
										else
											return 1.5;
										end
									else
										return 0.12;
									end
								elseif SN > "BURGLARCDWILLTOPHYMAS" then
									if SN < "CAPTAINCDAGILITYTOCRITHIT" then
										if SN < "BURGLARCDWILLTORESIST" then
											if SN == "BURGLARCDWILLTOPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "BURGLARCDWILLTORESIST" then
											if SN == "C" then
												return C;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "CAPTAINCDAGILITYTOCRITHIT" then
										if SN < "CAPTAINCDAGILITYTOPARRY" then
											if SN == "CAPTAINCDAGILITYTOFINESSE" then
												return 1;
											else
												return 0;
											end
										elseif SN > "CAPTAINCDAGILITYTOPARRY" then
											if SN == "CAPTAINCDAGILITYTOPHYMAS" then
												return 2;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 2;
									end
								else
									return 2;
								end
							else
								return 1;
							end
						else
							return CalcStat("ClassBaseNCPR",L);
						end
					elseif SN > "CAPTAINCDAGILITYTOTACMAS" then
						if SN < "CAPTAINCDPHYMITTONONPHYMIT" then
							if SN < "CAPTAINCDBASEWILL" then
								if SN < "CAPTAINCDBASEICMR" then
									if SN < "CAPTAINCDARMOURTOTACMIT" then
										if SN > "CAPTAINCDARMOURTOCOMPHYMIT" then
											if SN == "CAPTAINCDARMOURTONONPHYMIT" then
												return 0.2;
											else
												return 0;
											end
										elseif SN == "CAPTAINCDARMOURTOCOMPHYMIT" then
											return 1;
										else
											return 0;
										end
									elseif SN > "CAPTAINCDARMOURTOTACMIT" then
										if SN < "CAPTAINCDBASEAGILITY" then
											if SN == "CAPTAINCDARMOURTYPE" then
												return 3;
											else
												return 0;
											end
										elseif SN > "CAPTAINCDBASEAGILITY" then
											if SN == "CAPTAINCDBASEFATE" then
												return CalcStat("ClassBaseFate",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseAgilityL",L);
										end
									else
										return 0.2;
									end
								elseif SN > "CAPTAINCDBASEICMR" then
									if SN < "CAPTAINCDBASENCMR" then
										if SN < "CAPTAINCDBASEMIGHT" then
											if SN == "CAPTAINCDBASEICPR" then
												return CalcStat("ClassBaseICPR",L);
											else
												return 0;
											end
										elseif SN > "CAPTAINCDBASEMIGHT" then
											if SN == "CAPTAINCDBASEMORALE" then
												return CalcStat("ClassBaseMorale",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseMightH",L);
										end
									elseif SN > "CAPTAINCDBASENCMR" then
										if SN < "CAPTAINCDBASEPOWER" then
											if SN == "CAPTAINCDBASENCPR" then
												return CalcStat("ClassBaseNCPR",L);
											else
												return 0;
											end
										elseif SN > "CAPTAINCDBASEPOWER" then
											if SN == "CAPTAINCDBASEVITALITY" then
												return CalcStat("ClassBaseVitality",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBasePower",L);
										end
									else
										return CalcStat("ClassBaseNCMRM",L);
									end
								else
									return CalcStat("ClassBaseICMRM",L);
								end
							elseif SN > "CAPTAINCDBASEWILL" then
								if SN < "CAPTAINCDMIGHTTOBLOCK" then
									if SN < "CAPTAINCDCANBLOCK" then
										if SN < "CAPTAINCDCALCTYPENONPHYMIT" then
											if SN == "CAPTAINCDCALCTYPECOMPHYMIT" then
												return 14;
											else
												return 0;
											end
										elseif SN > "CAPTAINCDCALCTYPENONPHYMIT" then
											if SN == "CAPTAINCDCALCTYPETACMIT" then
												return 27;
											else
												return 0;
											end
										else
											return 14;
										end
									elseif SN > "CAPTAINCDCANBLOCK" then
										if SN < "CAPTAINCDFATETOPOWER" then
											if SN == "CAPTAINCDFATETONCPR" then
												return 0.07;
											else
												return 0;
											end
										elseif SN > "CAPTAINCDFATETOPOWER" then
											if SN == "CAPTAINCDHASPOWER" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										if Lm <= 14 then
											return 0;
										else
											return 1;
										end
									end
								elseif SN > "CAPTAINCDMIGHTTOBLOCK" then
									if SN < "CAPTAINCDMIGHTTOPHYMIT" then
										if SN < "CAPTAINCDMIGHTTOPARRY" then
											if SN == "CAPTAINCDMIGHTTOCRITHIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "CAPTAINCDMIGHTTOPARRY" then
											if SN == "CAPTAINCDMIGHTTOPHYMAS" then
												return 3;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "CAPTAINCDMIGHTTOPHYMIT" then
										if SN < "CAPTAINCDMIGHTTOTACMIT" then
											if SN == "CAPTAINCDMIGHTTOTACMAS" then
												return 3;
											else
												return 0;
											end
										elseif SN > "CAPTAINCDMIGHTTOTACMIT" then
											if SN == "CAPTAINCDPHYMITTOCOMPHYMIT" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 1;
									end
								else
									return 2;
								end
							else
								return CalcStat("ClassBaseWillM",L);
							end
						elseif SN > "CAPTAINCDPHYMITTONONPHYMIT" then
							if SN < "CHAMPIONCDAGILITYTOPHYMAS" then
								if SN < "CAPTAINCDWILLTORESIST" then
									if SN < "CAPTAINCDVITALITYTONCMR" then
										if SN < "CAPTAINCDVITALITYTOICMR" then
											if SN == "CAPTAINCDTACMASTOOUTHEAL" then
												return 1;
											else
												return 0;
											end
										elseif SN > "CAPTAINCDVITALITYTOICMR" then
											if SN == "CAPTAINCDVITALITYTOMORALE" then
												return 4.5;
											else
												return 0;
											end
										else
											return 0.012;
										end
									elseif SN > "CAPTAINCDVITALITYTONCMR" then
										if SN < "CAPTAINCDWILLTOPHYMAS" then
											if SN == "CAPTAINCDWILLTOFINESSE" then
												return 1;
											else
												return 0;
											end
										elseif SN > "CAPTAINCDWILLTOPHYMAS" then
											if SN == "CAPTAINCDWILLTOPHYMIT" then
												return 1.5;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 0.12;
									end
								elseif SN > "CAPTAINCDWILLTORESIST" then
									if SN < "CHAMPIONCDAGILITYTOCRITHIT" then
										if SN < "CAPTAINCDWILLTOTACMIT" then
											if SN == "CAPTAINCDWILLTOTACMAS" then
												return 1;
											else
												return 0;
											end
										elseif SN > "CAPTAINCDWILLTOTACMIT" then
											if SN == "CATMINTBEARARMOUR" then
												return CalcStat("LMCatmintBearArmour",L);
											else
												return 0;
											end
										else
											return 1.5;
										end
									elseif SN > "CHAMPIONCDAGILITYTOCRITHIT" then
										if SN < "CHAMPIONCDAGILITYTOOUTHEAL" then
											if SN == "CHAMPIONCDAGILITYTOFINESSE" then
												return 1;
											else
												return 0;
											end
										elseif SN > "CHAMPIONCDAGILITYTOOUTHEAL" then
											if SN == "CHAMPIONCDAGILITYTOPARRY" then
												return 1;
											else
												return 0;
											end
										else
											return 2;
										end
									else
										return 2;
									end
								else
									return 1;
								end
							elseif SN > "CHAMPIONCDAGILITYTOPHYMAS" then
								if SN < "CHAMPIONCDBASEICPR" then
									if SN < "CHAMPIONCDARMOURTYPE" then
										if SN < "CHAMPIONCDARMOURTONONPHYMIT" then
											if SN == "CHAMPIONCDARMOURTOCOMPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "CHAMPIONCDARMOURTONONPHYMIT" then
											if SN == "CHAMPIONCDARMOURTOTACMIT" then
												return 0.2;
											else
												return 0;
											end
										else
											return 0.2;
										end
									elseif SN > "CHAMPIONCDARMOURTYPE" then
										if SN < "CHAMPIONCDBASEFATE" then
											if SN == "CHAMPIONCDBASEAGILITY" then
												return CalcStat("ClassBaseAgilityM",L);
											else
												return 0;
											end
										elseif SN > "CHAMPIONCDBASEFATE" then
											if SN == "CHAMPIONCDBASEICMR" then
												return CalcStat("ClassBaseICMRH",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseFate",L);
										end
									else
										return 3;
									end
								elseif SN > "CHAMPIONCDBASEICPR" then
									if SN < "CHAMPIONCDBASENCPR" then
										if SN < "CHAMPIONCDBASEMORALE" then
											if SN == "CHAMPIONCDBASEMIGHT" then
												return CalcStat("ClassBaseMightH",L);
											else
												return 0;
											end
										elseif SN > "CHAMPIONCDBASEMORALE" then
											if SN == "CHAMPIONCDBASENCMR" then
												return CalcStat("ClassBaseNCMRH",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseMorale",L);
										end
									elseif SN > "CHAMPIONCDBASENCPR" then
										if SN < "CHAMPIONCDBASEVITALITY" then
											if SN == "CHAMPIONCDBASEPOWER" then
												return CalcStat("ClassBasePower",L);
											else
												return 0;
											end
										elseif SN > "CHAMPIONCDBASEVITALITY" then
											if SN == "CHAMPIONCDBASEWILL" then
												return CalcStat("ClassBaseWillL",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseVitality",L);
										end
									else
										return CalcStat("ClassBaseNCPR",L);
									end
								else
									return CalcStat("ClassBaseICPR",L);
								end
							else
								return 2;
							end
						else
							return 1;
						end
					else
						return 2;
					end
				elseif SN > "CHAMPIONCDCALCTYPECOMPHYMIT" then
					if SN < "CLASSBASEWILLL" then
						if SN < "CHISELCRITHITHOLD" then
							if SN < "CHAMPIONCDTACMASTOOUTHEAL" then
								if SN < "CHAMPIONCDMIGHTTOCRITHIT" then
									if SN < "CHAMPIONCDCANBLOCK" then
										if SN > "CHAMPIONCDCALCTYPENONPHYMIT" then
											if SN == "CHAMPIONCDCALCTYPETACMIT" then
												return 27;
											else
												return 0;
											end
										elseif SN == "CHAMPIONCDCALCTYPENONPHYMIT" then
											return 14;
										else
											return 0;
										end
									elseif SN > "CHAMPIONCDCANBLOCK" then
										if SN < "CHAMPIONCDFATETOPOWER" then
											if SN == "CHAMPIONCDFATETONCPR" then
												return 0.07;
											else
												return 0;
											end
										elseif SN > "CHAMPIONCDFATETOPOWER" then
											if SN == "CHAMPIONCDHASPOWER" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										if Lm <= 5 then
											return 0;
										else
											return 1;
										end
									end
								elseif SN > "CHAMPIONCDMIGHTTOCRITHIT" then
									if SN < "CHAMPIONCDMIGHTTOPHYMIT" then
										if SN < "CHAMPIONCDMIGHTTOPARRY" then
											if SN == "CHAMPIONCDMIGHTTOOUTHEAL" then
												return 3;
											else
												return 0;
											end
										elseif SN > "CHAMPIONCDMIGHTTOPARRY" then
											if SN == "CHAMPIONCDMIGHTTOPHYMAS" then
												return 3;
											else
												return 0;
											end
										else
											return 3;
										end
									elseif SN > "CHAMPIONCDMIGHTTOPHYMIT" then
										if SN < "CHAMPIONCDPHYMITTOCOMPHYMIT" then
											if SN == "CHAMPIONCDMIGHTTOTACMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "CHAMPIONCDPHYMITTOCOMPHYMIT" then
											if SN == "CHAMPIONCDPHYMITTONONPHYMIT" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 1;
									end
								else
									return 1;
								end
							elseif SN > "CHAMPIONCDTACMASTOOUTHEAL" then
								if SN < "CHAMPIONCDWILLTORESIST" then
									if SN < "CHAMPIONCDWILLTOFINESSE" then
										if SN < "CHAMPIONCDVITALITYTOMORALE" then
											if SN == "CHAMPIONCDVITALITYTOICMR" then
												return 0.012;
											else
												return 0;
											end
										elseif SN > "CHAMPIONCDVITALITYTOMORALE" then
											if SN == "CHAMPIONCDVITALITYTONCMR" then
												return 0.12;
											else
												return 0;
											end
										else
											return 4.5;
										end
									elseif SN > "CHAMPIONCDWILLTOFINESSE" then
										if SN < "CHAMPIONCDWILLTOPHYMAS" then
											if SN == "CHAMPIONCDWILLTOOUTHEAL" then
												return 1;
											else
												return 0;
											end
										elseif SN > "CHAMPIONCDWILLTOPHYMAS" then
											if SN == "CHAMPIONCDWILLTOPHYMIT" then
												return 1.5;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 1;
									end
								elseif SN > "CHAMPIONCDWILLTORESIST" then
									if SN < "CHICKENCDCALCTYPENONPHYMIT" then
										if SN < "CHICKENCANBLOCK" then
											if SN == "CHAMPIONCDWILLTOTACMIT" then
												return 1.5;
											else
												return 0;
											end
										elseif SN > "CHICKENCANBLOCK" then
											if SN == "CHICKENCDCALCTYPECOMPHYMIT" then
												return 14;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "CHICKENCDCALCTYPENONPHYMIT" then
										if SN < "CHICKENCDHASPOWER" then
											if SN == "CHICKENCDCALCTYPETACMIT" then
												return 27;
											else
												return 0;
											end
										elseif SN > "CHICKENCDHASPOWER" then
											if SN == "CHISELCRITHITH" then
												if Lm <= 140 then
													return CalcStat("U371LegacyStatFix",L,"ChiselCritHitHOld");
												else
													return CalcStat("ChiselCritHitH",140);
												end
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 14;
									end
								else
									return 1;
								end
							else
								return 1;
							end
						elseif SN > "CHISELCRITHITHOLD" then
							if SN < "CLASSBASEICMRM" then
								if SN < "CHPSTALWBLADEVITALITY" then
									if SN < "CHPCONTRBURNICPR" then
										if SN < "CHISELCRITHITLOLD" then
											if SN == "CHISELCRITHITL" then
												if Lm <= 140 then
													return CalcStat("U371LegacyStatFix",L,"ChiselCritHitLOld");
												else
													return CalcStat("ChiselCritHitL",140);
												end
											else
												return 0;
											end
										elseif SN > "CHISELCRITHITLOLD" then
											if SN == "CHP2HWPNBLOCK" then
												return CalcStat("BlockT",L,4);
											else
												return 0;
											end
										else
											if Lm <= 105 then
												return RoundDbl(16.16*L);
											else
												return CalcStat("ProgExtHighLinExpRnd",L,CalcStat("ChiselCritHitLOld",105));
											end
										end
									elseif SN > "CHPCONTRBURNICPR" then
										if SN < "CHPFLURRYINCRCRITHIT" then
											if SN == "CHPFINESSEINCREASE" then
												return CalcStat("FinesseT",L,CalcStat("Trait12345Choice",N)*0.4);
											else
												return 0;
											end
										elseif SN > "CHPFLURRYINCRCRITHIT" then
											if SN == "CHPMIGHTINCREASE" then
												return CalcStat("MightT",L,CalcStat("Trait567810Choice",N)*0.4);
											else
												return 0;
											end
										else
											return CalcStat("CritHitT",L,2.4);
										end
									else
										return CalcStat("ICPRT",L,0.4);
									end
								elseif SN > "CHPSTALWBLADEVITALITY" then
									if SN < "CLASSBASEAGILITYM" then
										if SN < "CLASSBASEAGILITYH" then
											if SN == "CHPUNBREAKTACMIT" then
												return CalcStat("TacMitT",L,0.4);
											else
												return 0;
											end
										elseif SN > "CLASSBASEAGILITYH" then
											if SN == "CLASSBASEAGILITYL" then
												return CalcStat("BaseAgility",L,0.5);
											else
												return 0;
											end
										else
											return CalcStat("BaseAgility",L,1.5);
										end
									elseif SN > "CLASSBASEAGILITYM" then
										if SN < "CLASSBASEICMRH" then
											if SN == "CLASSBASEFATE" then
												return CalcStat("BaseFate",L);
											else
												return 0;
											end
										elseif SN > "CLASSBASEICMRH" then
											if SN == "CLASSBASEICMRL" then
												return 0.15;
											else
												return 0;
											end
										else
											return 0.2;
										end
									else
										return CalcStat("BaseAgility",L,1.0);
									end
								else
									return CalcStat("VitalityT",L,CalcStat("Trait567810Choice",N)*0.4);
								end
							elseif SN > "CLASSBASEICMRM" then
								if SN < "CLASSBASENCMRL" then
									if SN < "CLASSBASEMIGHTL" then
										if SN < "CLASSBASEICPRADJ" then
											if SN == "CLASSBASEICPR" then
												return StatLinInter("PntMPClassBaseICPR","ClassBasePowerRegenPntS","ProgBICPR","ClassBaseICPRAdj",L,N,99);
											else
												return 0;
											end
										elseif SN > "CLASSBASEICPRADJ" then
											if SN == "CLASSBASEMIGHTH" then
												return CalcStat("BaseMight",L,1.5);
											else
												return 0;
											end
										else
											if Lm <= 1 then
												return 1.5*N;
											elseif Lm <= 20 then
												return 1.1*N;
											else
												return N;
											end
										end
									elseif SN > "CLASSBASEMIGHTL" then
										if SN < "CLASSBASEMORALE" then
											if SN == "CLASSBASEMIGHTM" then
												return CalcStat("BaseMight",L,1.0);
											else
												return 0;
											end
										elseif SN > "CLASSBASEMORALE" then
											if SN == "CLASSBASENCMRH" then
												return 2;
											else
												return 0;
											end
										else
											return CalcStat("BaseMorale",L);
										end
									else
										return CalcStat("BaseMight",L,0.5);
									end
								elseif SN > "CLASSBASENCMRL" then
									if SN < "CLASSBASEPOWER" then
										if SN < "CLASSBASENCPR" then
											if SN == "CLASSBASENCMRM" then
												return 1;
											else
												return 0;
											end
										elseif SN > "CLASSBASENCPR" then
											if SN == "CLASSBASENCPRADJ" then
												if Lm <= 1 then
													return 1.5*N;
												elseif Lm <= 20 then
													return 1.1*N;
												else
													return N;
												end
											else
												return 0;
											end
										else
											return StatLinInter("PntMPClassBaseNCPR","ClassBasePowerRegenPntS","ProgBNCPR","ClassBaseNCPRAdj",L,N,99);
										end
									elseif SN > "CLASSBASEPOWER" then
										if SN < "CLASSBASEVITALITY" then
											if SN == "CLASSBASEPOWERREGENPNTS" then
												return {{1,20,50,60,65,75,85,95,100,105,115,120,130,140,150},{1,20,50,60,65,75,85,95,100,105,115,120,130,140,150}};
											else
												return 0;
											end
										elseif SN > "CLASSBASEVITALITY" then
											if SN == "CLASSBASEWILLH" then
												return CalcStat("BaseWill",L,1.5);
											else
												return 0;
											end
										else
											return CalcStat("BaseVitality",L);
										end
									else
										return CalcStat("BasePower",L);
									end
								else
									return 1;
								end
							else
								return 0.175;
							end
						else
							if Lm <= 105 then
								return RoundDbl(24.24*L);
							else
								return CalcStat("ProgExtHighLinExpRnd",L,CalcStat("ChiselCritHitHOld",105));
							end
						end
					elseif SN > "CLASSBASEWILLL" then
						if SN < "COMBATDAMAGEMODPETS" then
							if SN < "COMBATBASETACHPSBYLEVELMAX" then
								if SN < "COMBATBASELQTYMP" then
									if SN < "COMBATBASECAT" then
										if SN < "CLOTHARMOUR" then
											if SN == "CLASSBASEWILLM" then
												return CalcStat("BaseWill",L,1.0);
											else
												return 0;
											end
										elseif SN > "CLOTHARMOUR" then
											if SN == "COMBATBASE" then
												return CalcStat("CombatBaseCat",WpnCodeIndex(C,1),L)*CalcStat("CombatBaseTypeMP",WpnCodeIndex(C,2))*CalcStat("CombatBaseQtyMPCat",WpnCodeIndex(C,1),WpnCodeIndex(C,3));
											else
												return 0;
											end
										else
											if Lm <= 50 then
												return L;
											else
												return 50;
											end
										end
									elseif SN > "COMBATBASECAT" then
										if SN < "COMBATBASEHQTYMP" then
											if SN == "COMBATBASEH" then
												return 1.0*CalcStat("CombatBasePhyDPS",L)*1.08;
											else
												return 0;
											end
										elseif SN > "COMBATBASEHQTYMP" then
											if SN == "COMBATBASEL" then
												return 0.9*CalcStat("CombatBasePhyDPS",L)*1.08;
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											else
												return DataTableValue({1,1.02,1.04,1.08,1.12},L);
											end
										end
									else
										if Lm <= 0 then
											return 0;
										elseif Lm <= 1 then
											return CalcStat("CombatBaseH",N);
										else
											return CalcStat("CombatBaseL",N);
										end
									end
								elseif SN > "COMBATBASELQTYMP" then
									if SN < "COMBATBASETACDPSBYLEVEL" then
										if SN < "COMBATBASEQTYMPCAT" then
											if SN == "COMBATBASEPHYDPS" then
												if Lm <= 50 then
													return LinFmod(1,2,20,1,50,L);
												elseif Lm <= 60 then
													return LinFmod(1,20,26.6,50,60,L);
												elseif Lm <= 65 then
													return LinFmod(1,26.6,29.1,60,65,L);
												elseif Lm <= 75 then
													return LinFmod(1,29.1,39,65,75,L);
												elseif Lm <= 125 then
													return LinFmod(1,39,52,75,125,L);
												elseif Lm <= 175 then
													return LinFmod(1,52,69,125,175,L);
												elseif Lm <= 200 then
													return LinFmod(1,69,86,175,200,L);
												elseif Lm <= 222 then
													return LinFmod(1,86,108,200,222,L);
												elseif Lm <= 300 then
													return LinFmod(1,108,108,222,300,L);
												elseif Lm <= 350 then
													return LinFmod(1,119,144,301,350,L);
												elseif Lm <= 400 then
													return LinFmod(1,158,180,351,400,L);
												elseif Lm <= 450 then
													return LinFmod(1,198,239,401,450,L);
												elseif Lm <= 500 then
													return LinFmod(1,263,360,451,500,L);
												elseif Lm <= 550 then
													return LinFmod(1,400,540,501,550,L);
												elseif Lm <= 600 then
													return LinFmod(1,590,810,551,600,L);
												elseif Lm <= 650 then
													return RoundDblDown(RoundDblUp((L-50)/5.5)*36.7-2811,-1);
												else
													return CalcStat("CombatBasePhyDPS",650);
												end
											else
												return 0;
											end
										elseif SN > "COMBATBASEQTYMPCAT" then
											if SN == "COMBATBASETACDPS" then
												if Lm <= 47 then
													return LinFmod(1,0.5,0.5,1,47,L);
												elseif Lm <= 50 then
													return LinFmod(1,0.5,0.8,47,50,L);
												elseif Lm <= 51 then
													return LinFmod(1,1,1,51,51,L);
												elseif Lm <= 60 then
													return LinFmod(1,1.32,6.6,52,60,L);
												elseif Lm <= 65 then
													return LinFmod(1,6.6,9.1,60,65,L);
												elseif Lm <= 75 then
													return LinFmod(1,9.1,19,65,75,L);
												elseif Lm <= 125 then
													return LinFmod(1,19,32,75,125,L);
												elseif Lm <= 175 then
													return LinFmod(1,32,49,125,175,L);
												elseif Lm <= 200 then
													return LinFmod(1,49,66,175,200,L);
												elseif Lm <= 222 then
													return LinFmod(1,66,88,200,222,L);
												elseif Lm <= 299 then
													return LinFmod(1,88,88,222,299,L);
												elseif Lm <= 349 then
													return LinFmod(1,99,124,300,349,L);
												elseif Lm <= 399 then
													return LinFmod(1,138,160,350,399,L);
												elseif Lm <= 449 then
													return LinFmod(1,178,219,400,449,L);
												elseif Lm <= 499 then
													return LinFmod(1,243,340,450,499,L);
												elseif Lm <= 549 then
													return LinFmod(1,380,520,500,549,L);
												elseif Lm <= 599 then
													return LinFmod(1,570,790,550,599,L);
												elseif Lm <= 649 then
													return RoundDblDown(RoundDblUp((L-49)/5.5)*36.7-2831,-1);
												else
													return CalcStat("CombatBaseTacDPS",649);
												end
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											elseif Lm <= 1 then
												return CalcStat("CombatBaseHQtyMP",N);
											else
												return CalcStat("CombatBaseLQtyMP",N);
											end
										end
									elseif SN > "COMBATBASETACDPSBYLEVEL" then
										if SN < "COMBATBASETACHPS" then
											if SN == "COMBATBASETACDPSBYLEVELMAX" then
												return 20;
											else
												return 0;
											end
										elseif SN > "COMBATBASETACHPS" then
											if SN == "COMBATBASETACHPSBYLEVEL" then
												if Lm <= 46 then
													return CalcStat("CombatBaseTacHPSCurves",L);
												else
													return CalcStat("CombatBaseTacHPSByLevelMax",L);
												end
											else
												return 0;
											end
										else
											if Lm <= 46 then
												return 0;
											elseif Lm <= 49 then
												return CalcStat("CombatBaseTacHPSCurves",L)-CalcStat("CombatBaseTacHPSByLevelMax",L);
											elseif Lm <= 55 then
												return 0.5;
											elseif Lm <= 599 then
												return CalcStat("CommonTacHPS",L)-CalcStat("CombatBaseTacHPSByLevelMax",L);
											elseif Lm <= 649 then
												return (RoundDblUp((4*L+2)/22)*678-RoundDblUp((L+1)/22))*0.175-11734.1-CalcStat("CombatBaseTacHPSByLevelMax",L);
											else
												return CalcStat("CombatBaseTacHPS",649);
											end
										end
									else
										if Lm <= 50 then
											return LinFmod(1,2,CalcStat("CombatBaseTacDPSByLevelMax",L),1,50,L);
										else
											return CalcStat("CombatBaseTacDPSByLevelMax",L);
										end
									end
								else
									return CalcStat("CombatBaseHQtyMP",L);
								end
							elseif SN > "COMBATBASETACHPSBYLEVELMAX" then
								if SN < "COMBATDAMAGEMODHEALTHADJ" then
									if SN < "COMBATBASETYPEMP" then
										if SN < "COMBATBASETACHPSLVLTOILVL" then
											if SN == "COMBATBASETACHPSCURVES" then
												if Lm <= 25 then
													return -0.0033215*L*L+0.2470730225*L+1.7562484775;
												else
													return -0.003714298*L*L+0.254286886*L+1.82140064;
												end
											else
												return 0;
											end
										elseif SN > "COMBATBASETACHPSLVLTOILVL" then
											if SN == "COMBATBASETACHPSNOCLASS" then
												return CalcStat("CombatBaseTacHPSByLevel",L)+CalcStat("CombatBaseTacHPS",CalcStat("CombatBaseTacHPSLvlToILvl",L));
											else
												return 0;
											end
										else
											if Lm <= 75 then
												return LinFmod(1,1,75,1,75,L);
											elseif Lm <= 100 then
												return LinFmod(1,75,200,75,100,L);
											elseif Lm <= 104 then
												return RoundDbl(LinFmod(1,201.3,214.3,101,104,L));
											elseif Lm <= 105 then
												return 222;
											else
												return RoundDbl(CalcStat("LvlToILvl",L));
											end
										end
									elseif SN > "COMBATBASETYPEMP" then
										if SN < "COMBATDAMAGEMODENERGY" then
											if SN == "COMBATDAMAGEMOD" then
												return StatLinInter("PntMPCombatDamageMod","TraitPntSVital","ProgBCombatDamageMod","",L,N,2);
											else
												return 0;
											end
										elseif SN > "COMBATDAMAGEMODENERGY" then
											if SN == "COMBATDAMAGEMODHEALTH" then
												return StatLinInter("PntMPCombatDamageMod","TraitPntSVital","ProgBHealth","CombatDamageModHealthAdj",L,N,2);
											else
												return 0;
											end
										else
											return StatLinInter("PntMPCombatDamageMod","TraitPntSVital","ProgBEnergy","",L,N,2);
										end
									else
										if Lm <= 0 then
											return 0;
										else
											return DataTableValue({1,1.4,1.4},L);
										end
									end
								elseif SN > "COMBATDAMAGEMODHEALTHADJ" then
									if SN < "COMBATDAMAGEMODHEALTHMEDIUMADJ" then
										if SN < "COMBATDAMAGEMODHEALTHLOWADJ" then
											if SN == "COMBATDAMAGEMODHEALTHLOW" then
												return StatLinInter("PntMPCombatDamageMod","TraitPntSVital","ProgBHealth","CombatDamageModHealthLowAdj",L,N,99);
											else
												return 0;
											end
										elseif SN > "COMBATDAMAGEMODHEALTHLOWADJ" then
											if SN == "COMBATDAMAGEMODHEALTHMEDIUM" then
												return StatLinInter("PntMPCombatDamageMod","TraitPntSVital","ProgBHealth","CombatDamageModHealthMediumAdj",L,N,99);
											else
												return 0;
											end
										else
											if Lm <= 1 then
												return 0.144*N;
											elseif Lm <= 25 then
												return 0.324*N;
											elseif Lm <= 50 then
												return 0.576*N;
											else
												return 0.9*N;
											end
										end
									elseif SN > "COMBATDAMAGEMODHEALTHMEDIUMADJ" then
										if SN < "COMBATDAMAGEMODNERFEDADJ" then
											if SN == "COMBATDAMAGEMODNERFED" then
												return StatLinInter("PntMPCombatDamageMod","TraitPntSVital","ProgBCombatDamageMod","CombatDamageModNerfedAdj",L,N,2);
											else
												return 0;
											end
										elseif SN > "COMBATDAMAGEMODNERFEDADJ" then
											if SN == "COMBATDAMAGEMODNPCS" then
												return StatLinInter("PntMPCombatDamageMod","TraitPntSVital","ProgBCombatDamageMod","",L,N,99);
											else
												return 0;
											end
										else
											if Lm <= 141 then
												return 1;
											else
												return 0.82;
											end
										end
									else
										if Lm <= 1 then
											return 0.36*N;
										elseif Lm <= 25 then
											return 0.54*N;
										elseif Lm <= 50 then
											return 0.72*N;
										else
											return 0.9*N;
										end
									end
								else
									if Lm <= 141 then
										return 1;
									else
										return 0.63;
									end
								end
							else
								return 5.659142856;
							end
						elseif SN > "COMBATDAMAGEMODPETS" then
							if SN < "CPTCRITDEF" then
								if SN < "CONSTSTATC" then
									if SN < "COMBATDAMAGEMODPLAYERSADJ" then
										if SN < "COMBATDAMAGEMODPETSRND" then
											if SN == "COMBATDAMAGEMODPETSADJ" then
												if Lm <= 1 then
													return N;
												elseif Lm <= 25 then
													return 0.4*N;
												elseif Lm <= 50 then
													return 0.5*N;
												elseif Lm <= 60 then
													return 0.6*N;
												elseif Lm <= 65 then
													return 0.7*N;
												elseif Lm <= 75 then
													return 0.8*N;
												elseif Lm <= 85 then
													return 0.85*N;
												elseif Lm <= 95 then
													return 0.9*N;
												elseif Lm <= 100 then
													return 0.95*N;
												else
													return N;
												end
											else
												return 0;
											end
										elseif SN > "COMBATDAMAGEMODPETSRND" then
											if SN == "COMBATDAMAGEMODPLAYERS" then
												return StatLinInter("PntMPCombatDamageMod","TraitPntSVital","ProgBCombatDamageMod","CombatDamageModPlayersAdj",L,N,99);
											else
												return 0;
											end
										else
											return StatLinInter("PntMPCombatDamageMod","TraitPntSVital","ProgBCombatDamageMod","CombatDamageModPetsAdj",L,N,2);
										end
									elseif SN > "COMBATDAMAGEMODPLAYERSADJ" then
										if SN < "COMMONTACHPS" then
											if SN == "COMBATINHEAL" then
												return CalcStat("InHeal",L,2.0);
											else
												return 0;
											end
										elseif SN > "COMMONTACHPS" then
											if SN == "COMMONTACHPSITEMPNTS" then
												return {{1,50,60,65,75,125,175,200,222,299,300,349,350,399,400,449,450,499,500,549,550,599},{1,50,60,65,75,85,95,100,105,105,106,115,116,120,121,130,131,140,141,150,151,160}};
											else
												return 0;
											end
										else
											return StatLinInter("PntMPTacHPS","CommonTacHPSItemPntS","ProgBTacHPS","",L,N,99);
										end
									else
										if Lm <= 1 then
											return 0.8*N;
										elseif Lm <= 25 then
											return 0.9*N;
										else
											return N;
										end
									end
								elseif SN > "CONSTSTATC" then
									if SN < "CPTCOVFATE" then
										if SN < "CPTBLADEPHYMAS" then
											if SN == "CPTBLADECRITDEF" then
												return CalcStat("CritDefT",L,0.8);
											else
												return 0;
											end
										elseif SN > "CPTBLADEPHYMAS" then
											if SN == "CPTBLADETACMAS" then
												return CalcStat("TacMasT",L,0.8);
											else
												return 0;
											end
										else
											return CalcStat("PhyMasT",L,1.2);
										end
									elseif SN > "CPTCOVFATE" then
										if SN < "CPTCOVPHYMIT" then
											if SN == "CPTCOVMAIN" then
												return CalcStat("MainT",L,0.4);
											else
												return 0;
											end
										elseif SN > "CPTCOVPHYMIT" then
											if SN == "CPTCOVVITALITY" then
												return CalcStat("VitalityT",L,0.4);
											else
												return 0;
											end
										else
											return CalcStat("PhyMitT",L,2.4);
										end
									else
										return CalcStat("FateT",L,0.4);
									end
								else
									return CalcStat(C,1,L);
								end
							elseif SN > "CPTCRITDEF" then
								if SN < "CPTSONGPHYMAS" then
									if SN < "CPTSHIELDCRITDEF" then
										if SN < "CPTIDOMEMAIN" then
											if SN == "CPTIDOMEFATE" then
												return CalcStat("FateT",L,0.4);
											else
												return 0;
											end
										elseif SN > "CPTIDOMEMAIN" then
											if SN == "CPTIDOMEVITALITY" then
												return CalcStat("VitalityT",L,0.4);
											else
												return 0;
											end
										else
											return CalcStat("MainT",L,0.4);
										end
									elseif SN > "CPTSHIELDCRITDEF" then
										if SN < "CPTSHIELDTACMAS" then
											if SN == "CPTSHIELDPHYMAS" then
												return CalcStat("PhyMasT",L,0.8);
											else
												return 0;
											end
										elseif SN > "CPTSHIELDTACMAS" then
											if SN == "CPTSONGCRITDEF" then
												return CalcStat("CritDefT",L,0.8);
											else
												return 0;
											end
										else
											return CalcStat("TacMasT",L,0.8);
										end
									else
										return CalcStat("CritDefT",L,1.2);
									end
								elseif SN > "CPTSONGPHYMAS" then
									if SN < "CREEPAUDACITYCCDP" then
										if SN < "CPTSTANDALONEPHYMAS" then
											if SN == "CPTSONGTACMAS" then
												return CalcStat("TacMasT",L,1.2);
											else
												return 0;
											end
										elseif SN > "CPTSTANDALONEPHYMAS" then
											if SN == "CPTSTANDALONETACMAS" then
												return CalcStat("TacMasT",L,0.8);
											else
												return 0;
											end
										else
											return CalcStat("PhyMasT",L,1.2);
										end
									elseif SN > "CREEPAUDACITYCCDP" then
										if SN < "CREEPAUDACITYCOSTBASE" then
											if SN == "CREEPAUDACITYCOST" then
												return CalcStat("CreepAudacityCostBase",L)*25;
											else
												return 0;
											end
										elseif SN > "CREEPAUDACITYCOSTBASE" then
											if SN == "CREEPAUDACITYDMGP" then
												if Lm <= 0 then
													return 0;
												elseif Lm <= 10 then
													return LinFmod(1,1,1.2,1,10,L);
												elseif Lm <= 36 then
													return LinFmod(1,1.2,1.25,10,36,L);
												elseif Lm <= 41 then
													return LinFmod(1,1.25,1.3,36,41,L);
												elseif Lm <= 60 then
													return LinFmod(1,1.3,1.25,41,60,L);
												else
													return CalcStat("CreepAudacityDmgP",60);
												end
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											elseif Lm <= 2 then
												return 2*L;
											elseif Lm <= 9 then
												return 2*L-1;
											elseif Lm <= 15 then
												return 3*L;
											elseif Lm <= 25 then
												return 6*L;
											elseif Lm <= 29 then
												return 9*L;
											elseif Lm <= 36 then
												return 300;
											else
												return 0;
											end
										end
									else
										if Lm <= 0 then
											return 0;
										elseif Lm <= 16 then
											return 0.5;
										else
											return 0.4;
										end
									end
								else
									return CalcStat("PhyMasT",L,0.8);
								end
							else
								return CalcStat("CritDef",L,0.6);
							end
						else
							return StatLinInter("PntMPCombatDamageMod","TraitPntSVital","ProgBCombatDamageMod","CombatDamageModPetsAdj",L,N,99);
						end
					else
						return CalcStat("BaseWill",L,0.5);
					end
				else
					return 14;
				end
			else
				return -CalcStat("PhyMitT",L,3);
			end
		elseif SN > "CREEPAUDACITYMELDMGP" then
			if SN < "HUNTERCDAGILITYTOOUTHEAL" then
				if SN < "FINESSEPRATPB" then
					if SN < "DEVHITPRATPCAP" then
						if SN < "CRITHIT" then
							if SN < "CREEPBATPROMTACDMGP" then
								if SN < "CREEPBATPROMDMGP" then
									if SN < "CREEPAUDACITYRNGDMGP" then
										if SN > "CREEPAUDACITYMELREDP" then
											if SN == "CREEPAUDACITYREDP" then
												if Lm <= 0 then
													return 0;
												elseif Lm <= 10 then
													return LinFmod(1,0.55,0.55,1,10,L);
												elseif Lm <= 36 then
													return LinFmod(1,0.55,0.55,10,36,L);
												elseif Lm <= 41 then
													return LinFmod(1,0.55,0.55,36,41,L);
												elseif Lm <= 60 then
													return LinFmod(1,0.55,0.55,41,60,L);
												else
													return CalcStat("CreepAudacityRedP",60);
												end
											else
												return 0;
											end
										elseif SN == "CREEPAUDACITYMELREDP" then
											return CalcStat("CreepAudacityRedP",L);
										else
											return 0;
										end
									elseif SN > "CREEPAUDACITYRNGDMGP" then
										if SN < "CREEPAUDACITYTACDMGP" then
											if SN == "CREEPAUDACITYRNGREDP" then
												return CalcStat("CreepAudacityRedP",L);
											else
												return 0;
											end
										elseif SN > "CREEPAUDACITYTACDMGP" then
											if SN == "CREEPAUDACITYTACREDP" then
												return CalcStat("CreepAudacityRedP",L);
											else
												return 0;
											end
										else
											return CalcStat("CreepAudacityDmgP",L);
										end
									else
										return CalcStat("CreepAudacityDmgP",L);
									end
								elseif SN > "CREEPBATPROMDMGP" then
									if SN < "CREEPBATPROMMELDMGP" then
										if SN < "CREEPBATPROMHEALTHP" then
											if SN == "CREEPBATPROMFINESSE" then
												return 0;
											else
												return 0;
											end
										elseif SN > "CREEPBATPROMHEALTHP" then
											if SN == "CREEPBATPROMINHEALP" then
												return 0;
											else
												return 0;
											end
										else
											return CalcStat("CreepBatPromVitalP",L);
										end
									elseif SN > "CREEPBATPROMMELDMGP" then
										if SN < "CREEPBATPROMPOWERP" then
											if SN == "CREEPBATPROMOUTHEALP" then
												if Lm <= 0 then
													return 0;
												elseif Lm <= 5 then
													return LinFmod(1,0.02,0.1,1,5,L);
												elseif Lm <= 10 then
													return LinFmod(1,0.1,0.15,5,10,L);
												elseif Lm <= 15 then
													return LinFmod(1,0.15,0.2,10,15,L);
												else
													return CalcStat("CreepBatPromOutHealP",15);
												end
											else
												return 0;
											end
										elseif SN > "CREEPBATPROMPOWERP" then
											if SN == "CREEPBATPROMRNGDMGP" then
												return CalcStat("CreepBatPromDmgP",L);
											else
												return 0;
											end
										else
											return CalcStat("CreepBatPromVitalP",L);
										end
									else
										return CalcStat("CreepBatPromDmgP",L);
									end
								else
									if Lm <= 0 then
										return 0;
									elseif Lm <= 5 then
										return LinFmod(1,0.005,0.02,1,5,L);
									elseif Lm <= 10 then
										return LinFmod(1,0.02,0.045,5,10,L);
									elseif Lm <= 15 then
										return LinFmod(1,0.045,0.075,10,15,L);
									else
										return CalcStat("CreepBatPromDmgP",15);
									end
								end
							elseif SN > "CREEPBATPROMTACDMGP" then
								if SN < "CRITDEFPPRAT" then
									if SN < "CREEPPROGB" then
										if SN < "CREEPPNTS" then
											if SN == "CREEPBATPROMVITALP" then
												if Lm <= 0 then
													return 0;
												elseif Lm <= 5 then
													return LinFmod(1,1.02,1.1,1,5,L);
												elseif Lm <= 10 then
													return LinFmod(1,1.1,1.15,5,10,L);
												elseif Lm <= 15 then
													return LinFmod(1,1.15,1.2,10,15,L);
												else
													return CalcStat("CreepBatPromVitalP",15);
												end
											else
												return 0;
											end
										elseif SN > "CREEPPNTS" then
											if SN == "CREEPPNTSOLD" then
												return {{1,140},{1,150}};
											else
												return 0;
											end
										else
											return {{1,150},{1,150}};
										end
									elseif SN > "CREEPPROGB" then
										if SN < "CRITDEFC" then
											if SN == "CRITDEF" then
												return StatLinInter("PntMPCritDef","ItemPntS","ProgBCritDef","AdjUmbarItem",L,N,0);
											else
												return 0;
											end
										elseif SN > "CRITDEFC" then
											if SN == "CRITDEFPBONUS" then
												return 0;
											else
												return 0;
											end
										else
											return StatLinInter("PntMPCritDefC","CreepPntS","ProgBCritDefC","",L,N,0);
										end
									else
										return LinFmod(1,0.01,1,1,CalcStat("LevelCap",L),L);
									end
								elseif SN > "CRITDEFPPRAT" then
									if SN < "CRITDEFPRATPC" then
										if SN < "CRITDEFPRATPA" then
											if SN == "CRITDEFPRATP" then
												return CalcPercAB(CalcStat("CritDefPRatPA",L),CalcStat("CritDefPRatPB",L),CalcStat("CritDefPRatPCap",L),N);
											else
												return 0;
											end
										elseif SN > "CRITDEFPRATPA" then
											if SN == "CRITDEFPRATPB" then
												return CalcStat("BRatRounded",L,"BRatStandard");
											else
												return 0;
											end
										else
											return 240;
										end
									elseif SN > "CRITDEFPRATPC" then
										if SN < "CRITDEFPRATPCAPR" then
											if SN == "CRITDEFPRATPCAP" then
												return 80;
											else
												return 0;
											end
										elseif SN > "CRITDEFPRATPCAPR" then
											if SN == "CRITDEFT" then
												return StatLinInter("PntMPCritDef","TraitPntS","ProgBCritDef","AdjUmbarTrait",L,N,0);
											else
												return 0;
											end
										else
											return CalcStat("CritDefPRatPB",L)*CalcStat("CritDefPRatPC",L);
										end
									else
										return 0.5;
									end
								else
									return CalcRatAB(CalcStat("CritDefPRatPA",L),CalcStat("CritDefPRatPB",L),CalcStat("CritDefPRatPCapR",L),N);
								end
							else
								return CalcStat("CreepBatPromDmgP",L);
							end
						elseif SN > "CRITHIT" then
							if SN < "CRITMAGNPRATPB" then
								if SN < "CRITHITPRATPC" then
									if SN < "CRITHITPPRAT" then
										if SN < "CRITHITOLD" then
											if SN == "CRITHITC" then
												return StatLinInter("PntMPCritHitC","CreepPntS","ProgBCritHitC","",L,N,0);
											else
												return 0;
											end
										elseif SN > "CRITHITOLD" then
											if SN == "CRITHITPBONUS" then
												return 0;
											else
												return 0;
											end
										else
											return CalcStat("CritHit",L,N);
										end
									elseif SN > "CRITHITPPRAT" then
										if SN < "CRITHITPRATPA" then
											if SN == "CRITHITPRATP" then
												return CalcPercAB(CalcStat("CritHitPRatPA",L),CalcStat("CritHitPRatPB",L),CalcStat("CritHitPRatPCap",L),N);
											else
												return 0;
											end
										elseif SN > "CRITHITPRATPA" then
											if SN == "CRITHITPRATPB" then
												return CalcStat("BRatRounded",L,"BRatExtra");
											else
												return 0;
											end
										else
											return 75;
										end
									else
										return CalcRatAB(CalcStat("CritHitPRatPA",L),CalcStat("CritHitPRatPB",L),CalcStat("CritHitPRatPCapR",L),N);
									end
								elseif SN > "CRITHITPRATPC" then
									if SN < "CRITMAGNPBONUS" then
										if SN < "CRITHITPRATPCAPR" then
											if SN == "CRITHITPRATPCAP" then
												return 25;
											else
												return 0;
											end
										elseif SN > "CRITHITPRATPCAPR" then
											if SN == "CRITHITT" then
												return StatLinInter("PntMPCritHit","TraitPntS","ProgBCritHit","AdjUmbarTrait",L,N,0);
											else
												return 0;
											end
										else
											return CalcStat("CritHitPRatPB",L)*CalcStat("CritHitPRatPC",L);
										end
									elseif SN > "CRITMAGNPBONUS" then
										if SN < "CRITMAGNPRATP" then
											if SN == "CRITMAGNPPRAT" then
												return CalcRatAB(CalcStat("CritMagnPRatPA",L),CalcStat("CritMagnPRatPB",L),CalcStat("CritMagnPRatPCapR",L),N);
											else
												return 0;
											end
										elseif SN > "CRITMAGNPRATP" then
											if SN == "CRITMAGNPRATPA" then
												return 225;
											else
												return 0;
											end
										else
											return CalcPercAB(CalcStat("CritMagnPRatPA",L),CalcStat("CritMagnPRatPB",L),CalcStat("CritMagnPRatPCap",L),N);
										end
									else
										return 0;
									end
								else
									return 0.5;
								end
							elseif SN > "CRITMAGNPRATPB" then
								if SN < "DEFILERCDCALCTYPETACMIT" then
									if SN < "CRYRESISTT" then
										if SN < "CRITMAGNPRATPCAP" then
											if SN == "CRITMAGNPRATPC" then
												return 0.5;
											else
												return 0;
											end
										elseif SN > "CRITMAGNPRATPCAP" then
											if SN == "CRITMAGNPRATPCAPR" then
												return CalcStat("CritMagnPRatPB",L)*CalcStat("CritMagnPRatPC",L);
											else
												return 0;
											end
										else
											return 75;
										end
									elseif SN > "CRYRESISTT" then
										if SN < "DEFILERCDCALCTYPECOMPHYMIT" then
											if SN == "DEFILERCANBLOCK" then
												return 1;
											else
												return 0;
											end
										elseif SN > "DEFILERCDCALCTYPECOMPHYMIT" then
											if SN == "DEFILERCDCALCTYPENONPHYMIT" then
												return 14;
											else
												return 0;
											end
										else
											return 13;
										end
									else
										return CalcStat("ResistAddT",L,N);
									end
								elseif SN > "DEFILERCDCALCTYPETACMIT" then
									if SN < "DEVHITPRATP" then
										if SN < "DEVHITPBONUS" then
											if SN == "DEFILERCDHASPOWER" then
												return 1;
											else
												return 0;
											end
										elseif SN > "DEVHITPBONUS" then
											if SN == "DEVHITPPRAT" then
												return CalcRatAB(CalcStat("DevHitPRatPA",L),CalcStat("DevHitPRatPB",L),CalcStat("DevHitPRatPCapR",L),N);
											else
												return 0;
											end
										else
											return 0;
										end
									elseif SN > "DEVHITPRATP" then
										if SN < "DEVHITPRATPB" then
											if SN == "DEVHITPRATPA" then
												return 30;
											else
												return 0;
											end
										elseif SN > "DEVHITPRATPB" then
											if SN == "DEVHITPRATPC" then
												return 0.5;
											else
												return 0;
											end
										else
											return CalcStat("BRatRounded",L,"BRatDevHit");
										end
									else
										return CalcPercAB(CalcStat("DevHitPRatPA",L),CalcStat("DevHitPRatPB",L),CalcStat("DevHitPRatPCap",L),N);
									end
								else
									return 27;
								end
							else
								return CalcStat("BRatRounded",L,"BRatCritMagn");
							end
						else
							return StatLinInter("PntMPCritHit","ItemPntS","ProgBCritHit","AdjUmbarItem",L,N,0);
						end
					elseif SN > "DEVHITPRATPCAP" then
						if SN < "ELFFADINGFIRSTBORNFATE" then
							if SN < "DWARFRDTRAITICPR" then
								if SN < "DWARFLOSTDWARFKDSFATE" then
									if SN < "DMGTYPEMIT" then
										if SN > "DEVHITPRATPCAPR" then
											if SN == "DISEASERESISTT" then
												return CalcStat("ResistAddT",L,N);
											else
												return 0;
											end
										elseif SN == "DEVHITPRATPCAPR" then
											return CalcStat("DevHitPRatPB",L)*CalcStat("DevHitPRatPC",L);
										else
											return 0;
										end
									elseif SN > "DMGTYPEMIT" then
										if SN < "DWARFENDURVITALITY" then
											if SN == "DMGTYPEMITT" then
												return StatLinInter("PntMPDmgTypeMit","TraitPntS","ProgBMitigation","AdjUmbarTraitMit",L,N,0);
											else
												return 0;
											end
										elseif SN > "DWARFENDURVITALITY" then
											if SN == "DWARFFATEFULDWARFFATE" then
												return CalcStat("FateT",L,1.0);
											else
												return 0;
											end
										else
											return CalcStat("VitalityT",L,1.0);
										end
									else
										return StatLinInter("PntMPDmgTypeMit","ItemPntS","ProgBMitigation","AdjUmbarItemMit",L,N,0);
									end
								elseif SN > "DWARFLOSTDWARFKDSFATE" then
									if SN < "DWARFRDPSVTWONAME" then
										if SN < "DWARFRDPSVONENAME" then
											if SN == "DWARFRDPSVONEFATE" then
												return CalcStat("DwarfFatefulDwarfFate",L);
											else
												return 0;
											end
										elseif SN > "DWARFRDPSVONENAME" then
											if SN == "DWARFRDPSVTWOBLOCK" then
												return CalcStat("DwarfShieldBrwlBlock",L);
											else
												return 0;
											end
										else
											return "Fateful Dwarf";
										end
									elseif SN > "DWARFRDPSVTWONAME" then
										if SN < "DWARFRDTRAITFATE" then
											if SN == "DWARFRDTRAITAGILITY" then
												return CalcStat("DwarfStockyAgility",L);
											else
												return 0;
											end
										elseif SN > "DWARFRDTRAITFATE" then
											if SN == "DWARFRDTRAITICMR" then
												return CalcStat("DwarfUnwearBattleICMR",L);
											else
												return 0;
											end
										else
											return CalcStat("DwarfLostDwarfKdsFate",L);
										end
									else
										return "Shield Brawler";
									end
								else
									return -CalcStat("FateT",L,0.4);
								end
							elseif SN > "DWARFRDTRAITICPR" then
								if SN < "DWARFSTURDINESSMIGHT" then
									if SN < "DWARFRDTRAITPHYMITP" then
										if SN < "DWARFRDTRAITNCMR" then
											if SN == "DWARFRDTRAITMIGHT" then
												return CalcStat("DwarfSturdinessMight",L);
											else
												return 0;
											end
										elseif SN > "DWARFRDTRAITNCMR" then
											if SN == "DWARFRDTRAITNCPR" then
												return CalcStat("DwarfUnwearBattleNCPR",L);
											else
												return 0;
											end
										else
											return CalcStat("DwarfUnwearBattleNCMR",L);
										end
									elseif SN > "DWARFRDTRAITPHYMITP" then
										if SN < "DWARFSHIELDBRWLBLOCK" then
											if SN == "DWARFRDTRAITVITALITY" then
												return CalcStat("DwarfSturdinessVitality",L);
											else
												return 0;
											end
										elseif SN > "DWARFSHIELDBRWLBLOCK" then
											if SN == "DWARFSTOCKYAGILITY" then
												return CalcStat("AgilityT",L,0.4);
											else
												return 0;
											end
										else
											return CalcStat("BlockT",L,0.8);
										end
									else
										return CalcStat("DwarfSturdinessPhyMitP",L);
									end
								elseif SN > "DWARFSTURDINESSMIGHT" then
									if SN < "DWARFUNWEARBATTLEICPR" then
										if SN < "DWARFSTURDINESSVITALITY" then
											if SN == "DWARFSTURDINESSPHYMITP" then
												return 1;
											else
												return 0;
											end
										elseif SN > "DWARFSTURDINESSVITALITY" then
											if SN == "DWARFUNWEARBATTLEICMR" then
												return CalcStat("ICMRT",L,0.6);
											else
												return 0;
											end
										else
											return CalcStat("VitalityT",L,1.0);
										end
									elseif SN > "DWARFUNWEARBATTLEICPR" then
										if SN < "DWARFUNWEARBATTLENCPR" then
											if SN == "DWARFUNWEARBATTLENCMR" then
												return -CalcStat("NCMRT",L,0.4);
											else
												return 0;
											end
										elseif SN > "DWARFUNWEARBATTLENCPR" then
											if SN == "ELFAGILITYWOODSAGILITY" then
												return CalcStat("AgilityT",L,1.0);
											else
												return 0;
											end
										else
											return -CalcStat("NCPRT",L,0.4);
										end
									else
										return CalcStat("ICPRT",L,0.6);
									end
								else
									return CalcStat("MightT",L,1.0);
								end
							else
								return CalcStat("DwarfUnwearBattleICPR",L);
							end
						elseif SN > "ELFFADINGFIRSTBORNFATE" then
							if SN < "EVADEPRATPA" then
								if SN < "ELFRDTRAITNCMR" then
									if SN < "ELFRDPSVTWONAME" then
										if SN < "ELFRDPSVONEFATE" then
											if SN == "ELFFRIENDOFMANFATE" then
												return CalcStat("FateT",L,1.0);
											else
												return 0;
											end
										elseif SN > "ELFRDPSVONEFATE" then
											if SN == "ELFRDPSVONENAME" then
												return "Friend Of Man";
											else
												return 0;
											end
										else
											return CalcStat("ElfFriendOfManFate",L);
										end
									elseif SN > "ELFRDPSVTWONAME" then
										if SN < "ELFRDTRAITFATE" then
											if SN == "ELFRDTRAITAGILITY" then
												return CalcStat("ElfAgilityWoodsAgility",L);
											else
												return 0;
											end
										elseif SN > "ELFRDTRAITFATE" then
											if SN == "ELFRDTRAITMORALE" then
												return CalcStat("ElfSorrowFirstbornMorale",L);
											else
												return 0;
											end
										else
											return CalcStat("ElfFadingFirstbornFate",L);
										end
									else
										return "";
									end
								elseif SN > "ELFRDTRAITNCMR" then
									if SN < "EVADEC" then
										if SN < "ELFSORROWFIRSTBORNNCMR" then
											if SN == "ELFSORROWFIRSTBORNMORALE" then
												return -CalcStat("MoraleT",L,0.4);
											else
												return 0;
											end
										elseif SN > "ELFSORROWFIRSTBORNNCMR" then
											if SN == "EVADE" then
												return CalcStat("BPE",L,N);
											else
												return 0;
											end
										else
											return -CalcStat("NCMRT",L,0.4);
										end
									elseif SN > "EVADEC" then
										if SN < "EVADEPPRAT" then
											if SN == "EVADEPBONUS" then
												return CalcStat("BPEPBonus",L);
											else
												return 0;
											end
										elseif SN > "EVADEPPRAT" then
											if SN == "EVADEPRATP" then
												return CalcStat("BPEPRatP",L,N);
											else
												return 0;
											end
										else
											return CalcStat("BPEPPRat",L,N);
										end
									else
										return CalcStat("BPEC",L,N);
									end
								else
									return CalcStat("ElfSorrowFirstbornNCMR",L);
								end
							elseif SN > "EVADEPRATPA" then
								if SN < "FATET" then
									if SN < "EVADEPRATPCAPR" then
										if SN < "EVADEPRATPC" then
											if SN == "EVADEPRATPB" then
												return CalcStat("BPEPRatPB",L);
											else
												return 0;
											end
										elseif SN > "EVADEPRATPC" then
											if SN == "EVADEPRATPCAP" then
												return CalcStat("BPEPRatPCap",L);
											else
												return 0;
											end
										else
											return CalcStat("BPEPRatPC",L);
										end
									elseif SN > "EVADEPRATPCAPR" then
										if SN < "FATE" then
											if SN == "EVADET" then
												return CalcStat("BPET",L,N);
											else
												return 0;
											end
										elseif SN > "FATE" then
											if SN == "FATEC" then
												return RoundDblDown(StatLinInter("PntMPFateC","CreepPntS","ProgBFateC","",L,N,0));
											else
												return 0;
											end
										else
											return RoundDblDown(StatLinInter("PntMPFate","ItemPntSVital","ProgBFate","",L,N,0));
										end
									else
										return CalcStat("BPEPRatPCapR",L);
									end
								elseif SN > "FATET" then
									if SN < "FINESSEPBONUS" then
										if SN < "FINESSE" then
											if SN == "FEARRESISTT" then
												return CalcStat("ResistAddT",L,N);
											else
												return 0;
											end
										elseif SN > "FINESSE" then
											if SN == "FINESSEC" then
												return StatLinInter("PntMPFinesseC","CreepPntS","ProgBFinesseC","",L,N,0);
											else
												return 0;
											end
										else
											return StatLinInter("PntMPFinesse","ItemPntS","ProgBFinesse","AdjUmbarItem",L,N,0);
										end
									elseif SN > "FINESSEPBONUS" then
										if SN < "FINESSEPRATP" then
											if SN == "FINESSEPPRAT" then
												return CalcRatAB(CalcStat("FinessePRatPA",L),CalcStat("FinessePRatPB",L),CalcStat("FinessePRatPCapR",L),N);
											else
												return 0;
											end
										elseif SN > "FINESSEPRATP" then
											if SN == "FINESSEPRATPA" then
												return 150;
											else
												return 0;
											end
										else
											return CalcPercAB(CalcStat("FinessePRatPA",L),CalcStat("FinessePRatPB",L),CalcStat("FinessePRatPCap",L),N);
										end
									else
										return 0;
									end
								else
									return RoundDblDown(StatLinInter("PntMPFate","TraitPntSVital","ProgBFate","",L,N,0));
								end
							else
								return CalcStat("BPEPRatPA",L);
							end
						else
							return -CalcStat("FateT",L,0.4);
						end
					else
						return 10;
					end
				elseif SN > "FINESSEPRATPB" then
					if SN < "GUARDIANCDBASEVITALITY" then
						if SN < "FREEPBATPROMPOWERP" then
							if SN < "FOODNCPRM" then
								if SN < "FOODNCMRBASEPROG" then
									if SN < "FINESSEPRATPCAPR" then
										if SN > "FINESSEPRATPC" then
											if SN == "FINESSEPRATPCAP" then
												return 50;
											else
												return 0;
											end
										elseif SN == "FINESSEPRATPC" then
											return 0.5;
										else
											return 0;
										end
									elseif SN > "FINESSEPRATPCAPR" then
										if SN < "FIREMIT" then
											if SN == "FINESSET" then
												return StatLinInter("PntMPFinesseT","TraitPntS","ProgBFinesse","AdjUmbarTrait",L,N,0);
											else
												return 0;
											end
										elseif SN > "FIREMIT" then
											if SN == "FIREMITT" then
												return CalcStat("DmgTypeMitT",L,N);
											else
												return 0;
											end
										else
											return CalcStat("DmgTypeMit",L,N);
										end
									else
										return CalcStat("FinessePRatPB",L)*CalcStat("FinessePRatPC",L);
									end
								elseif SN > "FOODNCMRBASEPROG" then
									if SN < "FOODNCMRPROG" then
										if SN < "FOODNCMRL" then
											if SN == "FOODNCMRH" then
												return CalcStat("FoodNCMRProg",L,1)*N;
											else
												return 0;
											end
										elseif SN > "FOODNCMRL" then
											if SN == "FOODNCMRM" then
												return CalcStat("FoodNCMRProg",L,3)*N;
											else
												return 0;
											end
										else
											return CalcStat("FoodNCMRProg",L,2)*N;
										end
									elseif SN > "FOODNCMRPROG" then
										if SN < "FOODNCPRH" then
											if SN == "FOODNCPRBASEPROG" then
												if Lm <= 1 then
													return (N*75+300)/60;
												elseif Lm <= 2 then
													return (N*100+350)/120;
												else
													return (N*90+337.5)/90;
												end
											else
												return 0;
											end
										elseif SN > "FOODNCPRH" then
											if SN == "FOODNCPRL" then
												return CalcStat("FoodNCPRProg",L,2)*N;
											else
												return 0;
											end
										else
											return CalcStat("FoodNCPRProg",L,1)*N;
										end
									else
										if Lm <= 50 then
											return CalcStat("FoodNCMRBaseProg",N,L);
										elseif Lm <= 52 then
											return CalcStat("FoodNCMRBaseProg",N,50);
										elseif Lm <= 77 then
											return CalcStat("FoodNCMRBaseProg",N,L-3);
										elseif Lm <= 111 then
											return CalcStat("FoodNCMRBaseProg",N,RoundDbl((L+143)/3));
										elseif Lm <= 140 then
											return CalcStat("FoodNCMRBaseProg",N,85);
										elseif Lm <= 217 then
											return CalcStat("FoodNCMRBaseProg",N,RoundDbl((L+200)/4));
										elseif Lm <= 221 then
											return CalcStat("FoodNCMRBaseProg",N,104);
										elseif Lm <= 299 then
											return CalcStat("FoodNCMRBaseProg",N,105);
										elseif Lm <= 320 then
											return CalcStat("FoodNCMRBaseProg",N,RoundDbl((L-53)/(7/3)));
										elseif Lm <= 325 then
											return CalcStat("FoodNCMRBaseProg",N,114);
										elseif Lm <= 326 then
											return CalcStat("FoodNCMRBaseProg",N,115);
										else
											return ExpFmod(CalcStat("FoodNCMRProg",326,N),327,1,L,1);
										end
									end
								else
									if Lm <= 1 then
										return (N*70.2+210)/60;
									elseif Lm <= 2 then
										return (N*84+216)/120;
									else
										return (N*83.7+270)/90;
									end
								end
							elseif SN > "FOODNCPRM" then
								if SN < "FREEPAUDACITYREDP" then
									if SN < "FREEPAUDACITYDMGP" then
										if SN < "FOODRESIST" then
											if SN == "FOODNCPRPROG" then
												if Lm <= 1 then
													return CalcStat("FoodNCPRBaseProg",N,L);
												elseif Lm <= 6 then
													return CalcStat("FoodNCPRBaseProg",N,L)-0.25;
												elseif Lm <= 24 then
													return CalcStat("FoodNCPRBaseProg",N,L)-0.5;
												elseif Lm <= 48 then
													return CalcStat("FoodNCPRBaseProg",N,L)-0.75;
												elseif Lm <= 61 then
													return RoundDblDown(CalcStat("FoodNCPRProg",48,N))+1;
												elseif Lm <= 66 then
													return RoundDblDown(CalcStat("FoodNCPRProg",48,N))+2;
												elseif Lm <= 72 then
													return RoundDblDown(CalcStat("FoodNCPRProg",48,N))+3;
												elseif Lm <= 326 then
													return RoundDblDown(CalcStat("FoodNCPRProg",48,N))+4;
												else
													return ExpFmod(CalcStat("FoodNCPRProg",326,N),327,1,L,1);
												end
											else
												return 0;
											end
										elseif SN > "FOODRESIST" then
											if SN == "FREEPAUDACITYCCDP" then
												if Lm <= 0 then
													return 0;
												elseif Lm <= 16 then
													return 0.5;
												else
													return 0.4;
												end
											else
												return 0;
											end
										else
											return StatLinInter("PntMPFoodResist","ItemPntS","ProgBResist","AdjUmbarItem",L,N,0);
										end
									elseif SN > "FREEPAUDACITYDMGP" then
										if SN < "FREEPAUDACITYMELREDP" then
											if SN == "FREEPAUDACITYMELDMGP" then
												return CalcStat("FreepAudacityDmgP",L);
											else
												return 0;
											end
										elseif SN > "FREEPAUDACITYMELREDP" then
											if SN == "FREEPAUDACITYMORALEP" then
												if Lm <= 0 then
													return 0;
												elseif Lm <= 16 then
													return LinFmod(1,0.5,1.4,1,16,L);
												else
													return 1.5;
												end
											else
												return 0;
											end
										else
											return CalcStat("FreepAudacityRedP",L);
										end
									else
										if Lm <= 0 then
											return 0;
										elseif Lm <= 16 then
											return 0.75;
										elseif Lm <= 36 then
											return LinFmod(1,1.2,1.25,17,36,L);
										else
											return 1.25;
										end
									end
								elseif SN > "FREEPAUDACITYREDP" then
									if SN < "FREEPAUDACITYTACREDP" then
										if SN < "FREEPAUDACITYRNGREDP" then
											if SN == "FREEPAUDACITYRNGDMGP" then
												return CalcStat("FreepAudacityDmgP",L);
											else
												return 0;
											end
										elseif SN > "FREEPAUDACITYRNGREDP" then
											if SN == "FREEPAUDACITYTACDMGP" then
												return CalcStat("FreepAudacityDmgP",L);
											else
												return 0;
											end
										else
											return CalcStat("FreepAudacityRedP",L);
										end
									elseif SN > "FREEPAUDACITYTACREDP" then
										if SN < "FREEPBATPROMHEALTHP" then
											if SN == "FREEPBATPROMDMGP" then
												if Lm <= 0 then
													return 0;
												elseif Lm <= 1 then
													return 0.005;
												elseif Lm <= 14 then
													return LinFmod(1,0.005,0.065,2,14,L);
												else
													return 0.075;
												end
											else
												return 0;
											end
										elseif SN > "FREEPBATPROMHEALTHP" then
											if SN == "FREEPBATPROMMELDMGP" then
												return CalcStat("FreepBatPromDmgP",L);
											else
												return 0;
											end
										else
											return CalcStat("FreepBatPromVitalP",L);
										end
									else
										return CalcStat("FreepAudacityRedP",L);
									end
								else
									if Lm <= 0 then
										return 0;
									elseif Lm <= 16 then
										return 1.5;
									else
										return 0.55;
									end
								end
							else
								return CalcStat("FoodNCPRProg",L,3)*N;
							end
						elseif SN > "FREEPBATPROMPOWERP" then
							if SN < "GUARDIANCDAGILITYTOOUTHEAL" then
								if SN < "GRDTENDERIZECRITHIT" then
									if SN < "FROSTMIT" then
										if SN < "FREEPBATPROMTACDMGP" then
											if SN == "FREEPBATPROMRNGDMGP" then
												return CalcStat("FreepBatPromDmgP",L);
											else
												return 0;
											end
										elseif SN > "FREEPBATPROMTACDMGP" then
											if SN == "FREEPBATPROMVITALP" then
												if Lm <= 0 then
													return 0;
												elseif Lm <= 5 then
													return LinFmod(1,1.02,1.1,1,5,L);
												elseif Lm <= 10 then
													return LinFmod(1,1.1,1.15,5,10,L);
												elseif Lm <= 15 then
													return LinFmod(1,1.15,1.2,10,15,L);
												else
													return CalcStat("FreepBatPromVitalP",15);
												end
											else
												return 0;
											end
										else
											return CalcStat("FreepBatPromDmgP",L);
										end
									elseif SN > "FROSTMIT" then
										if SN < "GRDCRITDEF" then
											if SN == "FROSTMITT" then
												return CalcStat("DmgTypeMitT",L,N);
											else
												return 0;
											end
										elseif SN > "GRDCRITDEF" then
											if SN == "GRDRELENTLASSFINESSE" then
												return CalcStat("FinesseT",L,CalcStat("Trait12345Choice",N)*0.2);
											else
												return 0;
											end
										else
											return CalcStat("CritDef",L);
										end
									else
										return CalcStat("DmgTypeMit",L,N);
									end
								elseif SN > "GRDTENDERIZECRITHIT" then
									if SN < "GRDTENDERIZET5CRITHIT" then
										if SN < "GRDTENDERIZET3CRITHIT" then
											if SN == "GRDTENDERIZET2CRITHIT" then
												return CalcStat("CritHitT",L,CalcStat("Trait12345Choice",N)*0.4);
											else
												return 0;
											end
										elseif SN > "GRDTENDERIZET3CRITHIT" then
											if SN == "GRDTENDERIZET4CRITHIT" then
												return CalcStat("CritHitT",L,CalcStat("Trait47101316Choice",N)*0.2);
											else
												return 0;
											end
										else
											return CalcStat("CritHitT",L,CalcStat("Trait357912Choice",N)*0.2);
										end
									elseif SN > "GRDTENDERIZET5CRITHIT" then
										if SN < "GUARDIANCDAGILITYTOCRITHIT" then
											if SN == "GRDWARDTACTTACMIT" then
												return CalcStat("TacMitT",L,CalcStat("Trait12345Choice",N)*0.2);
											else
												return 0;
											end
										elseif SN > "GUARDIANCDAGILITYTOCRITHIT" then
											if SN == "GUARDIANCDAGILITYTOFINESSE" then
												return 1;
											else
												return 0;
											end
										else
											return 2;
										end
									else
										return CalcStat("CritHitT",L,CalcStat("Trait58121620Choice",N)*0.2);
									end
								else
									return CalcStat("CritHitT",L,CalcStat("Trait12345Choice",N)*0.2);
								end
							elseif SN > "GUARDIANCDAGILITYTOOUTHEAL" then
								if SN < "GUARDIANCDBASEFATE" then
									if SN < "GUARDIANCDARMOURTONONPHYMIT" then
										if SN < "GUARDIANCDAGILITYTOPHYMAS" then
											if SN == "GUARDIANCDAGILITYTOPARRY" then
												return 1;
											else
												return 0;
											end
										elseif SN > "GUARDIANCDAGILITYTOPHYMAS" then
											if SN == "GUARDIANCDARMOURTOCOMPHYMIT" then
												return 1;
											else
												return 0;
											end
										else
											return 2;
										end
									elseif SN > "GUARDIANCDARMOURTONONPHYMIT" then
										if SN < "GUARDIANCDARMOURTYPE" then
											if SN == "GUARDIANCDARMOURTOTACMIT" then
												return 0.2;
											else
												return 0;
											end
										elseif SN > "GUARDIANCDARMOURTYPE" then
											if SN == "GUARDIANCDBASEAGILITY" then
												return CalcStat("ClassBaseAgilityM",L);
											else
												return 0;
											end
										else
											return 3;
										end
									else
										return 0.2;
									end
								elseif SN > "GUARDIANCDBASEFATE" then
									if SN < "GUARDIANCDBASEMORALE" then
										if SN < "GUARDIANCDBASEICPR" then
											if SN == "GUARDIANCDBASEICMR" then
												return CalcStat("ClassBaseICMRH",L);
											else
												return 0;
											end
										elseif SN > "GUARDIANCDBASEICPR" then
											if SN == "GUARDIANCDBASEMIGHT" then
												return CalcStat("ClassBaseMightH",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseICPR",L);
										end
									elseif SN > "GUARDIANCDBASEMORALE" then
										if SN < "GUARDIANCDBASENCPR" then
											if SN == "GUARDIANCDBASENCMR" then
												return CalcStat("ClassBaseNCMRH",L);
											else
												return 0;
											end
										elseif SN > "GUARDIANCDBASENCPR" then
											if SN == "GUARDIANCDBASEPOWER" then
												return CalcStat("ClassBasePower",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseNCPR",L);
										end
									else
										return CalcStat("ClassBaseMorale",L);
									end
								else
									return CalcStat("ClassBaseFate",L);
								end
							else
								return 2;
							end
						else
							return CalcStat("FreepBatPromVitalP",L);
						end
					elseif SN > "GUARDIANCDBASEVITALITY" then
						if SN < "HELFTHOSEWHOREMAINWILL" then
							if SN < "GUARDIANCDPHYMITTOCOMPHYMIT" then
								if SN < "GUARDIANCDHASPOWER" then
									if SN < "GUARDIANCDCALCTYPETACMIT" then
										if SN < "GUARDIANCDCALCTYPECOMPHYMIT" then
											if SN == "GUARDIANCDBASEWILL" then
												return CalcStat("ClassBaseWillL",L);
											else
												return 0;
											end
										elseif SN > "GUARDIANCDCALCTYPECOMPHYMIT" then
											if SN == "GUARDIANCDCALCTYPENONPHYMIT" then
												return 14;
											else
												return 0;
											end
										else
											return 14;
										end
									elseif SN > "GUARDIANCDCALCTYPETACMIT" then
										if SN < "GUARDIANCDFATETONCPR" then
											if SN == "GUARDIANCDCANBLOCK" then
												return 1;
											else
												return 0;
											end
										elseif SN > "GUARDIANCDFATETONCPR" then
											if SN == "GUARDIANCDFATETOPOWER" then
												return 1;
											else
												return 0;
											end
										else
											return 0.07;
										end
									else
										return 27;
									end
								elseif SN > "GUARDIANCDHASPOWER" then
									if SN < "GUARDIANCDMIGHTTOPARRY" then
										if SN < "GUARDIANCDMIGHTTOCRITHIT" then
											if SN == "GUARDIANCDMIGHTTOBLOCK" then
												return 1;
											else
												return 0;
											end
										elseif SN > "GUARDIANCDMIGHTTOCRITHIT" then
											if SN == "GUARDIANCDMIGHTTOOUTHEAL" then
												return 3;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "GUARDIANCDMIGHTTOPARRY" then
										if SN < "GUARDIANCDMIGHTTOPHYMIT" then
											if SN == "GUARDIANCDMIGHTTOPHYMAS" then
												return 3;
											else
												return 0;
											end
										elseif SN > "GUARDIANCDMIGHTTOPHYMIT" then
											if SN == "GUARDIANCDMIGHTTOTACMIT" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 2;
									end
								else
									return 1;
								end
							elseif SN > "GUARDIANCDPHYMITTOCOMPHYMIT" then
								if SN < "GUARDIANCDWILLTOPHYMAS" then
									if SN < "GUARDIANCDVITALITYTOMORALE" then
										if SN < "GUARDIANCDTACMASTOOUTHEAL" then
											if SN == "GUARDIANCDPHYMITTONONPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "GUARDIANCDTACMASTOOUTHEAL" then
											if SN == "GUARDIANCDVITALITYTOICMR" then
												return 0.012;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "GUARDIANCDVITALITYTOMORALE" then
										if SN < "GUARDIANCDWILLTOFINESSE" then
											if SN == "GUARDIANCDVITALITYTONCMR" then
												return 0.12;
											else
												return 0;
											end
										elseif SN > "GUARDIANCDWILLTOFINESSE" then
											if SN == "GUARDIANCDWILLTOOUTHEAL" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 4.5;
									end
								elseif SN > "GUARDIANCDWILLTOPHYMAS" then
									if SN < "HELFFADINGFIRSTBORNFATE" then
										if SN < "GUARDIANCDWILLTORESIST" then
											if SN == "GUARDIANCDWILLTOPHYMIT" then
												return 1.5;
											else
												return 0;
											end
										elseif SN > "GUARDIANCDWILLTORESIST" then
											if SN == "GUARDIANCDWILLTOTACMIT" then
												return 1.5;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "HELFFADINGFIRSTBORNFATE" then
										if SN < "HELFPEACEELDARNCMR" then
											if SN == "HELFPEACEELDARMORALE" then
												return CalcStat("MoraleT",L,1.0);
											else
												return 0;
											end
										elseif SN > "HELFPEACEELDARNCMR" then
											if SN == "HELFSORROWUNDYINGWILL" then
												return -CalcStat("WillT",L,0.4);
											else
												return 0;
											end
										else
											return CalcStat("NCMRT",L,0.6);
										end
									else
										return -CalcStat("FateT",L,0.4);
									end
								else
									return 1;
								end
							else
								return 1;
							end
						elseif SN > "HELFTHOSEWHOREMAINWILL" then
							if SN < "HNTRAPIDFIREPHYMAS" then
								if SN < "HNTARMOURRENDBLOCK" then
									if SN < "HIGHELFRDTRAITFATE" then
										if SN < "HIGHELFRDPSVONEWILL" then
											if SN == "HIGHELFRDPSVONENAME" then
												return "Those Who Remain";
											else
												return 0;
											end
										elseif SN > "HIGHELFRDPSVONEWILL" then
											if SN == "HIGHELFRDPSVTWONAME" then
												return "";
											else
												return 0;
											end
										else
											return CalcStat("HElfThoseWhoRemainWill",L);
										end
									elseif SN > "HIGHELFRDTRAITFATE" then
										if SN < "HIGHELFRDTRAITNCMR" then
											if SN == "HIGHELFRDTRAITMORALE" then
												return CalcStat("HElfPeaceEldarMorale",L);
											else
												return 0;
											end
										elseif SN > "HIGHELFRDTRAITNCMR" then
											if SN == "HIGHELFRDTRAITWILL" then
												return CalcStat("HElfSorrowUndyingWill",L);
											else
												return 0;
											end
										else
											return CalcStat("HElfPeaceEldarNCMR",L);
										end
									else
										return CalcStat("HElfFadingFirstbornFate",L);
									end
								elseif SN > "HNTARMOURRENDBLOCK" then
									if SN < "HNTCAMPFIRENCMR" then
										if SN < "HNTARMOURRENDPARRY" then
											if SN == "HNTARMOURRENDEVADE" then
												return -CalcStat("EvadeT",L,CalcStat("Trait23456Choice",N)*0.4);
											else
												return 0;
											end
										elseif SN > "HNTARMOURRENDPARRY" then
											if SN == "HNTBREACHFINDERRNGMIT" then
												return (-20)*L;
											else
												return 0;
											end
										else
											return -CalcStat("ParryT",L,CalcStat("Trait23456Choice",N)*0.4);
										end
									elseif SN > "HNTCAMPFIRENCMR" then
										if SN < "HNTPRECISIONSTANCEFINESSE" then
											if SN == "HNTCAMPFIRENCPR" then
												return CalcStat("NCPRT",L,1.2);
											else
												return 0;
											end
										elseif SN > "HNTPRECISIONSTANCEFINESSE" then
											if SN == "HNTPURGEPOISONRESIST" then
												return CalcStat("PoisonResistT",L,4);
											else
												return 0;
											end
										else
											return CalcStat("FinesseT",L,1.6);
										end
									else
										return CalcStat("NCMRT",L,1.2);
									end
								else
									return -CalcStat("ShieldBlock",L,CalcStat("Trait23456Choice",N)*0.4);
								end
							elseif SN > "HNTRAPIDFIREPHYMAS" then
								if SN < "HOBBITRDTRAITVITALITY" then
									if SN < "HOBBITRDPSVONENAME" then
										if SN < "HNTSTRENGTHSTANCECRITHIT" then
											if SN == "HNTRAPIDFIRESEL" then
												if Lm <= 0 then
													return 0;
												elseif Lm <= 8 then
													return L+2;
												elseif Lm <= 10 then
													return 2*L-6;
												else
													return CalcStat("HntRapidFireSel",10);
												end
											else
												return 0;
											end
										elseif SN > "HNTSTRENGTHSTANCECRITHIT" then
											if SN == "HOBBITRDPSVONEMIGHT" then
												return CalcStat("HobHobbitStatureMight",L);
											else
												return 0;
											end
										else
											return CalcStat("CritHitT",L,4);
										end
									elseif SN > "HOBBITRDPSVONENAME" then
										if SN < "HOBBITRDTRAITMIGHT" then
											if SN == "HOBBITRDPSVTWONAME" then
												return "";
											else
												return 0;
											end
										elseif SN > "HOBBITRDTRAITMIGHT" then
											if SN == "HOBBITRDTRAITNCMR" then
												return CalcStat("HobRapidRecoveryNCMR",L);
											else
												return 0;
											end
										else
											return CalcStat("HobSmallSizeMight",L);
										end
									else
										return "Hobbit-stature";
									end
								elseif SN > "HOBBITRDTRAITVITALITY" then
									if SN < "HOBSMALLSIZEMIGHT" then
										if SN < "HOBHOBBITTOUGHNVITALITY" then
											if SN == "HOBHOBBITSTATUREMIGHT" then
												return CalcStat("MightT",L,1.0);
											else
												return 0;
											end
										elseif SN > "HOBHOBBITTOUGHNVITALITY" then
											if SN == "HOBRAPIDRECOVERYNCMR" then
												return CalcStat("NCMRT",L,0.6);
											else
												return 0;
											end
										else
											return CalcStat("VitalityT",L,1.0);
										end
									elseif SN > "HOBSMALLSIZEMIGHT" then
										if SN < "HUNTERCDAGILITYTOCRITHIT" then
											if SN == "HOPEMORALEP" then
												if Lm <= 5 then
													return DataTableValue({-0.99,-0.97,-0.95,-0.9,-0.85,-0.8,-0.65,-0.6,-0.5,-0.4,-0.3,-0.2,-0.15,-0.1,-0.05,0,0.01,0.02,0.03,0.04,0.05},L+16);
												else
													return 0.05;
												end
											else
												return 0;
											end
										elseif SN > "HUNTERCDAGILITYTOCRITHIT" then
											if SN == "HUNTERCDAGILITYTOEVADE" then
												return 2;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return -CalcStat("MightT",L,0.4);
									end
								else
									return CalcStat("HobHobbitToughnVitality",L);
								end
							else
								return CalcStat("PhyMasT",L,CalcStat("HntRapidFireSel",N)*0.2);
							end
						else
							return CalcStat("WillT",L,1.0);
						end
					else
						return CalcStat("ClassBaseVitality",L);
					end
				else
					return CalcStat("BRatRounded",L,"BRatStandard");
				end
			elseif SN > "HUNTERCDAGILITYTOOUTHEAL" then
				if SN < "LOREMASTERCDCALCTYPETACMIT" then
					if SN < "INHEALPRATPA" then
						if SN < "HUNTERCDPHYMITTOCOMPHYMIT" then
							if SN < "HUNTERCDBASENCMR" then
								if SN < "HUNTERCDARMOURTOTACMIT" then
									if SN < "HUNTERCDAGILITYTOPHYMIT" then
										if SN > "HUNTERCDAGILITYTOPARRY" then
											if SN == "HUNTERCDAGILITYTOPHYMAS" then
												return 3;
											else
												return 0;
											end
										elseif SN == "HUNTERCDAGILITYTOPARRY" then
											return 1;
										else
											return 0;
										end
									elseif SN > "HUNTERCDAGILITYTOPHYMIT" then
										if SN < "HUNTERCDARMOURTOCOMPHYMIT" then
											if SN == "HUNTERCDAGILITYTOTACMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "HUNTERCDARMOURTOCOMPHYMIT" then
											if SN == "HUNTERCDARMOURTONONPHYMIT" then
												return 0.2;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 1;
									end
								elseif SN > "HUNTERCDARMOURTOTACMIT" then
									if SN < "HUNTERCDBASEICMR" then
										if SN < "HUNTERCDBASEAGILITY" then
											if SN == "HUNTERCDARMOURTYPE" then
												return 2;
											else
												return 0;
											end
										elseif SN > "HUNTERCDBASEAGILITY" then
											if SN == "HUNTERCDBASEFATE" then
												return CalcStat("ClassBaseFate",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseAgilityH",L);
										end
									elseif SN > "HUNTERCDBASEICMR" then
										if SN < "HUNTERCDBASEMIGHT" then
											if SN == "HUNTERCDBASEICPR" then
												return CalcStat("ClassBaseICPR",L);
											else
												return 0;
											end
										elseif SN > "HUNTERCDBASEMIGHT" then
											if SN == "HUNTERCDBASEMORALE" then
												return CalcStat("ClassBaseMorale",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseMightM",L);
										end
									else
										return CalcStat("ClassBaseICMRM",L);
									end
								else
									return 0.2;
								end
							elseif SN > "HUNTERCDBASENCMR" then
								if SN < "HUNTERCDFATETONCPR" then
									if SN < "HUNTERCDBASEWILL" then
										if SN < "HUNTERCDBASEPOWER" then
											if SN == "HUNTERCDBASENCPR" then
												return CalcStat("ClassBaseNCPR",L);
											else
												return 0;
											end
										elseif SN > "HUNTERCDBASEPOWER" then
											if SN == "HUNTERCDBASEVITALITY" then
												return CalcStat("ClassBaseVitality",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBasePower",L);
										end
									elseif SN > "HUNTERCDBASEWILL" then
										if SN < "HUNTERCDCALCTYPENONPHYMIT" then
											if SN == "HUNTERCDCALCTYPECOMPHYMIT" then
												return 13;
											else
												return 0;
											end
										elseif SN > "HUNTERCDCALCTYPENONPHYMIT" then
											if SN == "HUNTERCDCALCTYPETACMIT" then
												return 26;
											else
												return 0;
											end
										else
											return 13;
										end
									else
										return CalcStat("ClassBaseWillL",L);
									end
								elseif SN > "HUNTERCDFATETONCPR" then
									if SN < "HUNTERCDMIGHTTOEVADE" then
										if SN < "HUNTERCDHASPOWER" then
											if SN == "HUNTERCDFATETOPOWER" then
												return 1;
											else
												return 0;
											end
										elseif SN > "HUNTERCDHASPOWER" then
											if SN == "HUNTERCDMIGHTTOCRITHIT" then
												return 1.5;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "HUNTERCDMIGHTTOEVADE" then
										if SN < "HUNTERCDMIGHTTOOUTHEAL" then
											if SN == "HUNTERCDMIGHTTOFINESSE" then
												return 1.5;
											else
												return 0;
											end
										elseif SN > "HUNTERCDMIGHTTOOUTHEAL" then
											if SN == "HUNTERCDMIGHTTOPHYMAS" then
												return 2;
											else
												return 0;
											end
										else
											return 2;
										end
									else
										return 1;
									end
								else
									return 0.07;
								end
							else
								return CalcStat("ClassBaseNCMRM",L);
							end
						elseif SN > "HUNTERCDPHYMITTOCOMPHYMIT" then
							if SN < "ICPR" then
								if SN < "HUNTERCDWILLTOOUTHEAL" then
									if SN < "HUNTERCDVITALITYTOMORALE" then
										if SN < "HUNTERCDTACMASTOOUTHEAL" then
											if SN == "HUNTERCDPHYMITTONONPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "HUNTERCDTACMASTOOUTHEAL" then
											if SN == "HUNTERCDVITALITYTOICMR" then
												return 0.012;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "HUNTERCDVITALITYTOMORALE" then
										if SN < "HUNTERCDWILLTOCRITHIT" then
											if SN == "HUNTERCDVITALITYTONCMR" then
												return 0.12;
											else
												return 0;
											end
										elseif SN > "HUNTERCDWILLTOCRITHIT" then
											if SN == "HUNTERCDWILLTOFINESSE" then
												return 1.5;
											else
												return 0;
											end
										else
											return 0.5;
										end
									else
										return 4.5;
									end
								elseif SN > "HUNTERCDWILLTOOUTHEAL" then
									if SN < "ICMR" then
										if SN < "HUNTERCDWILLTOPHYMIT" then
											if SN == "HUNTERCDWILLTOPHYMAS" then
												return 2;
											else
												return 0;
											end
										elseif SN > "HUNTERCDWILLTOPHYMIT" then
											if SN == "HUNTERCDWILLTORESIST" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "ICMR" then
										if SN < "ICMRCRAW" then
											if SN == "ICMRC" then
												return StatLinInter("PntMPICMRC","CreepPntSOld","ProgBICMRC","",L,N,0);
											else
												return 0;
											end
										elseif SN > "ICMRCRAW" then
											if SN == "ICMRT" then
												return StatLinInter("PntMPICMR","TraitPntSVital","ProgBICMR","",L,N,1);
											else
												return 0;
											end
										else
											return StatLinInter("PntMPICMRCOld","CreepPntS","ProgBICMRC","",L,N,99);
										end
									else
										return StatLinInter("PntMPICMR","ItemPntSVital","ProgBICMR","",L,N,1);
									end
								else
									return 2;
								end
							elseif SN > "ICPR" then
								if SN < "INDMGPRATPB" then
									if SN < "INDMGPBONUS" then
										if SN < "ICPRCRAW" then
											if SN == "ICPRC" then
												return StatLinInter("PntMPICPRC","CreepPntSOld","ProgBICPRC","",L,N,0);
											else
												return 0;
											end
										elseif SN > "ICPRCRAW" then
											if SN == "ICPRT" then
												return StatLinInter("PntMPICPR","TraitPntSVital","ProgBICPR","",L,N,99);
											else
												return 0;
											end
										else
											return StatLinInter("PntMPICPRCOld","CreepPntS","ProgBICPRC","",L,N,99);
										end
									elseif SN > "INDMGPBONUS" then
										if SN < "INDMGPRATP" then
											if SN == "INDMGPPRAT" then
												return CalcRatAB(CalcStat("InDmgPRatPA",L),CalcStat("InDmgPRatPB",L),CalcStat("InDmgPRatPCapR",L),N);
											else
												return 0;
											end
										elseif SN > "INDMGPRATP" then
											if SN == "INDMGPRATPA" then
												return 1200;
											else
												return 0;
											end
										else
											return CalcPercAB(CalcStat("InDmgPRatPA",L),CalcStat("InDmgPRatPB",L),CalcStat("InDmgPRatPCap",L),N);
										end
									else
										return 0;
									end
								elseif SN > "INDMGPRATPB" then
									if SN < "INHEAL" then
										if SN < "INDMGPRATPCAP" then
											if SN == "INDMGPRATPC" then
												return 0.5;
											else
												return 0;
											end
										elseif SN > "INDMGPRATPCAP" then
											if SN == "INDMGPRATPCAPR" then
												return CalcStat("InDmgPRatPB",L)*CalcStat("InDmgPRatPC",L);
											else
												return 0;
											end
										else
											return 400;
										end
									elseif SN > "INHEAL" then
										if SN < "INHEALPPRAT" then
											if SN == "INHEALPBONUS" then
												return 0;
											else
												return 0;
											end
										elseif SN > "INHEALPPRAT" then
											if SN == "INHEALPRATP" then
												return CalcPercAB(CalcStat("InHealPRatPA",L),CalcStat("InHealPRatPB",L),CalcStat("InHealPRatPCap",L),N);
											else
												return 0;
											end
										else
											return CalcRatAB(CalcStat("InHealPRatPA",L),CalcStat("InHealPRatPB",L),CalcStat("InHealPRatPCapR",L),N);
										end
									else
										return StatLinInter("PntMPInHeal","ItemPntS","ProgBInHeal","AdjUmbarItem",L,N,0);
									end
								else
									return CalcStat("BRatRounded",L,"BRatStandard");
								end
							else
								return StatLinInter("PntMPICPR","ItemPntSVital","ProgBICPR","",L,N,99);
							end
						else
							return 1;
						end
					elseif SN > "INHEALPRATPA" then
						if SN < "LMPREPFORWARTACMAS" then
							if SN < "LI2ILVLCAP" then
								if SN < "INSTRPOWER" then
									if SN < "INHEALPRATPCAP" then
										if SN > "INHEALPRATPB" then
											if SN == "INHEALPRATPC" then
												return 0.5;
											else
												return 0;
											end
										elseif SN == "INHEALPRATPB" then
											return CalcStat("BRatRounded",L,"BRatStandard");
										else
											return 0;
										end
									elseif SN > "INHEALPRATPCAP" then
										if SN < "INHEALT" then
											if SN == "INHEALPRATPCAPR" then
												return CalcStat("InHealPRatPB",L)*CalcStat("InHealPRatPC",L);
											else
												return 0;
											end
										elseif SN > "INHEALT" then
											if SN == "INSTRMORALE" then
												if Lm <= 105 then
													return RoundDbl(4.04*L);
												else
													return CalcStat("ProgExtLowExpRnd",L,CalcStat("InstrMorale",105));
												end
											else
												return 0;
											end
										else
											return StatLinInter("PntMPInHeal","TraitPntS","ProgBInHeal","AdjUmbarTrait",L,N,0);
										end
									else
										return 25;
									end
								elseif SN > "INSTRPOWER" then
									if SN < "ITEMPNTSVIRTUEMORALE" then
										if SN < "ITEMPNTSCLASSIC" then
											if SN == "ITEMPNTS" then
												return {{1,25,79,80,200,225,300,349,350,399,400,449,450,499,500,549,550,599},{1,25,75,76,100,105,106,115,116,120,121,130,131,140,141,150,151,160}};
											else
												return 0;
											end
										elseif SN > "ITEMPNTSCLASSIC" then
											if SN == "ITEMPNTSVIRTUEMASTERY" then
												return {{0,1,25,79,80,200,225,300,349,350,400,449,450,499,500,549,550,599},{0,1,25,75,76,100,105,106,115,116,121,130,131,140,141,150,151,160}};
											else
												return 0;
											end
										else
											return {{1,25,50,60,79,80,200,225,300,349,350,399,400,449,450,499,500,549,550,599},{1,25,50,60,75,76,100,105,106,115,116,120,121,130,131,140,141,150,151,160}};
										end
									elseif SN > "ITEMPNTSVIRTUEMORALE" then
										if SN < "L" then
											if SN == "ITEMPNTSVITAL" then
												return {{1,25,50,60,79,80,200,225,300,349,350,399,400,449,450,499,500,549,550,599},{1,25,50,60,75,76,100,105,106,115,116,120,121,130,131,140,141,150,151,160}};
											else
												return 0;
											end
										elseif SN > "L" then
											if SN == "LEVELCAP" then
												return 150;
											else
												return 0;
											end
										else
											return L;
										end
									else
										return {{0,1,2,50,80,200,225,300,349,350,399,400,449,450,499,500,549,550,599},{0,1,2,50,76,100,105,106,115,116,120,121,130,131,140,141,150,151,160}};
									end
								else
									if Lm <= 9 then
										return RoundDbl(0.95*L+12.6);
									elseif Lm <= 18 then
										return RoundDbl(1.95*L+3);
									elseif Lm <= 26 then
										return RoundDbl(2.95*L-15.55);
									elseif Lm <= 35 then
										return RoundDbl(3.95*L-42.15);
									elseif Lm <= 42 then
										return RoundDbl(4.95*L-77.7);
									elseif Lm <= 45 then
										return RoundDbl(5.95*L-120.35);
									elseif Lm <= 105 then
										return RoundDbl(6*L-124);
									else
										return CalcStat("ProgExtMpExpRnd",L,CalcStat("InstrPower",105));
									end
								end
							elseif SN > "LI2ILVLCAP" then
								if SN < "LMEAGLENOBILITYICPR" then
									if SN < "LIGHTNINGMIT" then
										if SN < "LIGHTMIT" then
											if SN == "LI2REFORGEILVL" then
												if Lm <= 145 then
													return CalcStat("AwardILvlI",L);
												else
													return N;
												end
											else
												return 0;
											end
										elseif SN > "LIGHTMIT" then
											if SN == "LIGHTMITT" then
												return CalcStat("DmgTypeMitT",L,N);
											else
												return 0;
											end
										else
											return CalcStat("DmgTypeMit",L,N);
										end
									elseif SN > "LIGHTNINGMIT" then
										if SN < "LMANCIENTWISDOMWILL" then
											if SN == "LIGHTNINGMITT" then
												return CalcStat("DmgTypeMitT",L,N);
											else
												return 0;
											end
										elseif SN > "LMANCIENTWISDOMWILL" then
											if SN == "LMCATMINTBEARARMOUR" then
												return CalcStat("BaseArmour",L,15);
											else
												return 0;
											end
										else
											if Lm <= 105 then
												return RoundDbl(1.1*L);
											else
												return CalcStat("ProgExtLowExpRnd",L,CalcStat("LmAncientWisdomWill",105));
											end
										end
									else
										return CalcStat("DmgTypeMit",L,N);
									end
								elseif SN > "LMEAGLENOBILITYICPR" then
									if SN < "LMKNOWLEDGELMPHYRES" then
										if SN < "LMHEARTYDIETMORALE" then
											if SN == "LMEVASIONRAVENARMOUR" then
												return CalcStat("ArmourT",L,0.8);
											else
												return 0;
											end
										elseif SN > "LMHEARTYDIETMORALE" then
											if SN == "LMKNOWLEDGELMCRYRES" then
												return -CalcStat("CryResistT",L,0.6);
											else
												return 0;
											end
										else
											return CalcStat("Morale",L,CalcStat("Trait12345Choice",N)*0.4);
										end
									elseif SN > "LMKNOWLEDGELMPHYRES" then
										if SN < "LMKNOWLEDGELMTACRES" then
											if SN == "LMKNOWLEDGELMSONGRES" then
												return -CalcStat("SongResistT",L,0.6);
											else
												return 0;
											end
										elseif SN > "LMKNOWLEDGELMTACRES" then
											if SN == "LMPREPFORWARPETTACMAS" then
												return CalcStat("TacMas",L,3.0);
											else
												return 0;
											end
										else
											return -CalcStat("TacResistT",L,0.6);
										end
									else
										return -CalcStat("PhyResistT",L,0.6);
									end
								else
									return CalcStat("ICPRT",L,0.8);
								end
							else
								return 515;
							end
						elseif SN > "LMPREPFORWARTACMAS" then
							if SN < "LOREMASTERCDARMOURTONONPHYMIT" then
								if SN < "LMSWSTAFFBUGPARRYOLD" then
									if SN < "LMRINGOFFIREEVADE" then
										if SN < "LMRAVENSHOTRAVWINGTACMIT" then
											if SN == "LMRAVENSHOTRAVWINGFIXTACMIT" then
												return CalcStat("TacMitT",L,2);
											else
												return 0;
											end
										elseif SN > "LMRAVENSHOTRAVWINGTACMIT" then
											if SN == "LMRINGOFFIREBLOCK" then
												return -CalcStat("BlockT",L,2.4);
											else
												return 0;
											end
										else
											return CalcStat("TacMit",L,2);
										end
									elseif SN > "LMRINGOFFIREEVADE" then
										if SN < "LMSWSTAFFBUGMORALE" then
											if SN == "LMRINGOFFIREPARRY" then
												return -CalcStat("ParryT",L,2.4);
											else
												return 0;
											end
										elseif SN > "LMSWSTAFFBUGMORALE" then
											if SN == "LMSWSTAFFBUGPARRY" then
												if Lm <= 140 then
													return CalcStat("U371LegacyStatFix",L,"LmSwStaffBugParryOld");
												else
													return CalcStat("LMSwStaffBugParry",140);
												end
											else
												return 0;
											end
										else
											if Lm <= 105 then
												return RoundDbl(LinFmod(1,16.2,696.9,1,105,L));
											else
												return CalcStat("ProgExtLowExpRnd",L,CalcStat("LmSwStaffBugMorale",105));
											end
										end
									else
										return -CalcStat("EvadeT",L,2.4);
									end
								elseif SN > "LMSWSTAFFBUGPARRYOLD" then
									if SN < "LOREMASTERCDAGILITYTOEVADE" then
										if SN < "LOEPASSIVE" then
											if SN == "LOE" then
												return 2*N;
											else
												return 0;
											end
										elseif SN > "LOEPASSIVE" then
											if SN == "LOREMASTERCDAGILITYTOCRITHIT" then
												return 2;
											else
												return 0;
											end
										else
											if Lm <= 115 then
												return 0;
											elseif Lm <= 119 then
												return 20*L-2300;
											else
												return CalcStat("LoEPassive",119);
											end
										end
									elseif SN > "LOREMASTERCDAGILITYTOEVADE" then
										if SN < "LOREMASTERCDAGILITYTOTACMAS" then
											if SN == "LOREMASTERCDAGILITYTOFINESSE" then
												return 1;
											else
												return 0;
											end
										elseif SN > "LOREMASTERCDAGILITYTOTACMAS" then
											if SN == "LOREMASTERCDARMOURTOCOMPHYMIT" then
												return 1;
											else
												return 0;
											end
										else
											return 2;
										end
									else
										return 1;
									end
								else
									if Lm <= 105 then
										return RoundDbl(44.44*L);
									else
										return CalcStat("ProgExtHighLinExpRnd",L,CalcStat("LmSwStaffBugParryOld",105));
									end
								end
							elseif SN > "LOREMASTERCDARMOURTONONPHYMIT" then
								if SN < "LOREMASTERCDBASEMORALE" then
									if SN < "LOREMASTERCDBASEFATE" then
										if SN < "LOREMASTERCDARMOURTYPE" then
											if SN == "LOREMASTERCDARMOURTOTACMIT" then
												return 0.2;
											else
												return 0;
											end
										elseif SN > "LOREMASTERCDARMOURTYPE" then
											if SN == "LOREMASTERCDBASEAGILITY" then
												return CalcStat("ClassBaseAgilityL",L);
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "LOREMASTERCDBASEFATE" then
										if SN < "LOREMASTERCDBASEICPR" then
											if SN == "LOREMASTERCDBASEICMR" then
												return CalcStat("ClassBaseICMRL",L);
											else
												return 0;
											end
										elseif SN > "LOREMASTERCDBASEICPR" then
											if SN == "LOREMASTERCDBASEMIGHT" then
												return CalcStat("ClassBaseMightM",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseICPR",L);
										end
									else
										return CalcStat("ClassBaseFate",L);
									end
								elseif SN > "LOREMASTERCDBASEMORALE" then
									if SN < "LOREMASTERCDBASEVITALITY" then
										if SN < "LOREMASTERCDBASENCPR" then
											if SN == "LOREMASTERCDBASENCMR" then
												return CalcStat("ClassBaseNCMRL",L);
											else
												return 0;
											end
										elseif SN > "LOREMASTERCDBASENCPR" then
											if SN == "LOREMASTERCDBASEPOWER" then
												return CalcStat("ClassBasePower",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseNCPR",L);
										end
									elseif SN > "LOREMASTERCDBASEVITALITY" then
										if SN < "LOREMASTERCDCALCTYPECOMPHYMIT" then
											if SN == "LOREMASTERCDBASEWILL" then
												return CalcStat("ClassBaseWillH",L);
											else
												return 0;
											end
										elseif SN > "LOREMASTERCDCALCTYPECOMPHYMIT" then
											if SN == "LOREMASTERCDCALCTYPENONPHYMIT" then
												return 12;
											else
												return 0;
											end
										else
											return 12;
										end
									else
										return CalcStat("ClassBaseVitality",L);
									end
								else
									return CalcStat("ClassBaseMorale",L);
								end
							else
								return 0.2;
							end
						else
							return CalcStat("TacMasT",L,CalcStat("Trait12345Choice",N)*0.4);
						end
					else
						return 75;
					end
				elseif SN > "LOREMASTERCDCALCTYPETACMIT" then
					if SN < "MARINERCDBASEPOWER" then
						if SN < "MANEASILYINSPINHEALP" then
							if SN < "LOREMASTERCDWILLTOEVADE" then
								if SN < "LOREMASTERCDMIGHTTOTACMAS" then
									if SN < "LOREMASTERCDHASPOWER" then
										if SN > "LOREMASTERCDFATETONCPR" then
											if SN == "LOREMASTERCDFATETOPOWER" then
												return 1;
											else
												return 0;
											end
										elseif SN == "LOREMASTERCDFATETONCPR" then
											return 0.07;
										else
											return 0;
										end
									elseif SN > "LOREMASTERCDHASPOWER" then
										if SN < "LOREMASTERCDMIGHTTOFINESSE" then
											if SN == "LOREMASTERCDMIGHTTOCRITHIT" then
												return 1.5;
											else
												return 0;
											end
										elseif SN > "LOREMASTERCDMIGHTTOFINESSE" then
											if SN == "LOREMASTERCDMIGHTTOPARRY" then
												return 1;
											else
												return 0;
											end
										else
											return 1.5;
										end
									else
										return 1;
									end
								elseif SN > "LOREMASTERCDMIGHTTOTACMAS" then
									if SN < "LOREMASTERCDVITALITYTOICMR" then
										if SN < "LOREMASTERCDPHYMITTONONPHYMIT" then
											if SN == "LOREMASTERCDPHYMITTOCOMPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "LOREMASTERCDPHYMITTONONPHYMIT" then
											if SN == "LOREMASTERCDTACMASTOOUTHEAL" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "LOREMASTERCDVITALITYTOICMR" then
										if SN < "LOREMASTERCDVITALITYTONCMR" then
											if SN == "LOREMASTERCDVITALITYTOMORALE" then
												return 4.5;
											else
												return 0;
											end
										elseif SN > "LOREMASTERCDVITALITYTONCMR" then
											if SN == "LOREMASTERCDWILLTOCRITHIT" then
												return 1;
											else
												return 0;
											end
										else
											return 0.12;
										end
									else
										return 0.012;
									end
								else
									return 2;
								end
							elseif SN > "LOREMASTERCDWILLTOEVADE" then
								if SN < "LVLBONUSTACDMG" then
									if SN < "LOREMASTERCDWILLTOTACMIT" then
										if SN < "LOREMASTERCDWILLTORESIST" then
											if SN == "LOREMASTERCDWILLTOPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "LOREMASTERCDWILLTORESIST" then
											if SN == "LOREMASTERCDWILLTOTACMAS" then
												return 3;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "LOREMASTERCDWILLTOTACMIT" then
										if SN < "LVLBONUSPHYDMG" then
											if SN == "LVLBONUSMORRES" then
												return 0.1;
											else
												return 0;
											end
										elseif SN > "LVLBONUSPHYDMG" then
											if SN == "LVLBONUSPOWRES" then
												return CalcStat("SkillPowerCost",L,N);
											else
												return 0;
											end
										else
											return 0.1;
										end
									else
										return 1;
									end
								elseif SN > "LVLBONUSTACDMG" then
									if SN < "MAIN" then
										if SN < "LVLEXPCOSTTOT" then
											if SN == "LVLEXPCOST" then
												if Lm <= 1 then
													return 0;
												elseif Lm <= 5 then
													return RoundDbl(12.5*L*L+12.5666666666667*L+24.8666666666667);
												elseif Lm <= 10 then
													return RoundDbl(33.8*L*L-179.48*L+452.6);
												elseif Lm <= 15 then
													return RoundDbl(55.05*L*L-583.77*L+2370.5);
												elseif Lm <= 20 then
													return RoundDbl(76.2*L*L-1196.96*L+6809);
												elseif Lm <= 25 then
													return RoundDbl(97.4*L*L-2023*L+14849.8);
												elseif Lm <= 30 then
													return RoundDbl(118.7*L*L-3066.02 *L+27612.8);
												elseif Lm <= 35 then
													return RoundDbl(139.95*L*L-4319.23*L+46084.1);
												elseif Lm <= 40 then
													return RoundDbl(161.2*L*L-5785.04*L+71356.2);
												elseif Lm <= 45 then
													return RoundDbl(182.5*L*L-7467.38*L+104569.8);
												elseif Lm <= 50 then
													return RoundDbl(203.8*L*L-9363.48*L+146761.8);
												elseif Lm <= 55 then
													return RoundDbl(225.05*L*L-11467.77*L+198851.3);
												elseif Lm <= 60 then
													return RoundDbl(246.3*L*L-13784.46*L+261988);
												elseif Lm <= 70 then
													return RoundDbl(ExpFmod(CalcStat("LvlExpCost",60),61,5.071,L,nil,3.485));
												elseif Lm <= 75 then
													return RoundDbl(ExpFmod(CalcStat("LvlExpCost",70),71,5.072,L,nil,-0.95));
												else
													return ExpFmod(CalcStat("LvlExpCost",75),76,5,L,0,-0.5);
												end
											else
												return 0;
											end
										elseif SN > "LVLEXPCOSTTOT" then
											if SN == "LVLTOILVL" then
												if Lm <= 106 then
													return LinFmod(1,225,300,105,106,L);
												elseif Lm <= 115 then
													return LinFmod(1,300,349,106,115,L);
												elseif Lm <= 116 then
													return LinFmod(1,349,350,115,116,L);
												elseif Lm <= 120 then
													return LinFmod(1,350,399,116,120,L);
												elseif Lm <= 121 then
													return LinFmod(1,399,400,120,121,L);
												elseif Lm <= 130 then
													return LinFmod(1,400,449,121,130,L);
												elseif Lm <= 131 then
													return LinFmod(1,449,450,130,131,L);
												elseif Lm <= 140 then
													return LinFmod(1,450,499,131,140,L);
												elseif Lm <= 141 then
													return LinFmod(1,499,500,140,141,L);
												else
													return LinFmod(1,500,549,141,150,L);
												end
											else
												return 0;
											end
										else
											if Lm <= 1 then
												return 0;
											else
												return CalcStat("LvlExpCostTot",L-1)+CalcStat("LvlExpCost",L);
											end
										end
									elseif SN > "MAIN" then
										if SN < "MAINT" then
											if SN == "MAINC" then
												return RoundDblDown(StatLinInter("PntMPMainC","CreepPntS","ProgBMainC","",L,N,0));
											else
												return 0;
											end
										elseif SN > "MAINT" then
											if SN == "MANDIMMANKINDWILL" then
												return -CalcStat("WillT",L,0.4);
											else
												return 0;
											end
										else
											return RoundDblDown(StatLinInter("PntMPMain","TraitPntS","ProgBMain","AdjUmbarTrait",L,N,0));
										end
									else
										return RoundDblDown(StatLinInter("PntMPMain","ItemPntS","ProgBMain","AdjUmbarItem",L,N,0));
									end
								else
									return 0.1;
								end
							else
								return 2;
							end
						elseif SN > "MANEASILYINSPINHEALP" then
							if SN < "MARINERCDAGILITYTOPARRY" then
								if SN < "MANRDPSVTWOPARRY" then
									if SN < "MANRDPSVONEWILL" then
										if SN < "MANGIFTOFMENFATE" then
											if SN == "MANFOURTHAGEWILL" then
												return CalcStat("WillT",L,1.0);
											else
												return 0;
											end
										elseif SN > "MANGIFTOFMENFATE" then
											if SN == "MANRDPSVONENAME" then
												return "Man of the Fourth Age";
											else
												return 0;
											end
										else
											return CalcStat("FateT",L,1.0);
										end
									elseif SN > "MANRDPSVONEWILL" then
										if SN < "MANRDPSVTWOEVADE" then
											if SN == "MANRDPSVTWOBLOCK" then
												return CalcStat("BalanceOfManBlock",L);
											else
												return 0;
											end
										elseif SN > "MANRDPSVTWOEVADE" then
											if SN == "MANRDPSVTWONAME" then
												return "Balance of Man";
											else
												return 0;
											end
										else
											return CalcStat("BalanceOfManEvade",L);
										end
									else
										return CalcStat("ManFourthAgeWill",L);
									end
								elseif SN > "MANRDPSVTWOPARRY" then
									if SN < "MANRDTRAITWILL" then
										if SN < "MANRDTRAITINHEALP" then
											if SN == "MANRDTRAITFATE" then
												return CalcStat("ManGiftOfMenFate",L);
											else
												return 0;
											end
										elseif SN > "MANRDTRAITINHEALP" then
											if SN == "MANRDTRAITMIGHT" then
												return CalcStat("ManStrongMenMight",L);
											else
												return 0;
											end
										else
											return CalcStat("ManEasilyInspInHealP",L);
										end
									elseif SN > "MANRDTRAITWILL" then
										if SN < "MARINERCDAGILITYTOCRITHIT" then
											if SN == "MANSTRONGMENMIGHT" then
												return CalcStat("MightT",L,1.0);
											else
												return 0;
											end
										elseif SN > "MARINERCDAGILITYTOCRITHIT" then
											if SN == "MARINERCDAGILITYTOOUTHEAL" then
												return 3;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return CalcStat("ManDimMankindWill",L);
									end
								else
									return CalcStat("BalanceOfManParry",L);
								end
							elseif SN > "MARINERCDAGILITYTOPARRY" then
								if SN < "MARINERCDBASEAGILITY" then
									if SN < "MARINERCDARMOURTOCOMPHYMIT" then
										if SN < "MARINERCDAGILITYTOPHYMIT" then
											if SN == "MARINERCDAGILITYTOPHYMAS" then
												return 3;
											else
												return 0;
											end
										elseif SN > "MARINERCDAGILITYTOPHYMIT" then
											if SN == "MARINERCDAGILITYTOTACMIT" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "MARINERCDARMOURTOCOMPHYMIT" then
										if SN < "MARINERCDARMOURTOTACMIT" then
											if SN == "MARINERCDARMOURTONONPHYMIT" then
												return 0.2;
											else
												return 0;
											end
										elseif SN > "MARINERCDARMOURTOTACMIT" then
											if SN == "MARINERCDARMOURTYPE" then
												return 2;
											else
												return 0;
											end
										else
											return 0.2;
										end
									else
										return 1;
									end
								elseif SN > "MARINERCDBASEAGILITY" then
									if SN < "MARINERCDBASEMIGHT" then
										if SN < "MARINERCDBASEICMR" then
											if SN == "MARINERCDBASEFATE" then
												return CalcStat("ClassBaseFate",L);
											else
												return 0;
											end
										elseif SN > "MARINERCDBASEICMR" then
											if SN == "MARINERCDBASEICPR" then
												return CalcStat("ClassBaseICPR",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseICMRL",L);
										end
									elseif SN > "MARINERCDBASEMIGHT" then
										if SN < "MARINERCDBASENCMR" then
											if SN == "MARINERCDBASEMORALE" then
												return CalcStat("ClassBaseMorale",L);
											else
												return 0;
											end
										elseif SN > "MARINERCDBASENCMR" then
											if SN == "MARINERCDBASENCPR" then
												return CalcStat("ClassBaseNCPR",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseNCMRL",L);
										end
									else
										return CalcStat("ClassBaseMightM",L);
									end
								else
									return CalcStat("ClassBaseAgilityM",L);
								end
							else
								return 3;
							end
						else
							return 5;
						end
					elseif SN > "MARINERCDBASEPOWER" then
						if SN < "MATHOMLVLTOILVL" then
							if SN < "MARINERCDTACMASTOOUTHEAL" then
								if SN < "MARINERCDHASPOWER" then
									if SN < "MARINERCDCALCTYPENONPHYMIT" then
										if SN < "MARINERCDBASEWILL" then
											if SN == "MARINERCDBASEVITALITY" then
												return CalcStat("ClassBaseVitality",L);
											else
												return 0;
											end
										elseif SN > "MARINERCDBASEWILL" then
											if SN == "MARINERCDCALCTYPECOMPHYMIT" then
												return 13;
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseWillM",L);
										end
									elseif SN > "MARINERCDCALCTYPENONPHYMIT" then
										if SN < "MARINERCDFATETONCPR" then
											if SN == "MARINERCDCALCTYPETACMIT" then
												return 26;
											else
												return 0;
											end
										elseif SN > "MARINERCDFATETONCPR" then
											if SN == "MARINERCDFATETOPOWER" then
												return 1;
											else
												return 0;
											end
										else
											return 0.07;
										end
									else
										return 13;
									end
								elseif SN > "MARINERCDHASPOWER" then
									if SN < "MARINERCDMIGHTTOPARRY" then
										if SN < "MARINERCDMIGHTTOFINESSE" then
											if SN == "MARINERCDMIGHTTOCRITHIT" then
												return 1.5;
											else
												return 0;
											end
										elseif SN > "MARINERCDMIGHTTOFINESSE" then
											if SN == "MARINERCDMIGHTTOOUTHEAL" then
												return 2;
											else
												return 0;
											end
										else
											return 1.5;
										end
									elseif SN > "MARINERCDMIGHTTOPARRY" then
										if SN < "MARINERCDPHYMITTOCOMPHYMIT" then
											if SN == "MARINERCDMIGHTTOPHYMAS" then
												return 2;
											else
												return 0;
											end
										elseif SN > "MARINERCDPHYMITTOCOMPHYMIT" then
											if SN == "MARINERCDPHYMITTONONPHYMIT" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 1;
									end
								else
									return 1;
								end
							elseif SN > "MARINERCDTACMASTOOUTHEAL" then
								if SN < "MARINERCDWILLTOPHYMIT" then
									if SN < "MARINERCDWILLTOCRITHIT" then
										if SN < "MARINERCDVITALITYTOMORALE" then
											if SN == "MARINERCDVITALITYTOICMR" then
												return 0.012;
											else
												return 0;
											end
										elseif SN > "MARINERCDVITALITYTOMORALE" then
											if SN == "MARINERCDVITALITYTONCMR" then
												return 0.12;
											else
												return 0;
											end
										else
											return 4.5;
										end
									elseif SN > "MARINERCDWILLTOCRITHIT" then
										if SN < "MARINERCDWILLTOOUTHEAL" then
											if SN == "MARINERCDWILLTOFINESSE" then
												return 1.5;
											else
												return 0;
											end
										elseif SN > "MARINERCDWILLTOOUTHEAL" then
											if SN == "MARINERCDWILLTOPHYMAS" then
												return 2;
											else
												return 0;
											end
										else
											return 2;
										end
									else
										return 0.5;
									end
								elseif SN > "MARINERCDWILLTOPHYMIT" then
									if SN < "MASTERYC" then
										if SN < "MASTERY" then
											if SN == "MARINERCDWILLTORESIST" then
												return 1;
											else
												return 0;
											end
										elseif SN > "MASTERY" then
											if SN == "MASTERYADJ" then
												if Lm <= 499 then
													return 1;
												elseif Lm <= 500 then
													return 0.9;
												else
													return 247/300;
												end
											else
												return 0;
											end
										else
											return StatLinInter("PntMPMastery","ItemPntS","ProgBMastery","MasteryAdj",L,N,0);
										end
									elseif SN > "MASTERYC" then
										if SN < "MASTERYT" then
											if SN == "MASTERYOLD" then
												return CalcStat("Mastery",L,N);
											else
												return 0;
											end
										elseif SN > "MASTERYT" then
											if SN == "MASTERYTADJ" then
												if Lm <= 140 then
													return 1;
												elseif Lm <= 141 then
													return 0.9;
												else
													return 247/300;
												end
											else
												return 0;
											end
										else
											return StatLinInter("PntMPMastery","TraitPntS","ProgBMastery","MasteryTAdj",L,N,0);
										end
									else
										return StatLinInter("PntMPMasteryC","CreepPntS","ProgBMasteryC","",L,N,0);
									end
								else
									return 1;
								end
							else
								return 1;
							end
						elseif SN > "MATHOMLVLTOILVL" then
							if SN < "MINSTRELCDAGILITYTOFINESSE" then
								if SN < "MINCOMPOSURETACMIT" then
									if SN < "MINCALLEARENDILLIGHTMIT" then
										if SN < "MIGHTC" then
											if SN == "MIGHT" then
												return CalcStat("Main",L,N);
											else
												return 0;
											end
										elseif SN > "MIGHTC" then
											if SN == "MIGHTT" then
												return CalcStat("MainT",L,N);
											else
												return 0;
											end
										else
											return CalcStat("MainC",L,N);
										end
									elseif SN > "MINCALLEARENDILLIGHTMIT" then
										if SN < "MINCALLOROMEMELLIGHTMIT" then
											if SN == "MINCALLOROMELIGHTMIT" then
												return -CalcStat("LightMitT",L,1.2);
											else
												return 0;
											end
										elseif SN > "MINCALLOROMEMELLIGHTMIT" then
											if SN == "MINCOMPOSURERESIST" then
												return CalcStat("ResistT",L,1.6);
											else
												return 0;
											end
										else
											return -CalcStat("LightMitT",L,1.4);
										end
									else
										return -CalcStat("LightMitT",L,1.2);
									end
								elseif SN > "MINCOMPOSURETACMIT" then
									if SN < "MINENDMORALE" then
										if SN < "MINECHOESBATTLECRITDEF" then
											if SN == "MINCOURAGERESIST" then
												return CalcStat("FearResistT",L,1.0);
											else
												return 0;
											end
										elseif SN > "MINECHOESBATTLECRITDEF" then
											if SN == "MINECHOESBATTLERESIST" then
												return -CalcStat("SongResistT",L,1.0);
											else
												return 0;
											end
										else
											return -CalcStat("CritDefT",L,2.0);
										end
									elseif SN > "MINENDMORALE" then
										if SN < "MINSTRELCDAGILITYTOCRITHIT" then
											if SN == "MINPIERCINGBALFINESSE" then
												return CalcStat("FinesseT",L,CalcStat("Trait12345Choice",N)*0.4);
											else
												return 0;
											end
										elseif SN > "MINSTRELCDAGILITYTOCRITHIT" then
											if SN == "MINSTRELCDAGILITYTOEVADE" then
												return 1;
											else
												return 0;
											end
										else
											return 2;
										end
									else
										return CalcStat("MoraleT",L,CalcStat("Trait12345Choice",N)*0.8);
									end
								else
									return CalcStat("TacMitT",L,1.0);
								end
							elseif SN > "MINSTRELCDAGILITYTOFINESSE" then
								if SN < "MINSTRELCDBASEICMR" then
									if SN < "MINSTRELCDARMOURTOTACMIT" then
										if SN < "MINSTRELCDARMOURTOCOMPHYMIT" then
											if SN == "MINSTRELCDAGILITYTOTACMAS" then
												return 2;
											else
												return 0;
											end
										elseif SN > "MINSTRELCDARMOURTOCOMPHYMIT" then
											if SN == "MINSTRELCDARMOURTONONPHYMIT" then
												return 0.2;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "MINSTRELCDARMOURTOTACMIT" then
										if SN < "MINSTRELCDBASEAGILITY" then
											if SN == "MINSTRELCDARMOURTYPE" then
												return 1;
											else
												return 0;
											end
										elseif SN > "MINSTRELCDBASEAGILITY" then
											if SN == "MINSTRELCDBASEFATE" then
												return CalcStat("ClassBaseFate",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseAgilityM",L);
										end
									else
										return 0.2;
									end
								elseif SN > "MINSTRELCDBASEICMR" then
									if SN < "MINSTRELCDBASENCMR" then
										if SN < "MINSTRELCDBASEMIGHT" then
											if SN == "MINSTRELCDBASEICPR" then
												return CalcStat("ClassBaseICPR",L);
											else
												return 0;
											end
										elseif SN > "MINSTRELCDBASEMIGHT" then
											if SN == "MINSTRELCDBASEMORALE" then
												return CalcStat("ClassBaseMorale",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseMightL",L);
										end
									elseif SN > "MINSTRELCDBASENCMR" then
										if SN < "MINSTRELCDBASEPOWER" then
											if SN == "MINSTRELCDBASENCPR" then
												return CalcStat("ClassBaseNCPR",L);
											else
												return 0;
											end
										elseif SN > "MINSTRELCDBASEPOWER" then
											if SN == "MINSTRELCDBASEVITALITY" then
												return CalcStat("ClassBaseVitality",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBasePower",L);
										end
									else
										return CalcStat("ClassBaseNCMRL",L);
									end
								else
									return CalcStat("ClassBaseICMRL",L);
								end
							else
								return 1;
							end
						else
							return CalcStat("AwardLvlToILvl",L);
						end
					else
						return CalcStat("ClassBasePower",L);
					end
				else
					return 25;
				end
			else
				return 3;
			end
		else
			return CalcStat("CreepAudacityDmgP",L);
		end
	elseif SN > "MINSTRELCDBASEWILL" then
		if SN < "TACMITLPRATPA" then
			if SN < "PNTMPFINESSE" then
				if SN < "PARTBPEPRATPC" then
					if SN < "MORALEADJ" then
						if SN < "MINTOTFINESSE" then
							if SN < "MINSTRELCDVITALITYTOICMR" then
								if SN < "MINSTRELCDHASPOWER" then
									if SN < "MINSTRELCDCALCTYPETACMIT" then
										if SN > "MINSTRELCDCALCTYPECOMPHYMIT" then
											if SN == "MINSTRELCDCALCTYPENONPHYMIT" then
												return 12;
											else
												return 0;
											end
										elseif SN == "MINSTRELCDCALCTYPECOMPHYMIT" then
											return 12;
										else
											return 0;
										end
									elseif SN > "MINSTRELCDCALCTYPETACMIT" then
										if SN < "MINSTRELCDFATETONCPR" then
											if SN == "MINSTRELCDCANBLOCK" then
												if Lm <= 19 then
													return 0;
												else
													return 1;
												end
											else
												return 0;
											end
										elseif SN > "MINSTRELCDFATETONCPR" then
											if SN == "MINSTRELCDFATETOPOWER" then
												return 1;
											else
												return 0;
											end
										else
											return 0.07;
										end
									else
										return 25;
									end
								elseif SN > "MINSTRELCDHASPOWER" then
									if SN < "MINSTRELCDMIGHTTOTACMIT" then
										if SN < "MINSTRELCDMIGHTTOOUTHEAL" then
											if SN == "MINSTRELCDMIGHTTOCRITHIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "MINSTRELCDMIGHTTOOUTHEAL" then
											if SN == "MINSTRELCDMIGHTTOTACMAS" then
												return 2;
											else
												return 0;
											end
										else
											return 2;
										end
									elseif SN > "MINSTRELCDMIGHTTOTACMIT" then
										if SN < "MINSTRELCDPHYMITTONONPHYMIT" then
											if SN == "MINSTRELCDPHYMITTOCOMPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "MINSTRELCDPHYMITTONONPHYMIT" then
											if SN == "MINSTRELCDTACMASTOOUTHEAL" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 1;
									end
								else
									return 1;
								end
							elseif SN > "MINSTRELCDVITALITYTOICMR" then
								if SN < "MINSTRELCDWILLTOTACMAS" then
									if SN < "MINSTRELCDWILLTOCRITHIT" then
										if SN < "MINSTRELCDVITALITYTONCMR" then
											if SN == "MINSTRELCDVITALITYTOMORALE" then
												return 4.5;
											else
												return 0;
											end
										elseif SN > "MINSTRELCDVITALITYTONCMR" then
											if SN == "MINSTRELCDWILLTOBLOCK" then
												return 1;
											else
												return 0;
											end
										else
											return 0.12;
										end
									elseif SN > "MINSTRELCDWILLTOCRITHIT" then
										if SN < "MINSTRELCDWILLTOPHYMIT" then
											if SN == "MINSTRELCDWILLTOEVADE" then
												return 1;
											else
												return 0;
											end
										elseif SN > "MINSTRELCDWILLTOPHYMIT" then
											if SN == "MINSTRELCDWILLTORESIST" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 1;
									end
								elseif SN > "MINSTRELCDWILLTOTACMAS" then
									if SN < "MINTOTCRITHIT" then
										if SN < "MINTACMAS" then
											if SN == "MINSTRELCDWILLTOTACMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "MINTACMAS" then
											if SN == "MINTIMEECHOESBATTLERESIST" then
												return -CalcStat("SongResistT",L,0.6);
											else
												return 0;
											end
										else
											return CalcStat("TacMasT",L,CalcStat("Trait12345Choice",N)*0.4);
										end
									elseif SN > "MINTOTCRITHIT" then
										if SN < "MINTOTFATE" then
											if SN == "MINTOTCRITHITSEL" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({0,0,0,0.4,0.6,0},L);
												end
											else
												return 0;
											end
										elseif SN > "MINTOTFATE" then
											if SN == "MINTOTFATESEL" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({0.2,0.3,0.4,0.5,0.6,0},L);
												end
											else
												return 0;
											end
										else
											return CalcStat("FateT",L,CalcStat("MinToTFateSel",N));
										end
									else
										return CalcStat("CritHitT",L,CalcStat("MinToTCritHitSel",N));
									end
								else
									return 3;
								end
							else
								return 0.012;
							end
						elseif SN > "MINTOTFINESSE" then
							if SN < "MITLIGHTPPRAT" then
								if SN < "MITHEAVYPRATP" then
									if SN < "MINTOTVITALITY" then
										if SN < "MINTOTRESIST" then
											if SN == "MINTOTFINESSESEL" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({0,0,0.2,0.4,0.6,0},L);
												end
											else
												return 0;
											end
										elseif SN > "MINTOTRESIST" then
											if SN == "MINTOTRESISTSEL" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({0,0.2,0.3,0.4,0.5,0},L);
												end
											else
												return 0;
											end
										else
											return CalcStat("ResistT",L,CalcStat("MinToTResistSel",N));
										end
									elseif SN > "MINTOTVITALITY" then
										if SN < "MITHEAVYPBONUS" then
											if SN == "MINTOTVITALITYSEL" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({0,0,0,0,0.4,0},L);
												end
											else
												return 0;
											end
										elseif SN > "MITHEAVYPBONUS" then
											if SN == "MITHEAVYPPRAT" then
												return CalcRatAB(CalcStat("MitHeavyPRatPA",L),CalcStat("MitHeavyPRatPB",L),CalcStat("MitHeavyPRatPCapR",L),N);
											else
												return 0;
											end
										else
											return 0;
										end
									else
										return CalcStat("VitalityT",L,CalcStat("MinToTVitalitySel",N));
									end
								elseif SN > "MITHEAVYPRATP" then
									if SN < "MITHEAVYPRATPCAP" then
										if SN < "MITHEAVYPRATPB" then
											if SN == "MITHEAVYPRATPA" then
												return 180;
											else
												return 0;
											end
										elseif SN > "MITHEAVYPRATPB" then
											if SN == "MITHEAVYPRATPC" then
												return 0.5;
											else
												return 0;
											end
										else
											return CalcStat("BRatRounded",L,"BRatMitHeavy");
										end
									elseif SN > "MITHEAVYPRATPCAP" then
										if SN < "MITIGATION" then
											if SN == "MITHEAVYPRATPCAPR" then
												return CalcStat("MitHeavyPRatPB",L)*CalcStat("MitHeavyPRatPC",L);
											else
												return 0;
											end
										elseif SN > "MITIGATION" then
											if SN == "MITLIGHTPBONUS" then
												return 0;
											else
												return 0;
											end
										else
											return StatLinInter("PntMPMitigation","ItemPntS","ProgBMitigation","AdjUmbarItemMit",L,N,0);
										end
									else
										return 60;
									end
								else
									return CalcPercAB(CalcStat("MitHeavyPRatPA",L),CalcStat("MitHeavyPRatPB",L),CalcStat("MitHeavyPRatPCap",L),N);
								end
							elseif SN > "MITLIGHTPPRAT" then
								if SN < "MITMEDIUMPPRAT" then
									if SN < "MITLIGHTPRATPC" then
										if SN < "MITLIGHTPRATPA" then
											if SN == "MITLIGHTPRATP" then
												return CalcPercAB(CalcStat("MitLightPRatPA",L),CalcStat("MitLightPRatPB",L),CalcStat("MitLightPRatPCap",L),N);
											else
												return 0;
											end
										elseif SN > "MITLIGHTPRATPA" then
											if SN == "MITLIGHTPRATPB" then
												return CalcStat("BRatRounded",L,"BRatMitLight");
											else
												return 0;
											end
										else
											return 120;
										end
									elseif SN > "MITLIGHTPRATPC" then
										if SN < "MITLIGHTPRATPCAPR" then
											if SN == "MITLIGHTPRATPCAP" then
												return 40;
											else
												return 0;
											end
										elseif SN > "MITLIGHTPRATPCAPR" then
											if SN == "MITMEDIUMPBONUS" then
												return 0;
											else
												return 0;
											end
										else
											return CalcStat("MitLightPRatPB",L)*CalcStat("MitLightPRatPC",L);
										end
									else
										return 0.5;
									end
								elseif SN > "MITMEDIUMPPRAT" then
									if SN < "MITMEDIUMPRATPC" then
										if SN < "MITMEDIUMPRATPA" then
											if SN == "MITMEDIUMPRATP" then
												return CalcPercAB(CalcStat("MitMediumPRatPA",L),CalcStat("MitMediumPRatPB",L),CalcStat("MitMediumPRatPCap",L),N);
											else
												return 0;
											end
										elseif SN > "MITMEDIUMPRATPA" then
											if SN == "MITMEDIUMPRATPB" then
												return CalcStat("BRatRounded",L,"BRatMitMedium");
											else
												return 0;
											end
										else
											return 150;
										end
									elseif SN > "MITMEDIUMPRATPC" then
										if SN < "MITMEDIUMPRATPCAPR" then
											if SN == "MITMEDIUMPRATPCAP" then
												return 50;
											else
												return 0;
											end
										elseif SN > "MITMEDIUMPRATPCAPR" then
											if SN == "MORALE" then
												return StatLinInter("PntMPMorale","ItemPntSVital","ProgBMorale","MoraleAdj",L,N,0);
											else
												return 0;
											end
										else
											return CalcStat("MitMediumPRatPB",L)*CalcStat("MitMediumPRatPC",L);
										end
									else
										return 0.5;
									end
								else
									return CalcRatAB(CalcStat("MitMediumPRatPA",L),CalcStat("MitMediumPRatPB",L),CalcStat("MitMediumPRatPCapR",L),N);
								end
							else
								return CalcRatAB(CalcStat("MitLightPRatPA",L),CalcStat("MitLightPRatPB",L),CalcStat("MitLightPRatPCapR",L),N);
							end
						else
							return CalcStat("FinesseT",L,CalcStat("MinToTFinesseSel",N));
						end
					elseif SN > "MORALEADJ" then
						if SN < "PARRY" then
							if SN < "OUTDMGPRATP" then
								if SN < "NCMRT" then
									if SN < "N" then
										if SN > "MORALET" then
											if SN == "MORALETADJ" then
												if Lm <= 25 then
													return 0.5;
												elseif Lm <= 50 then
													return 0.6;
												elseif Lm <= 60 then
													return 0.7;
												elseif Lm <= 65 then
													return 0.8;
												elseif Lm <= 75 then
													return 0.9;
												else
													return 1;
												end
											else
												return 0;
											end
										elseif SN == "MORALET" then
											return StatLinInter("PntMPMorale","TraitPntSVital","ProgBMorale","MoraleTAdj",L,N,0);
										else
											return 0;
										end
									elseif SN > "N" then
										if SN < "NCMRC" then
											if SN == "NCMR" then
												return StatLinInter("PntMPNCMR","ItemPntSVital","ProgBNCMR","",L,N,1);
											else
												return 0;
											end
										elseif SN > "NCMRC" then
											if SN == "NCMRCRAW" then
												return StatLinInter("PntMPNCMRCOld","CreepPntS","ProgBNCMRC","",L,N,99);
											else
												return 0;
											end
										else
											return StatLinInter("PntMPNCMRC","CreepPntS","ProgBNCMRC","",L,N,0);
										end
									else
										return N;
									end
								elseif SN > "NCMRT" then
									if SN < "NCPRT" then
										if SN < "NCPRC" then
											if SN == "NCPR" then
												return StatLinInter("PntMPNCPR","ItemPntSClassic","ProgBNCPR","",L,N,99);
											else
												return 0;
											end
										elseif SN > "NCPRC" then
											if SN == "NCPRCRAW" then
												return StatLinInter("PntMPNCPRCOld","CreepPntS","ProgBNCPRC","",L,N,99);
											else
												return 0;
											end
										else
											return StatLinInter("PntMPNCPRC","CreepPntS","ProgBNCPRC","",L,N,0);
										end
									elseif SN > "NCPRT" then
										if SN < "OUTDMGPBONUS" then
											if SN == "OFFSET" then
												return L+N;
											else
												return 0;
											end
										elseif SN > "OUTDMGPBONUS" then
											if SN == "OUTDMGPPRAT" then
												return CalcRatAB(CalcStat("OutDmgPRatPA",L),CalcStat("OutDmgPRatPB",L),CalcStat("OutDmgPRatPCapR",L),N);
											else
												return 0;
											end
										else
											return 0;
										end
									else
										return StatLinInter("PntMPNCPR","TraitPntSVital","ProgBNCPR","",L,N,99);
									end
								else
									return StatLinInter("PntMPNCMR","TraitPntSVital","ProgBNCMR","",L,N,1);
								end
							elseif SN > "OUTDMGPRATP" then
								if SN < "OUTHEALPPRAT" then
									if SN < "OUTDMGPRATPCAP" then
										if SN < "OUTDMGPRATPB" then
											if SN == "OUTDMGPRATPA" then
												return 600;
											else
												return 0;
											end
										elseif SN > "OUTDMGPRATPB" then
											if SN == "OUTDMGPRATPC" then
												return 0.5;
											else
												return 0;
											end
										else
											return CalcStat("BRatRounded",L,"BRatExtra");
										end
									elseif SN > "OUTDMGPRATPCAP" then
										if SN < "OUTHEAL" then
											if SN == "OUTDMGPRATPCAPR" then
												return CalcStat("OutDmgPRatPB",L)*CalcStat("OutDmgPRatPC",L);
											else
												return 0;
											end
										elseif SN > "OUTHEAL" then
											if SN == "OUTHEALPBONUS" then
												return 0;
											else
												return 0;
											end
										else
											return StatLinInter("PntMPOutHeal","ItemPntS","ProgBOutHeal","AdjUmbarItem",L,N,0);
										end
									else
										return 200;
									end
								elseif SN > "OUTHEALPPRAT" then
									if SN < "OUTHEALPRATPC" then
										if SN < "OUTHEALPRATPA" then
											if SN == "OUTHEALPRATP" then
												return CalcPercAB(CalcStat("OutHealPRatPA",L),CalcStat("OutHealPRatPB",L),CalcStat("OutHealPRatPCap",L),N);
											else
												return 0;
											end
										elseif SN > "OUTHEALPRATPA" then
											if SN == "OUTHEALPRATPB" then
												return CalcStat("BRatRounded",L,"BRatOutHeal");
											else
												return 0;
											end
										else
											return 210;
										end
									elseif SN > "OUTHEALPRATPC" then
										if SN < "OUTHEALPRATPCAPR" then
											if SN == "OUTHEALPRATPCAP" then
												return 70;
											else
												return 0;
											end
										elseif SN > "OUTHEALPRATPCAPR" then
											if SN == "OUTHEALT" then
												return StatLinInter("PntMPOutHeal","TraitPntS","ProgBOutHeal","AdjUmbarTrait",L,N,0);
											else
												return 0;
											end
										else
											return CalcStat("OutHealPRatPB",L)*CalcStat("OutHealPRatPC",L);
										end
									else
										return 0.5;
									end
								else
									return CalcRatAB(CalcStat("OutHealPRatPA",L),CalcStat("OutHealPRatPB",L),CalcStat("OutHealPRatPCapR",L),N);
								end
							else
								return CalcPercAB(CalcStat("OutDmgPRatPA",L),CalcStat("OutDmgPRatPB",L),CalcStat("OutDmgPRatPCap",L),N);
							end
						elseif SN > "PARRY" then
							if SN < "PARTBLOCKMITPRATPC" then
								if SN < "PARRYPRATPCAP" then
									if SN < "PARRYPRATP" then
										if SN < "PARRYPBONUS" then
											if SN == "PARRYC" then
												return CalcStat("BPEC",L,N);
											else
												return 0;
											end
										elseif SN > "PARRYPBONUS" then
											if SN == "PARRYPPRAT" then
												return CalcStat("BPEPPRat",L,N);
											else
												return 0;
											end
										else
											return CalcStat("BPEPBonus",L);
										end
									elseif SN > "PARRYPRATP" then
										if SN < "PARRYPRATPB" then
											if SN == "PARRYPRATPA" then
												return CalcStat("BPEPRatPA",L);
											else
												return 0;
											end
										elseif SN > "PARRYPRATPB" then
											if SN == "PARRYPRATPC" then
												return CalcStat("BPEPRatPC",L);
											else
												return 0;
											end
										else
											return CalcStat("BPEPRatPB",L);
										end
									else
										return CalcStat("BPEPRatP",L,N);
									end
								elseif SN > "PARRYPRATPCAP" then
									if SN < "PARTBLOCKMITPPRAT" then
										if SN < "PARRYT" then
											if SN == "PARRYPRATPCAPR" then
												return CalcStat("BPEPRatPCapR",L);
											else
												return 0;
											end
										elseif SN > "PARRYT" then
											if SN == "PARTBLOCKMITPBONUS" then
												return CalcStat("PartMitPBonus",L);
											else
												return 0;
											end
										else
											return CalcStat("BPET",L,N);
										end
									elseif SN > "PARTBLOCKMITPPRAT" then
										if SN < "PARTBLOCKMITPRATPA" then
											if SN == "PARTBLOCKMITPRATP" then
												return CalcStat("PartMitPRatP",L,N);
											else
												return 0;
											end
										elseif SN > "PARTBLOCKMITPRATPA" then
											if SN == "PARTBLOCKMITPRATPB" then
												return CalcStat("PartMitPRatPB",L);
											else
												return 0;
											end
										else
											return CalcStat("PartMitPRatPA",L);
										end
									else
										return CalcStat("PartMitPPRat",L,N);
									end
								else
									return CalcStat("BPEPRatPCap",L);
								end
							elseif SN > "PARTBLOCKMITPRATPC" then
								if SN < "PARTBLOCKPRATPC" then
									if SN < "PARTBLOCKPPRAT" then
										if SN < "PARTBLOCKMITPRATPCAPR" then
											if SN == "PARTBLOCKMITPRATPCAP" then
												return CalcStat("PartMitPRatPCap",L);
											else
												return 0;
											end
										elseif SN > "PARTBLOCKMITPRATPCAPR" then
											if SN == "PARTBLOCKPBONUS" then
												return CalcStat("PartBPEPBonus",L);
											else
												return 0;
											end
										else
											return CalcStat("PartMitPRatPCapR",L);
										end
									elseif SN > "PARTBLOCKPPRAT" then
										if SN < "PARTBLOCKPRATPA" then
											if SN == "PARTBLOCKPRATP" then
												return CalcStat("PartBPEPRatP",L,N);
											else
												return 0;
											end
										elseif SN > "PARTBLOCKPRATPA" then
											if SN == "PARTBLOCKPRATPB" then
												return CalcStat("PartBPEPRatPB",L);
											else
												return 0;
											end
										else
											return CalcStat("PartBPEPRatPA",L);
										end
									else
										return CalcStat("PartBPEPPRat",L,N);
									end
								elseif SN > "PARTBLOCKPRATPC" then
									if SN < "PARTBPEPPRAT" then
										if SN < "PARTBLOCKPRATPCAPR" then
											if SN == "PARTBLOCKPRATPCAP" then
												return CalcStat("PartBPEPRatPCap",L);
											else
												return 0;
											end
										elseif SN > "PARTBLOCKPRATPCAPR" then
											if SN == "PARTBPEPBONUS" then
												return 0;
											else
												return 0;
											end
										else
											return CalcStat("PartBPEPRatPCapR",L);
										end
									elseif SN > "PARTBPEPPRAT" then
										if SN < "PARTBPEPRATPA" then
											if SN == "PARTBPEPRATP" then
												return CalcPercAB(CalcStat("PartBPEPRatPA",L),CalcStat("PartBPEPRatPB",L),CalcStat("PartBPEPRatPCap",L),N);
											else
												return 0;
											end
										elseif SN > "PARTBPEPRATPA" then
											if SN == "PARTBPEPRATPB" then
												return CalcStat("BRatRounded",L,"BRatPartBPE");
											else
												return 0;
											end
										else
											return 75;
										end
									else
										return CalcRatAB(CalcStat("PartBPEPRatPA",L),CalcStat("PartBPEPRatPB",L),CalcStat("PartBPEPRatPCapR",L),N);
									end
								else
									return CalcStat("PartBPEPRatPC",L);
								end
							else
								return CalcStat("PartMitPRatPC",L);
							end
						else
							return CalcStat("BPE",L,N);
						end
					else
						if Lm <= 25 then
							return 0.5;
						elseif Lm <= 50 then
							return 0.6;
						elseif Lm <= 60 then
							return 0.7;
						elseif Lm <= 79 then
							return 0.8;
						elseif Lm <= 80 then
							return 0.9;
						else
							return 1;
						end
					end
				elseif SN > "PARTBPEPRATPC" then
					if SN < "PERKPOWER" then
						if SN < "PARTFINESSEPRATPB" then
							if SN < "PARTEVADEPRATPB" then
								if SN < "PARTEVADEMITPRATPB" then
									if SN < "PARTEVADEMITPBONUS" then
										if SN > "PARTBPEPRATPCAP" then
											if SN == "PARTBPEPRATPCAPR" then
												return CalcStat("PartBPEPRatPB",L)*CalcStat("PartBPEPRatPC",L);
											else
												return 0;
											end
										elseif SN == "PARTBPEPRATPCAP" then
											return 25;
										else
											return 0;
										end
									elseif SN > "PARTEVADEMITPBONUS" then
										if SN < "PARTEVADEMITPRATP" then
											if SN == "PARTEVADEMITPPRAT" then
												return CalcStat("PartMitPPRat",L,N);
											else
												return 0;
											end
										elseif SN > "PARTEVADEMITPRATP" then
											if SN == "PARTEVADEMITPRATPA" then
												return CalcStat("PartMitPRatPA",L);
											else
												return 0;
											end
										else
											return CalcStat("PartMitPRatP",L,N);
										end
									else
										return CalcStat("PartMitPBonus",L);
									end
								elseif SN > "PARTEVADEMITPRATPB" then
									if SN < "PARTEVADEPBONUS" then
										if SN < "PARTEVADEMITPRATPCAP" then
											if SN == "PARTEVADEMITPRATPC" then
												return CalcStat("PartMitPRatPC",L);
											else
												return 0;
											end
										elseif SN > "PARTEVADEMITPRATPCAP" then
											if SN == "PARTEVADEMITPRATPCAPR" then
												return CalcStat("PartMitPRatPCapR",L);
											else
												return 0;
											end
										else
											return CalcStat("PartMitPRatPCap",L);
										end
									elseif SN > "PARTEVADEPBONUS" then
										if SN < "PARTEVADEPRATP" then
											if SN == "PARTEVADEPPRAT" then
												return CalcStat("PartBPEPPRat",L,N);
											else
												return 0;
											end
										elseif SN > "PARTEVADEPRATP" then
											if SN == "PARTEVADEPRATPA" then
												return CalcStat("PartBPEPRatPA",L);
											else
												return 0;
											end
										else
											return CalcStat("PartBPEPRatP",L,N);
										end
									else
										return CalcStat("PartBPEPBonus",L);
									end
								else
									return CalcStat("PartMitPRatPB",L);
								end
							elseif SN > "PARTEVADEPRATPB" then
								if SN < "PARTFINESSEDMGPRATPB" then
									if SN < "PARTFINESSEDMGPBONUS" then
										if SN < "PARTEVADEPRATPCAP" then
											if SN == "PARTEVADEPRATPC" then
												return CalcStat("PartBPEPRatPC",L);
											else
												return 0;
											end
										elseif SN > "PARTEVADEPRATPCAP" then
											if SN == "PARTEVADEPRATPCAPR" then
												return CalcStat("PartBPEPRatPCapR",L);
											else
												return 0;
											end
										else
											return CalcStat("PartBPEPRatPCap",L);
										end
									elseif SN > "PARTFINESSEDMGPBONUS" then
										if SN < "PARTFINESSEDMGPRATP" then
											if SN == "PARTFINESSEDMGPPRAT" then
												return CalcRatAB(CalcStat("PartFinesseDmgPRatPA",L),CalcStat("PartFinesseDmgPRatPB",L),CalcStat("PartFinesseDmgPRatPCapR",L),N);
											else
												return 0;
											end
										elseif SN > "PARTFINESSEDMGPRATP" then
											if SN == "PARTFINESSEDMGPRATPA" then
												return 150;
											else
												return 0;
											end
										else
											return CalcPercAB(CalcStat("PartFinesseDmgPRatPA",L),CalcStat("PartFinesseDmgPRatPB",L),CalcStat("PartFinesseDmgPRatPCap",L),N);
										end
									else
										return 0;
									end
								elseif SN > "PARTFINESSEDMGPRATPB" then
									if SN < "PARTFINESSEPBONUS" then
										if SN < "PARTFINESSEDMGPRATPCAP" then
											if SN == "PARTFINESSEDMGPRATPC" then
												return 0.5;
											else
												return 0;
											end
										elseif SN > "PARTFINESSEDMGPRATPCAP" then
											if SN == "PARTFINESSEDMGPRATPCAPR" then
												return CalcStat("PartFinesseDmgPRatPB",L)*CalcStat("PartFinesseDmgPRatPC",L);
											else
												return 0;
											end
										else
											return 50;
										end
									elseif SN > "PARTFINESSEPBONUS" then
										if SN < "PARTFINESSEPRATP" then
											if SN == "PARTFINESSEPPRAT" then
												return CalcRatAB(CalcStat("PartFinessePRatPA",L),CalcStat("PartFinessePRatPB",L),CalcStat("PartFinessePRatPCapR",L),N);
											else
												return 0;
											end
										elseif SN > "PARTFINESSEPRATP" then
											if SN == "PARTFINESSEPRATPA" then
												return 150;
											else
												return 0;
											end
										else
											return CalcPercAB(CalcStat("PartFinessePRatPA",L),CalcStat("PartFinessePRatPB",L),CalcStat("PartFinessePRatPCap",L),N);
										end
									else
										return 0;
									end
								else
									return CalcStat("BRatRounded",L,"BRatStandard");
								end
							else
								return CalcStat("PartBPEPRatPB",L);
							end
						elseif SN > "PARTFINESSEPRATPB" then
							if SN < "PARTPARRYMITPRATPB" then
								if SN < "PARTMITPRATPB" then
									if SN < "PARTMITPBONUS" then
										if SN < "PARTFINESSEPRATPCAP" then
											if SN == "PARTFINESSEPRATPC" then
												return 0.5;
											else
												return 0;
											end
										elseif SN > "PARTFINESSEPRATPCAP" then
											if SN == "PARTFINESSEPRATPCAPR" then
												return CalcStat("PartFinessePRatPB",L)*CalcStat("PartFinessePRatPC",L);
											else
												return 0;
											end
										else
											return 50;
										end
									elseif SN > "PARTMITPBONUS" then
										if SN < "PARTMITPRATP" then
											if SN == "PARTMITPPRAT" then
												return CalcRatAB(CalcStat("PartMitPRatPA",L),CalcStat("PartMitPRatPB",L),CalcStat("PartMitPRatPCapR",L),N);
											else
												return 0;
											end
										elseif SN > "PARTMITPRATP" then
											if SN == "PARTMITPRATPA" then
												return 105;
											else
												return 0;
											end
										else
											return CalcPercAB(CalcStat("PartMitPRatPA",L),CalcStat("PartMitPRatPB",L),CalcStat("PartMitPRatPCap",L),N);
										end
									else
										return 0.1;
									end
								elseif SN > "PARTMITPRATPB" then
									if SN < "PARTPARRYMITPBONUS" then
										if SN < "PARTMITPRATPCAP" then
											if SN == "PARTMITPRATPC" then
												return 0.5;
											else
												return 0;
											end
										elseif SN > "PARTMITPRATPCAP" then
											if SN == "PARTMITPRATPCAPR" then
												return CalcStat("PartMitPRatPB",L)*CalcStat("PartMitPRatPC",L);
											else
												return 0;
											end
										else
											return 35;
										end
									elseif SN > "PARTPARRYMITPBONUS" then
										if SN < "PARTPARRYMITPRATP" then
											if SN == "PARTPARRYMITPPRAT" then
												return CalcStat("PartMitPPRat",L,N);
											else
												return 0;
											end
										elseif SN > "PARTPARRYMITPRATP" then
											if SN == "PARTPARRYMITPRATPA" then
												return CalcStat("PartMitPRatPA",L);
											else
												return 0;
											end
										else
											return CalcStat("PartMitPRatP",L,N);
										end
									else
										return CalcStat("PartMitPBonus",L);
									end
								else
									return CalcStat("BRatRounded",L,"BRatPartBPE");
								end
							elseif SN > "PARTPARRYMITPRATPB" then
								if SN < "PARTPARRYPRATPB" then
									if SN < "PARTPARRYPBONUS" then
										if SN < "PARTPARRYMITPRATPCAP" then
											if SN == "PARTPARRYMITPRATPC" then
												return CalcStat("PartMitPRatPC",L);
											else
												return 0;
											end
										elseif SN > "PARTPARRYMITPRATPCAP" then
											if SN == "PARTPARRYMITPRATPCAPR" then
												return CalcStat("PartMitPRatPCapR",L);
											else
												return 0;
											end
										else
											return CalcStat("PartMitPRatPCap",L);
										end
									elseif SN > "PARTPARRYPBONUS" then
										if SN < "PARTPARRYPRATP" then
											if SN == "PARTPARRYPPRAT" then
												return CalcStat("PartBPEPPRat",L,N);
											else
												return 0;
											end
										elseif SN > "PARTPARRYPRATP" then
											if SN == "PARTPARRYPRATPA" then
												return CalcStat("PartBPEPRatPA",L);
											else
												return 0;
											end
										else
											return CalcStat("PartBPEPRatP",L,N);
										end
									else
										return CalcStat("PartBPEPBonus",L);
									end
								elseif SN > "PARTPARRYPRATPB" then
									if SN < "PERKMORALE" then
										if SN < "PARTPARRYPRATPCAP" then
											if SN == "PARTPARRYPRATPC" then
												return CalcStat("PartBPEPRatPC",L);
											else
												return 0;
											end
										elseif SN > "PARTPARRYPRATPCAP" then
											if SN == "PARTPARRYPRATPCAPR" then
												return CalcStat("PartBPEPRatPCapR",L);
											else
												return 0;
											end
										else
											return CalcStat("PartBPEPRatPCap",L);
										end
									elseif SN > "PERKMORALE" then
										if SN < "PERKNCPR" then
											if SN == "PERKNCMR" then
												return CalcStat("FoodNCMRL",L);
											else
												return 0;
											end
										elseif SN > "PERKNCPR" then
											if SN == "PERKPHYMIT" then
												return CalcStat("PhyMitT",L,0.2*N);
											else
												return 0;
											end
										else
											return CalcStat("FoodNCPRL",L);
										end
									else
										return DataTableValue({10,20,30,40},L);
									end
								else
									return CalcStat("PartBPEPRatPB",L);
								end
							else
								return CalcStat("PartMitPRatPB",L);
							end
						else
							return CalcStat("BRatRounded",L,"BRatStandard");
						end
					elseif SN > "PERKPOWER" then
						if SN < "PHYMITMPBONUS" then
							if SN < "PHYMITHPBONUS" then
								if SN < "PHYDMGPRATPCAP" then
									if SN < "PHYDMGPRATP" then
										if SN < "PHYDMGPBONUS" then
											if SN == "PERKTACMIT" then
												return CalcStat("TacMitT",L,0.2*N);
											else
												return 0;
											end
										elseif SN > "PHYDMGPBONUS" then
											if SN == "PHYDMGPPRAT" then
												return CalcStat("OutDmgPPRat",L,N);
											else
												return 0;
											end
										else
											return CalcStat("OutDmgPBonus",L);
										end
									elseif SN > "PHYDMGPRATP" then
										if SN < "PHYDMGPRATPB" then
											if SN == "PHYDMGPRATPA" then
												return CalcStat("OutDmgPRatPA",L);
											else
												return 0;
											end
										elseif SN > "PHYDMGPRATPB" then
											if SN == "PHYDMGPRATPC" then
												return CalcStat("OutDmgPRatPC",L);
											else
												return 0;
											end
										else
											return CalcStat("OutDmgPRatPB",L);
										end
									else
										return CalcStat("OutDmgPRatP",L,N);
									end
								elseif SN > "PHYDMGPRATPCAP" then
									if SN < "PHYMASOLD" then
										if SN < "PHYMAS" then
											if SN == "PHYDMGPRATPCAPR" then
												return CalcStat("OutDmgPRatPCapR",L);
											else
												return 0;
											end
										elseif SN > "PHYMAS" then
											if SN == "PHYMASC" then
												return CalcStat("MasteryC",L,N);
											else
												return 0;
											end
										else
											return CalcStat("Mastery",L,N);
										end
									elseif SN > "PHYMASOLD" then
										if SN < "PHYMIT" then
											if SN == "PHYMAST" then
												return CalcStat("MasteryT",L,N);
											else
												return 0;
											end
										elseif SN > "PHYMIT" then
											if SN == "PHYMITC" then
												return StatLinInter("PntMPPhyMitC","CreepPntS","ProgBMitigationC","",L,N,0);
											else
												return 0;
											end
										else
											return StatLinInter("PntMPPhyMit","ItemPntS","ProgBMitigation","AdjUmbarItemMit",L,N,0);
										end
									else
										return CalcStat("Mastery",L,N);
									end
								else
									return CalcStat("OutDmgPRatPCap",L);
								end
							elseif SN > "PHYMITHPBONUS" then
								if SN < "PHYMITLPBONUS" then
									if SN < "PHYMITHPRATPB" then
										if SN < "PHYMITHPRATP" then
											if SN == "PHYMITHPPRAT" then
												return CalcStat("MitHeavyPPRat",L,N);
											else
												return 0;
											end
										elseif SN > "PHYMITHPRATP" then
											if SN == "PHYMITHPRATPA" then
												return CalcStat("MitHeavyPRatPA",L);
											else
												return 0;
											end
										else
											return CalcStat("MitHeavyPRatP",L,N);
										end
									elseif SN > "PHYMITHPRATPB" then
										if SN < "PHYMITHPRATPCAP" then
											if SN == "PHYMITHPRATPC" then
												return CalcStat("MitHeavyPRatPC",L);
											else
												return 0;
											end
										elseif SN > "PHYMITHPRATPCAP" then
											if SN == "PHYMITHPRATPCAPR" then
												return CalcStat("MitHeavyPRatPCapR",L);
											else
												return 0;
											end
										else
											return CalcStat("MitHeavyPRatPCap",L);
										end
									else
										return CalcStat("MitHeavyPRatPB",L);
									end
								elseif SN > "PHYMITLPBONUS" then
									if SN < "PHYMITLPRATPB" then
										if SN < "PHYMITLPRATP" then
											if SN == "PHYMITLPPRAT" then
												return CalcStat("MitLightPPRat",L,N);
											else
												return 0;
											end
										elseif SN > "PHYMITLPRATP" then
											if SN == "PHYMITLPRATPA" then
												return CalcStat("MitLightPRatPA",L);
											else
												return 0;
											end
										else
											return CalcStat("MitLightPRatP",L,N);
										end
									elseif SN > "PHYMITLPRATPB" then
										if SN < "PHYMITLPRATPCAP" then
											if SN == "PHYMITLPRATPC" then
												return CalcStat("MitLightPRatPC",L);
											else
												return 0;
											end
										elseif SN > "PHYMITLPRATPCAP" then
											if SN == "PHYMITLPRATPCAPR" then
												return CalcStat("MitLightPRatPCapR",L);
											else
												return 0;
											end
										else
											return CalcStat("MitLightPRatPCap",L);
										end
									else
										return CalcStat("MitLightPRatPB",L);
									end
								else
									return CalcStat("MitLightPBonus",L);
								end
							else
								return CalcStat("MitHeavyPBonus",L);
							end
						elseif SN > "PHYMITMPBONUS" then
							if SN < "PNTMPARMOURC" then
								if SN < "PHYMITT" then
									if SN < "PHYMITMPRATPB" then
										if SN < "PHYMITMPRATP" then
											if SN == "PHYMITMPPRAT" then
												return CalcStat("MitMediumPPRat",L,N);
											else
												return 0;
											end
										elseif SN > "PHYMITMPRATP" then
											if SN == "PHYMITMPRATPA" then
												return CalcStat("MitMediumPRatPA",L);
											else
												return 0;
											end
										else
											return CalcStat("MitMediumPRatP",L,N);
										end
									elseif SN > "PHYMITMPRATPB" then
										if SN < "PHYMITMPRATPCAP" then
											if SN == "PHYMITMPRATPC" then
												return CalcStat("MitMediumPRatPC",L);
											else
												return 0;
											end
										elseif SN > "PHYMITMPRATPCAP" then
											if SN == "PHYMITMPRATPCAPR" then
												return CalcStat("MitMediumPRatPCapR",L);
											else
												return 0;
											end
										else
											return CalcStat("MitMediumPRatPCap",L);
										end
									else
										return CalcStat("MitMediumPRatPB",L);
									end
								elseif SN > "PHYMITT" then
									if SN < "PLAYERBASEPARRY" then
										if SN < "PLAYERBASEEVADE" then
											if SN == "PHYRESISTT" then
												return CalcStat("ResistAddT",L,N);
											else
												return 0;
											end
										elseif SN > "PLAYERBASEEVADE" then
											if SN == "PLAYERBASEMORALE" then
												return 52.5;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "PLAYERBASEPARRY" then
										if SN < "PLAYERBASETACMAS" then
											if SN == "PLAYERBASEPHYMAS" then
												return 11.5;
											else
												return 0;
											end
										elseif SN > "PLAYERBASETACMAS" then
											if SN == "PNTMPARMOUR" then
												return 4.4/1200;
											else
												return 0;
											end
										else
											return 11.5;
										end
									else
										return 3;
									end
								else
									return StatLinInter("PntMPPhyMit","TraitPntS","ProgBMitigation","AdjUmbarTraitMit",L,N,0);
								end
							elseif SN > "PNTMPARMOURC" then
								if SN < "PNTMPCOMBATDAMAGEMOD" then
									if SN < "PNTMPBPE" then
										if SN < "PNTMPARMOURT" then
											if SN == "PNTMPARMOURPENT" then
												return 72/1200;
											else
												return 0;
											end
										elseif SN > "PNTMPARMOURT" then
											if SN == "PNTMPARMOURVIRTUES" then
												return 24/1200;
											else
												return 0;
											end
										else
											return 25/1200;
										end
									elseif SN > "PNTMPBPE" then
										if SN < "PNTMPCLASSBASEICPR" then
											if SN == "PNTMPBPEC" then
												return 20430/6;
											else
												return 0;
											end
										elseif SN > "PNTMPCLASSBASEICPR" then
											if SN == "PNTMPCLASSBASENCPR" then
												return 0.25;
											else
												return 0;
											end
										else
											return 0.125;
										end
									else
										return 42/1200;
									end
								elseif SN > "PNTMPCOMBATDAMAGEMOD" then
									if SN < "PNTMPCRITHITC" then
										if SN < "PNTMPCRITDEFC" then
											if SN == "PNTMPCRITDEF" then
												return 40/1200;
											else
												return 0;
											end
										elseif SN > "PNTMPCRITDEFC" then
											if SN == "PNTMPCRITHIT" then
												return 20/1200;
											else
												return 0;
											end
										else
											return 20430/6;
										end
									elseif SN > "PNTMPCRITHITC" then
										if SN < "PNTMPFATE" then
											if SN == "PNTMPDMGTYPEMIT" then
												return 60/1200;
											else
												return 0;
											end
										elseif SN > "PNTMPFATE" then
											if SN == "PNTMPFATEC" then
												return 1803/6;
											else
												return 0;
											end
										else
											return 1.25;
										end
									else
										return 30610/6;
									end
								else
									return 300/1200;
								end
							else
								return 16990/6;
							end
						else
							return CalcStat("MitMediumPBonus",L);
						end
					else
						return DataTableValue({10,20,30,40},L);
					end
				else
					return 0.5;
				end
			elseif SN > "PNTMPFINESSE" then
				if SN < "REVERSE" then
					if SN < "PROGBINHEAL" then
						if SN < "PNTMPSHIELDBLOCK" then
							if SN < "PNTMPMITIGATION" then
								if SN < "PNTMPICPR" then
									if SN < "PNTMPFOODRESIST" then
										if SN > "PNTMPFINESSEC" then
											if SN == "PNTMPFINESSET" then
												return 36/1200;
											else
												return 0;
											end
										elseif SN == "PNTMPFINESSEC" then
											return 20430/6;
										else
											return 0;
										end
									elseif SN > "PNTMPFOODRESIST" then
										if SN < "PNTMPICMRC" then
											if SN == "PNTMPICMR" then
												return 0.015;
											else
												return 0;
											end
										elseif SN > "PNTMPICMRC" then
											if SN == "PNTMPICMRCOLD" then
												return 27;
											else
												return 0;
											end
										else
											return 41.2;
										end
									else
										return 30/1200;
									end
								elseif SN > "PNTMPICPR" then
									if SN < "PNTMPMAIN" then
										if SN < "PNTMPICPRCOLD" then
											if SN == "PNTMPICPRC" then
												return 4.75;
											else
												return 0;
											end
										elseif SN > "PNTMPICPRCOLD" then
											if SN == "PNTMPINHEAL" then
												return 40/1200;
											else
												return 0;
											end
										else
											return 3.125;
										end
									elseif SN > "PNTMPMAIN" then
										if SN < "PNTMPMASTERY" then
											if SN == "PNTMPMAINC" then
												return 1803/6;
											else
												return 0;
											end
										elseif SN > "PNTMPMASTERY" then
											if SN == "PNTMPMASTERYC" then
												return 30610/6;
											else
												return 0;
											end
										else
											return 17/1200;
										end
									else
										return 0.5;
									end
								else
									return 0.0625;
								end
							elseif SN > "PNTMPMITIGATION" then
								if SN < "PNTMPNCPRCOLD" then
									if SN < "PNTMPNCMRC" then
										if SN < "PNTMPMORALEVIRTUES" then
											if SN == "PNTMPMORALE" then
												return 1;
											else
												return 0;
											end
										elseif SN > "PNTMPMORALEVIRTUES" then
											if SN == "PNTMPNCMR" then
												return 0.15;
											else
												return 0;
											end
										else
											return 0.75;
										end
									elseif SN > "PNTMPNCMRC" then
										if SN < "PNTMPNCPR" then
											if SN == "PNTMPNCMRCOLD" then
												return 108;
											else
												return 0;
											end
										elseif SN > "PNTMPNCPR" then
											if SN == "PNTMPNCPRC" then
												return 19;
											else
												return 0;
											end
										else
											return 0.5;
										end
									else
										return 164.8;
									end
								elseif SN > "PNTMPNCPRCOLD" then
									if SN < "PNTMPPOWER" then
										if SN < "PNTMPPHYMIT" then
											if SN == "PNTMPOUTHEAL" then
												return 30/1200;
											else
												return 0;
											end
										elseif SN > "PNTMPPHYMIT" then
											if SN == "PNTMPPHYMITC" then
												return 16990/6;
											else
												return 0;
											end
										else
											return 36/1200;
										end
									elseif SN > "PNTMPPOWER" then
										if SN < "PNTMPRESIST" then
											if SN == "PNTMPPOWERT" then
												return 0.6666;
											else
												return 0;
											end
										elseif SN > "PNTMPRESIST" then
											if SN == "PNTMPRESISTC" then
												return 30610/6;
											else
												return 0;
											end
										else
											return 36/1200;
										end
									else
										return 1;
									end
								else
									return 12.5;
								end
							else
								return 28/1200;
							end
						elseif SN > "PNTMPSHIELDBLOCK" then
							if SN < "PROGBBPEC" then
								if SN < "POWER" then
									if SN < "PNTMPVITALITY" then
										if SN < "PNTMPTACMIT" then
											if SN == "PNTMPTACHPS" then
												return 0.0875;
											else
												return 0;
											end
										elseif SN > "PNTMPTACMIT" then
											if SN == "PNTMPTACMITC" then
												return 16990/6;
											else
												return 0;
											end
										else
											return 36/1200;
										end
									elseif SN > "PNTMPVITALITY" then
										if SN < "PNTMPVITALITYT" then
											if SN == "PNTMPVITALITYC" then
												return 4200/6;
											else
												return 0;
											end
										elseif SN > "PNTMPVITALITYT" then
											if SN == "POISONRESISTT" then
												return CalcStat("ResistAddT",L,N);
											else
												return 0;
											end
										else
											return 0.225;
										end
									else
										return 0.175;
									end
								elseif SN > "POWER" then
									if SN < "PROGBARMOURHEAVY" then
										if SN < "PROGBARMOUR" then
											if SN == "POWERT" then
												return StatLinInter("PntMPPowerT","TraitPntSVital","ProgBPower","",L,N,0);
											else
												return 0;
											end
										elseif SN > "PROGBARMOUR" then
											if SN == "PROGBARMOURC" then
												return CalcStat("CreepProgB",L);
											else
												return 0;
											end
										else
											return CalcStat("BRatProgB",L,"BRatMitMedium");
										end
									elseif SN > "PROGBARMOURHEAVY" then
										if SN < "PROGBARMOURMEDIUM" then
											if SN == "PROGBARMOURLIGHT" then
												return CalcStat("BRatProgB",L,"BRatMitLight");
											else
												return 0;
											end
										elseif SN > "PROGBARMOURMEDIUM" then
											if SN == "PROGBBPE" then
												return CalcStat("BRatProgB",L,"BRatStandard");
											else
												return 0;
											end
										else
											return CalcStat("BRatProgB",L,"BRatMitMedium");
										end
									else
										return CalcStat("BRatProgB",L,"BRatMitHeavy");
									end
								else
									return StatLinInter("PntMPPower","ItemPntSVital","ProgBPower","",L,N,0);
								end
							elseif SN > "PROGBBPEC" then
								if SN < "PROGBFATEC" then
									if SN < "PROGBCRITHIT" then
										if SN < "PROGBCRITDEF" then
											if SN == "PROGBCOMBATDAMAGEMOD" then
												if Lm <= 25 then
													return LinFmod(1,5,45.58309,1,25,L);
												elseif Lm <= 50 then
													return LinFmod(1,45.58309,120,25,50,L);
												elseif Lm <= 60 then
													return LinFmod(1,120,175.56,50,60,L);
												elseif Lm <= 65 then
													return LinFmod(1,175.56,200.79,60,65,L);
												elseif Lm <= 75 then
													return LinFmod(1,200.79,292.5,65,75,L);
												elseif Lm <= 85 then
													return LinFmod(1,292.5,421.2,75,85,L);
												elseif Lm <= 95 then
													return LinFmod(1,421.2,600.3,85,95,L);
												elseif Lm <= 100 then
													return LinFmod(1,600.3,774,95,100,L);
												elseif Lm <= 105 then
													return LinFmod(1,774,985.5,100,105,L);
												elseif Lm <= 115 then
													return LinFmod(1,985.5,1350,105,115,L);
												elseif Lm <= 120 then
													return LinFmod(1,1350,1710,115,120,L);
												elseif Lm <= 130 then
													return LinFmod(1,1710,2330.25,120,130,L);
												elseif Lm <= 140 then
													return LinFmod(1,2330.25,3600,130,140,L);
												else
													return LinFmod(1,4010,5535,141,150,L);
												end
											else
												return 0;
											end
										elseif SN > "PROGBCRITDEF" then
											if SN == "PROGBCRITDEFC" then
												return CalcStat("CreepProgB",L);
											else
												return 0;
											end
										else
											return CalcStat("BRatProgB",L,"BRatStandard");
										end
									elseif SN > "PROGBCRITHIT" then
										if SN < "PROGBENERGY" then
											if SN == "PROGBCRITHITC" then
												return CalcStat("CreepProgB",L);
											else
												return 0;
											end
										elseif SN > "PROGBENERGY" then
											if SN == "PROGBFATE" then
												return CalcStat("ProgBEnergy",L);
											else
												return 0;
											end
										else
											if Lm <= 50 then
												return LinFmod(1,4,8,1,50,L);
											elseif Lm <= 60 then
												return LinFmod(1,8,10.6,50,60,L);
											elseif Lm <= 65 then
												return LinFmod(1,10.6,13.2,60,65,L);
											elseif Lm <= 75 then
												return LinFmod(1,13.2,19.8,65,75,L);
											elseif Lm <= 85 then
												return LinFmod(1,19.8,29.8,75,85,L);
											elseif Lm <= 95 then
												return LinFmod(1,29.8,39.6,85,95,L);
											elseif Lm <= 100 then
												return LinFmod(1,39.6,52,95,100,L);
											elseif Lm <= 105 then
												return LinFmod(1,52,70,100,105,L);
											elseif Lm <= 115 then
												return LinFmod(1,78,106,106,115,L);
											elseif Lm <= 120 then
												return LinFmod(1,122,132,116,120,L);
											elseif Lm <= 130 then
												return LinFmod(1,152,198,121,130,L);
											elseif Lm <= 140 then
												return LinFmod(1,228,396,131,140,L);
											elseif Lm <= 150 then
												return LinFmod(1,456,800,141,150,L);
											else
												return LinFmod(1,800,1600,151,160,L);
											end
										end
									else
										return CalcStat("BRatProgB",L,"BRatExtra");
									end
								elseif SN > "PROGBFATEC" then
									if SN < "PROGBICMR" then
										if SN < "PROGBFINESSEC" then
											if SN == "PROGBFINESSE" then
												return CalcStat("BRatProgB",L,"BRatStandard");
											else
												return 0;
											end
										elseif SN > "PROGBFINESSEC" then
											if SN == "PROGBHEALTH" then
												if Lm <= 50 then
													return LinFmod(1,8,60,1,50,L);
												elseif Lm <= 60 then
													return LinFmod(1,60,80,50,60,L);
												elseif Lm <= 65 then
													return LinFmod(1,80,100,60,65,L);
												elseif Lm <= 75 then
													return LinFmod(1,100,150,65,75,L);
												elseif Lm <= 85 then
													return LinFmod(1,150,226,75,85,L);
												elseif Lm <= 95 then
													return LinFmod(1,226,300,85,95,L);
												elseif Lm <= 100 then
													return LinFmod(1,300,450,95,100,L);
												elseif Lm <= 105 then
													return LinFmod(1,450,600,100,105,L);
												elseif Lm <= 115 then
													return LinFmod(1,660,900,106,115,L);
												elseif Lm <= 120 then
													return LinFmod(1,1040,1120,116,120,L);
												elseif Lm <= 130 then
													return LinFmod(1,1280,1680,121,130,L);
												elseif Lm <= 140 then
													return LinFmod(1,1940,3360,131,140,L);
												elseif Lm <= 150 then
													return LinFmod(1,3860,6800,141,150,L);
												else
													return LinFmod(1,6800,13600,151,160,L);
												end
											else
												return 0;
											end
										else
											return CalcStat("CreepProgB",L);
										end
									elseif SN > "PROGBICMR" then
										if SN < "PROGBICPR" then
											if SN == "PROGBICMRC" then
												return CalcStat("CreepProgB",L);
											else
												return 0;
											end
										elseif SN > "PROGBICPR" then
											if SN == "PROGBICPRC" then
												return CalcStat("CreepProgB",L);
											else
												return 0;
											end
										else
											return CalcStat("ProgBEnergy",L);
										end
									else
										return CalcStat("ProgBHealth",L);
									end
								else
									return CalcStat("CreepProgB",L);
								end
							else
								return CalcStat("CreepProgB",L);
							end
						else
							return 80/1200;
						end
					elseif SN > "PROGBINHEAL" then
						if SN < "REAVERCDHASPOWER" then
							if SN < "PROGBRESISTC" then
								if SN < "PROGBMORALE" then
									if SN < "PROGBMASTERY" then
										if SN > "PROGBMAIN" then
											if SN == "PROGBMAINC" then
												return CalcStat("CreepProgB",L);
											else
												return 0;
											end
										elseif SN == "PROGBMAIN" then
											return CalcStat("StdProg",L,1.75);
										else
											return 0;
										end
									elseif SN > "PROGBMASTERY" then
										if SN < "PROGBMITIGATION" then
											if SN == "PROGBMASTERYC" then
												return CalcStat("CreepProgB",L);
											else
												return 0;
											end
										elseif SN > "PROGBMITIGATION" then
											if SN == "PROGBMITIGATIONC" then
												return CalcStat("CreepProgB",L);
											else
												return 0;
											end
										else
											return CalcStat("BRatProgB",L,"BRatMitMedium");
										end
									else
										return CalcStat("BRatProgB",L,"BRatExtra");
									end
								elseif SN > "PROGBMORALE" then
									if SN < "PROGBNCPRC" then
										if SN < "PROGBNCMRC" then
											if SN == "PROGBNCMR" then
												return CalcStat("ProgBHealth",L);
											else
												return 0;
											end
										elseif SN > "PROGBNCMRC" then
											if SN == "PROGBNCPR" then
												return CalcStat("ProgBEnergy",L);
											else
												return 0;
											end
										else
											return CalcStat("CreepProgB",L);
										end
									elseif SN > "PROGBNCPRC" then
										if SN < "PROGBPOWER" then
											if SN == "PROGBOUTHEAL" then
												return CalcStat("BRatProgB",L,"BRatOutHeal");
											else
												return 0;
											end
										elseif SN > "PROGBPOWER" then
											if SN == "PROGBRESIST" then
												return CalcStat("BRatProgB",L,"BRatExtra");
											else
												return 0;
											end
										else
											return CalcStat("ProgBEnergy",L);
										end
									else
										return CalcStat("CreepProgB",L);
									end
								else
									return CalcStat("ProgBHealth",L);
								end
							elseif SN > "PROGBRESISTC" then
								if SN < "PROGEXTHIGHLINEXPRND" then
									if SN < "PROGEXTCOMHIGHRAW" then
										if SN < "PROGBVITALITY" then
											if SN == "PROGBTACHPS" then
												return CalcStat("ProgBHealth",L);
											else
												return 0;
											end
										elseif SN > "PROGBVITALITY" then
											if SN == "PROGBVITALITYC" then
												return CalcStat("CreepProgB",L);
											else
												return 0;
											end
										else
											return CalcStat("ProgBHealth",L);
										end
									elseif SN > "PROGEXTCOMHIGHRAW" then
										if SN < "PROGEXTCOMLOWRAW" then
											if SN == "PROGEXTCOMHIGHRND" then
												if Lm <= 121 then
													return ExpFmod(N,121,20,L,0);
												elseif Lm <= 125 then
													return ExpFmod(CalcStat("ProgExtComHighRnd",121,N),122,5.5,L,0);
												elseif Lm <= 126 then
													return ExpFmod(CalcStat("ProgExtComHighRnd",125,N),126,20,L,0);
												elseif Lm <= 130 then
													return ExpFmod(CalcStat("ProgExtComHighRnd",126,N),127,5.5,L,0);
												elseif Lm <= 131 then
													return ExpFmod(CalcStat("ProgExtComHighRnd",130,N),131,20,L,0);
												elseif Lm <= 150 then
													return ExpFmod(CalcStat("ProgExtComHighRnd",131,N),132,5.5,L,0);
												else
													return CalcStat("ProgExtComHighRnd",150,N);
												end
											else
												return 0;
											end
										elseif SN > "PROGEXTCOMLOWRAW" then
											if SN == "PROGEXTCOMLOWRND" then
												if Lm <= 116 then
													return ExpFmod(N,116,20,L,0);
												elseif Lm <= 120 then
													return ExpFmod(CalcStat("ProgExtComLowRnd",116,N),117,5.5,L,0);
												else
													return CalcStat("ProgExtComHighRnd",L,CalcStat("ProgExtComLowRnd",120,N));
												end
											else
												return 0;
											end
										else
											if Lm <= 116 then
												return ExpFmod(N,116,20,L,nil);
											elseif Lm <= 120 then
												return ExpFmod(CalcStat("ProgExtComLowRaw",116,N),117,5.5,L,nil);
											else
												return CalcStat("ProgExtComHighRaw",L,CalcStat("ProgExtComLowRaw",120,N));
											end
										end
									else
										if Lm <= 121 then
											return ExpFmod(N,121,20,L,nil);
										elseif Lm <= 125 then
											return ExpFmod(CalcStat("ProgExtComHighRaw",121,N),122,5.5,L,nil);
										elseif Lm <= 126 then
											return ExpFmod(CalcStat("ProgExtComHighRaw",125,N),126,20,L,nil);
										elseif Lm <= 130 then
											return ExpFmod(CalcStat("ProgExtComHighRaw",126,N),127,5.5,L,nil);
										elseif Lm <= 131 then
											return ExpFmod(CalcStat("ProgExtComHighRaw",130,N),131,20,L,nil);
										elseif Lm <= 150 then
											return ExpFmod(CalcStat("ProgExtComHighRaw",131,N),132,5.5,L,nil);
										else
											return CalcStat("ProgExtComHighRaw",150,N);
										end
									end
								elseif SN > "PROGEXTHIGHLINEXPRND" then
									if SN < "REAVERCANBLOCK" then
										if SN < "PROGEXTMEDEXPRAW" then
											if SN == "PROGEXTLOWEXPRND" then
												if Lm <= 115 then
													return ExpFmod(N,106,5.5,L,0);
												else
													return CalcStat("ProgExtComLowRnd",L,CalcStat("ProgExtLowExpRnd",115,N));
												end
											else
												return 0;
											end
										elseif SN > "PROGEXTMEDEXPRAW" then
											if SN == "PROGEXTMPEXPRND" then
												if Lm <= 114 then
													return ExpFmod(N,106,7.5,L,0);
												elseif Lm <= 115 then
													return 2*N;
												elseif Lm <= 119 then
													return ExpFmod(CalcStat("ProgExtMpExpRnd",115,N),116,25,L,0);
												elseif Lm <= 120 then
													return RoundDbl((16/3)*N);
												else
													return CalcStat("ProgExtComHighRnd",L,CalcStat("ProgExtMpExpRnd",120,N));
												end
											else
												return 0;
											end
										else
											if Lm <= 106 then
												return ExpFmod(N,106,10,L,nil);
											elseif Lm <= 115 then
												return ExpFmod(CalcStat("ProgExtMedExpRaw",106,N),107,5.5,L,nil);
											else
												return CalcStat("ProgExtComLowRaw",L,CalcStat("ProgExtMedExpRaw",115,N));
											end
										end
									elseif SN > "REAVERCANBLOCK" then
										if SN < "REAVERCDCALCTYPENONPHYMIT" then
											if SN == "REAVERCDCALCTYPECOMPHYMIT" then
												return 13;
											else
												return 0;
											end
										elseif SN > "REAVERCDCALCTYPENONPHYMIT" then
											if SN == "REAVERCDCALCTYPETACMIT" then
												return 27;
											else
												return 0;
											end
										else
											return 14;
										end
									else
										return 1;
									end
								else
									if Lm <= 115 then
										return LinFmod(N,2,4,106,115,L,-1);
									else
										return CalcStat("ProgExtComLowRnd",L,CalcStat("ProgExtHighLinExpRnd",115,N));
									end
								end
							else
								return CalcStat("CreepProgB",L);
							end
						elseif SN > "REAVERCDHASPOWER" then
							if SN < "REPVITALITYL" then
								if SN < "REPMAINH" then
									if SN < "REPCRITHIT" then
										if SN < "REPAGILITYL" then
											if SN == "REPAGILITYH" then
												return CalcStat("RepMainH",L);
											else
												return 0;
											end
										elseif SN > "REPAGILITYL" then
											if SN == "REPCRITDEF" then
												if Lm <= 50 then
													return LinFmod(1,900,1488,1,50,L);
												elseif Lm <= 85 then
													return LinFmod(1,1488,1908,50,85,L);
												elseif Lm <= 105 then
													return LinFmod(1,1908,2148,85,105,L);
												else
													return LinFmod(1,2148,2328,105,120,L);
												end
											else
												return 0;
											end
										else
											return CalcStat("RepMainL",L);
										end
									elseif SN > "REPCRITHIT" then
										if SN < "REPFATEL" then
											if SN == "REPFATEH" then
												return CalcStat("RepMainH",L);
											else
												return 0;
											end
										elseif SN > "REPFATEL" then
											if SN == "REPFINESSE" then
												if Lm <= 50 then
													return LinFmod(1,322,557,1,50,L);
												elseif Lm <= 85 then
													return LinFmod(1,557,749.9477,50,85,L);
												elseif Lm <= 105 then
													return LinFmod(1,749.9477,859.1634,85,105,L);
												else
													return LinFmod(1,859.1634,939.2549,105,120,L);
												end
											else
												return 0;
											end
										else
											return CalcStat("RepMainL",L);
										end
									else
										if Lm <= 50 then
											return LinFmod(1,300,496,1,50,L);
										elseif Lm <= 85 then
											return LinFmod(1,496,636,50,85,L);
										elseif Lm <= 105 then
											return LinFmod(1,636,716,85,105,L);
										else
											return LinFmod(1,716,776,105,120,L);
										end
									end
								elseif SN > "REPMAINH" then
									if SN < "REPMORALE" then
										if SN < "REPMIGHTH" then
											if SN == "REPMAINL" then
												if Lm <= 50 then
													return RoundDblDown(LinFmod(1,53,102,1,50,L));
												elseif Lm <= 85 then
													return RoundDblDown(LinFmod(1,102,137,50,85,L));
												elseif Lm <= 105 then
													return RoundDblDown(LinFmod(1,137,157,85,105,L));
												else
													return RoundDblDown(LinFmod(1,157,172,105,120,L));
												end
											else
												return 0;
											end
										elseif SN > "REPMIGHTH" then
											if SN == "REPMIGHTL" then
												return CalcStat("RepMainL",L);
											else
												return 0;
											end
										else
											return CalcStat("RepMainH",L);
										end
									elseif SN > "REPMORALE" then
										if SN < "REPTACMIT" then
											if SN == "REPPOWER" then
												if Lm <= 50 then
													return LinFmod(1,94,212,1,50,L);
												elseif Lm <= 85 then
													return LinFmod(1,212,296,50,85,L);
												elseif Lm <= 105 then
													return LinFmod(1,296,344,85,105,L);
												else
													return LinFmod(1,344,380,105,120,L);
												end
											else
												return 0;
											end
										elseif SN > "REPTACMIT" then
											if SN == "REPVITALITYH" then
												return CalcStat("RepMainH",L);
											else
												return 0;
											end
										else
											if Lm <= 50 then
												return LinFmod(1,675,1116,1,50,L);
											elseif Lm <= 85 then
												return LinFmod(1,1116,1431,50,85,L);
											elseif Lm <= 105 then
												return LinFmod(1,1431,1611,85,105,L);
											else
												return LinFmod(1,1611,1746,105,120,L);
											end
										end
									else
										if Lm <= 50 then
											return LinFmod(1,187,427,1,50,L);
										elseif Lm <= 85 then
											return LinFmod(1,427,599,50,85,L);
										elseif Lm <= 105 then
											return LinFmod(1,599,697,85,105,L);
										else
											return LinFmod(1,697,770,105,120,L);
										end
									end
								else
									if Lm <= 50 then
										return RoundDblDown(LinFmod(1,80,153,1,50,L));
									elseif Lm <= 85 then
										return RoundDblDown(LinFmod(1,153,206,50,85,L));
									elseif Lm <= 105 then
										return RoundDblDown(LinFmod(1,206,236,85,105,L));
									else
										return RoundDblDown(LinFmod(1,236,258,105,120,L));
									end
								end
							elseif SN > "REPVITALITYL" then
								if SN < "RESISTPRATP" then
									if SN < "RESISTADDT" then
										if SN < "REPWILLL" then
											if SN == "REPWILLH" then
												return CalcStat("RepMainH",L);
											else
												return 0;
											end
										elseif SN > "REPWILLL" then
											if SN == "RESIST" then
												return StatLinInter("PntMPResist","ItemPntS","ProgBResist","AdjUmbarItem",L,N,0);
											else
												return 0;
											end
										else
											return CalcStat("RepMainL",L);
										end
									elseif SN > "RESISTADDT" then
										if SN < "RESISTPBONUS" then
											if SN == "RESISTC" then
												return StatLinInter("PntMPResistC","CreepPntS","ProgBResistC","",L,N,0);
											else
												return 0;
											end
										elseif SN > "RESISTPBONUS" then
											if SN == "RESISTPPRAT" then
												return CalcRatAB(CalcStat("ResistPRatPA",L),CalcStat("ResistPRatPB",L),CalcStat("ResistPRatPCapR",L),N);
											else
												return 0;
											end
										else
											return 0;
										end
									else
										return CalcStat("ResistT",L,N);
									end
								elseif SN > "RESISTPRATP" then
									if SN < "RESISTPRATPCAP" then
										if SN < "RESISTPRATPB" then
											if SN == "RESISTPRATPA" then
												return 150;
											else
												return 0;
											end
										elseif SN > "RESISTPRATPB" then
											if SN == "RESISTPRATPC" then
												return 0.5;
											else
												return 0;
											end
										else
											return CalcStat("BRatRounded",L,"BRatExtra");
										end
									elseif SN > "RESISTPRATPCAP" then
										if SN < "RESISTRKALLRES" then
											if SN == "RESISTPRATPCAPR" then
												return CalcStat("ResistPRatPB",L)*CalcStat("ResistPRatPC",L);
											else
												return 0;
											end
										elseif SN > "RESISTRKALLRES" then
											if SN == "RESISTT" then
												return StatLinInter("PntMPResist","TraitPntS","ProgBResist","AdjUmbarTrait",L,N,0);
											else
												return 0;
											end
										else
											return StatLinInter("PntMPResist","ItemPntS","ProgBResist","AdjUmbarItem",L,N,0);
										end
									else
										return 50;
									end
								else
									return CalcPercAB(CalcStat("ResistPRatPA",L),CalcStat("ResistPRatPB",L),CalcStat("ResistPRatPCap",L),N);
								end
							else
								return CalcStat("RepMainL",L);
							end
						else
							return 1;
						end
					else
						return CalcStat("BRatProgB",L,"BRatStandard");
					end
				elseif SN > "REVERSE" then
					if SN < "STALKERCANBLOCK" then
						if SN < "RUNEKEEPERCDBASEPOWER" then
							if SN < "RUNEKEEPERCDAGILITYTOCRITHIT" then
								if SN < "RIVERHOBBITRDTRAITWILL" then
									if SN < "RIVERHOBBITRDPSVTWONAME" then
										if SN > "RIVERHOBBITRDPSVONENAME" then
											if SN == "RIVERHOBBITRDPSVONEWILL" then
												return CalcStat("RivHobSeenWorldWill",L);
											else
												return 0;
											end
										elseif SN == "RIVERHOBBITRDPSVONENAME" then
											return "Seen the World";
										else
											return 0;
										end
									elseif SN > "RIVERHOBBITRDPSVTWONAME" then
										if SN < "RIVERHOBBITRDTRAITFROSTMITP" then
											if SN == "RIVERHOBBITRDTRAITAGILITY" then
												return CalcStat("RivHobSlipperyAgility",L);
											else
												return 0;
											end
										elseif SN > "RIVERHOBBITRDTRAITFROSTMITP" then
											if SN == "RIVERHOBBITRDTRAITMORALE" then
												return CalcStat("RivHobHardyHolbMorale",L);
											else
												return 0;
											end
										else
											return CalcStat("RivHobSwimmerFrostMitP",L);
										end
									else
										return "";
									end
								elseif SN > "RIVERHOBBITRDTRAITWILL" then
									if SN < "RIVHOBSLIPPERYAGILITY" then
										if SN < "RIVHOBSECLUSIONWILL" then
											if SN == "RIVHOBHARDYHOLBMORALE" then
												return CalcStat("MoraleT",L,1.0);
											else
												return 0;
											end
										elseif SN > "RIVHOBSECLUSIONWILL" then
											if SN == "RIVHOBSEENWORLDWILL" then
												return CalcStat("WillT",L,1.0);
											else
												return 0;
											end
										else
											return -CalcStat("WillT",L,0.4);
										end
									elseif SN > "RIVHOBSLIPPERYAGILITY" then
										if SN < "RKDETERMINATIONWILL" then
											if SN == "RIVHOBSWIMMERFROSTMITP" then
												return 1;
											else
												return 0;
											end
										elseif SN > "RKDETERMINATIONWILL" then
											if SN == "RKFORTUNESMILESFATE" then
												return CalcStat("FateT",L,CalcStat("Trait567810Choice",N)*0.4);
											else
												return 0;
											end
										else
											return CalcStat("WillT",L,CalcStat("Trait567810Choice",N)*0.4);
										end
									else
										return CalcStat("AgilityT",L,1.0);
									end
								else
									return CalcStat("RivHobSeclusionWill",L);
								end
							elseif SN > "RUNEKEEPERCDAGILITYTOCRITHIT" then
								if SN < "RUNEKEEPERCDBASEAGILITY" then
									if SN < "RUNEKEEPERCDARMOURTOCOMPHYMIT" then
										if SN < "RUNEKEEPERCDAGILITYTOFINESSE" then
											if SN == "RUNEKEEPERCDAGILITYTOEVADE" then
												return 1;
											else
												return 0;
											end
										elseif SN > "RUNEKEEPERCDAGILITYTOFINESSE" then
											if SN == "RUNEKEEPERCDAGILITYTOTACMAS" then
												return 2;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "RUNEKEEPERCDARMOURTOCOMPHYMIT" then
										if SN < "RUNEKEEPERCDARMOURTOTACMIT" then
											if SN == "RUNEKEEPERCDARMOURTONONPHYMIT" then
												return 0.2;
											else
												return 0;
											end
										elseif SN > "RUNEKEEPERCDARMOURTOTACMIT" then
											if SN == "RUNEKEEPERCDARMOURTYPE" then
												return 1;
											else
												return 0;
											end
										else
											return 0.2;
										end
									else
										return 1;
									end
								elseif SN > "RUNEKEEPERCDBASEAGILITY" then
									if SN < "RUNEKEEPERCDBASEMIGHT" then
										if SN < "RUNEKEEPERCDBASEICMR" then
											if SN == "RUNEKEEPERCDBASEFATE" then
												return CalcStat("ClassBaseFate",L);
											else
												return 0;
											end
										elseif SN > "RUNEKEEPERCDBASEICMR" then
											if SN == "RUNEKEEPERCDBASEICPR" then
												return CalcStat("ClassBaseICPR",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseICMRL",L);
										end
									elseif SN > "RUNEKEEPERCDBASEMIGHT" then
										if SN < "RUNEKEEPERCDBASENCMR" then
											if SN == "RUNEKEEPERCDBASEMORALE" then
												return CalcStat("ClassBaseMorale",L);
											else
												return 0;
											end
										elseif SN > "RUNEKEEPERCDBASENCMR" then
											if SN == "RUNEKEEPERCDBASENCPR" then
												return CalcStat("ClassBaseNCPR",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseNCMRL",L);
										end
									else
										return CalcStat("ClassBaseMightM",L);
									end
								else
									return CalcStat("ClassBaseAgilityL",L);
								end
							else
								return 2;
							end
						elseif SN > "RUNEKEEPERCDBASEPOWER" then
							if SN < "RUNEKEEPERCDVITALITYTOICMR" then
								if SN < "RUNEKEEPERCDHASPOWER" then
									if SN < "RUNEKEEPERCDCALCTYPENONPHYMIT" then
										if SN < "RUNEKEEPERCDBASEWILL" then
											if SN == "RUNEKEEPERCDBASEVITALITY" then
												return CalcStat("ClassBaseVitality",L);
											else
												return 0;
											end
										elseif SN > "RUNEKEEPERCDBASEWILL" then
											if SN == "RUNEKEEPERCDCALCTYPECOMPHYMIT" then
												return 12;
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseWillH",L);
										end
									elseif SN > "RUNEKEEPERCDCALCTYPENONPHYMIT" then
										if SN < "RUNEKEEPERCDFATETONCPR" then
											if SN == "RUNEKEEPERCDCALCTYPETACMIT" then
												return 25;
											else
												return 0;
											end
										elseif SN > "RUNEKEEPERCDFATETONCPR" then
											if SN == "RUNEKEEPERCDFATETOPOWER" then
												return 1;
											else
												return 0;
											end
										else
											return 0.07;
										end
									else
										return 12;
									end
								elseif SN > "RUNEKEEPERCDHASPOWER" then
									if SN < "RUNEKEEPERCDMIGHTTOTACMIT" then
										if SN < "RUNEKEEPERCDMIGHTTOOUTHEAL" then
											if SN == "RUNEKEEPERCDMIGHTTOCRITHIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "RUNEKEEPERCDMIGHTTOOUTHEAL" then
											if SN == "RUNEKEEPERCDMIGHTTOTACMAS" then
												return 2;
											else
												return 0;
											end
										else
											return 2;
										end
									elseif SN > "RUNEKEEPERCDMIGHTTOTACMIT" then
										if SN < "RUNEKEEPERCDPHYMITTONONPHYMIT" then
											if SN == "RUNEKEEPERCDPHYMITTOCOMPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "RUNEKEEPERCDPHYMITTONONPHYMIT" then
											if SN == "RUNEKEEPERCDTACMASTOOUTHEAL" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 1;
									end
								else
									return 1;
								end
							elseif SN > "RUNEKEEPERCDVITALITYTOICMR" then
								if SN < "RUNEKEEPERCDWILLTOTACMIT" then
									if SN < "RUNEKEEPERCDWILLTOEVADE" then
										if SN < "RUNEKEEPERCDVITALITYTONCMR" then
											if SN == "RUNEKEEPERCDVITALITYTOMORALE" then
												return 4.5;
											else
												return 0;
											end
										elseif SN > "RUNEKEEPERCDVITALITYTONCMR" then
											if SN == "RUNEKEEPERCDWILLTOCRITHIT" then
												return 1;
											else
												return 0;
											end
										else
											return 0.12;
										end
									elseif SN > "RUNEKEEPERCDWILLTOEVADE" then
										if SN < "RUNEKEEPERCDWILLTORESIST" then
											if SN == "RUNEKEEPERCDWILLTOPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "RUNEKEEPERCDWILLTORESIST" then
											if SN == "RUNEKEEPERCDWILLTOTACMAS" then
												return 3;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 2;
									end
								elseif SN > "RUNEKEEPERCDWILLTOTACMIT" then
									if SN < "SHIELDBRAWLERBLOCK" then
										if SN < "SHADOWMITT" then
											if SN == "SHADOWMIT" then
												return CalcStat("DmgTypeMit",L,N);
											else
												return 0;
											end
										elseif SN > "SHADOWMITT" then
											if SN == "SHIELDBLOCK" then
												return StatLinInter("PntMPShieldBlock","ItemPntS","ProgBBPE","AdjUmbarItem",L,N,0);
											else
												return 0;
											end
										else
											return CalcStat("DmgTypeMitT",L,N);
										end
									elseif SN > "SHIELDBRAWLERBLOCK" then
										if SN < "SKILLPOWERCOSTMOUNTED" then
											if SN == "SKILLPOWERCOST" then
												if Lm <= 140 then
													return CalcStat("CombatDamageModEnergy",L,0.64*N);
												else
													return CalcStat("CombatDamageModEnergy",L,1.05*0.64*N);
												end
											else
												return 0;
											end
										elseif SN > "SKILLPOWERCOSTMOUNTED" then
											if SN == "SONGRESISTT" then
												return CalcStat("ResistAddT",L,N);
											else
												return 0;
											end
										else
											return CalcStat("CombatDamageModEnergy",L,0.64*N);
										end
									else
										return CalcStat("DwarfShieldBrwlBlock",L);
									end
								else
									return 1;
								end
							else
								return 0.012;
							end
						else
							return CalcStat("ClassBasePower",L);
						end
					elseif SN > "STALKERCANBLOCK" then
						if SN < "STOUTWRBLACKLDISEASERESISTP" then
							if SN < "STOUTAXERDPSVONEVITALITY" then
								if SN < "STDMORALEM" then
									if SN < "STALKERCDHASPOWER" then
										if SN < "STALKERCDCALCTYPENONPHYMIT" then
											if SN == "STALKERCDCALCTYPECOMPHYMIT" then
												return 13;
											else
												return 0;
											end
										elseif SN > "STALKERCDCALCTYPENONPHYMIT" then
											if SN == "STALKERCDCALCTYPETACMIT" then
												return 27;
											else
												return 0;
											end
										else
											return 14;
										end
									elseif SN > "STALKERCDHASPOWER" then
										if SN < "STDMORALEH" then
											if SN == "STATC" then
												return CalcStat(C,L);
											else
												return 0;
											end
										elseif SN > "STDMORALEH" then
											if SN == "STDMORALEL" then
												if Lm <= 105 then
													return RoundDbl(CalcStat("StdMoraleRaw",L));
												else
													return CalcStat("ProgExtLowExpRnd",L,CalcStat("StdMoraleL",105));
												end
											else
												return 0;
											end
										else
											if Lm <= 105 then
												return RoundDbl(2*CalcStat("StdMoraleRaw",L));
											else
												return CalcStat("ProgExtLowExpRnd",L,CalcStat("StdMoraleH",105));
											end
										end
									else
										return 1;
									end
								elseif SN > "STDMORALEM" then
									if SN < "STDPOWERL" then
										if SN < "STDPNTS" then
											if SN == "STDMORALERAW" then
												if Lm <= 50 then
													return LinFmod(1,7.51,227.59,1,50,L);
												else
													return LinFmod(1,227.59,1327.5,50,105,L);
												end
											else
												return 0;
											end
										elseif SN > "STDPNTS" then
											if SN == "STDPOWERH" then
												if Lm <= 105 then
													return RoundDbl(2*CalcStat("StdPowerRaw",L));
												else
													return CalcStat("ProgExtLowExpRnd",L,CalcStat("StdPowerH",105));
												end
											else
												return 0;
											end
										else
											return {{1,50,60,65,75,85,95,100,105,106,115,116,120,121,130,131,140,141,150,151,160},{1,50,60,65,75,85,95,100,105,106,115,116,120,121,130,131,140,141,150,151,160}};
										end
									elseif SN > "STDPOWERL" then
										if SN < "STDPROG" then
											if SN == "STDPOWERRAW" then
												if Lm <= 50 then
													return LinFmod(1,3,91.0375,1,50,L);
												else
													return LinFmod(1,91.0375,421,50,105,L);
												end
											else
												return 0;
											end
										elseif SN > "STDPROG" then
											if SN == "STOUTAXERDPSVONENAME" then
												return "Unwritten Destiny";
											else
												return 0;
											end
										else
											if Lm <= 50 then
												return LinFmod(N,1,10,1,50,L,"P");
											elseif Lm <= 60 then
												return LinFmod(CalcStat("StdProg",50,N),10/10,15/10,50,60,L,"P");
											elseif Lm <= 65 then
												return LinFmod(CalcStat("StdProg",60,N),15/15,20/15,60,65,L,"P");
											elseif Lm <= 75 then
												return LinFmod(CalcStat("StdProg",65,N),20/20,30/20,65,75,L,"P");
											elseif Lm <= 85 then
												return LinFmod(CalcStat("StdProg",75,N),30/30,45/30,75,85,L,"P");
											elseif Lm <= 95 then
												return LinFmod(CalcStat("StdProg",85,N),45/45,65/45,85,95,L,"P");
											elseif Lm <= 100 then
												return LinFmod(CalcStat("StdProg",95,N),65/65,90.27/65,95,100,L,"P");
											elseif Lm <= 105 then
												return LinFmod(CalcStat("StdProg",100,N),90.27/90.27,120.24/90.27,100,105,L,"P");
											elseif Lm <= 115 then
												return LinFmod(CalcStat("StdProg",105,N),1.1,1.5,106,115,L,"P");
											elseif Lm <= 120 then
												return LinFmod(CalcStat("StdProg",115,N),1.15,1.25,116,120,L,"P");
											elseif Lm <= 130 then
												return LinFmod(CalcStat("StdProg",120,N),1.15,1.5,121,130,L,"P");
											elseif Lm <= 140 then
												return LinFmod(CalcStat("StdProg",130,N),1.15,2,131,140,L,"P");
											elseif Lm <= 150 then
												return LinFmod(CalcStat("StdProg",140,N),1.3,2.205,141,150,L,"P");
											else
												return LinFmod(CalcStat("StdProg",150,N),1,2,151,160,L,"P");
											end
										end
									else
										if Lm <= 105 then
											return RoundDbl(CalcStat("StdPowerRaw",L));
										else
											return CalcStat("ProgExtLowExpRnd",L,CalcStat("StdPowerL",105));
										end
									end
								else
									if Lm <= 105 then
										return RoundDbl(1.5*CalcStat("StdMoraleRaw",L));
									else
										return CalcStat("ProgExtLowExpRnd",L,CalcStat("StdMoraleM",105));
									end
								end
							elseif SN > "STOUTAXERDPSVONEVITALITY" then
								if SN < "STOUTAXERDTRAITVITALITY" then
									if SN < "STOUTAXERDTRAITFATE" then
										if SN < "STOUTAXERDTRAITAGILITY" then
											if SN == "STOUTAXERDPSVTWONAME" then
												return "";
											else
												return 0;
											end
										elseif SN > "STOUTAXERDTRAITAGILITY" then
											if SN == "STOUTAXERDTRAITDISEASERESISTP" then
												return CalcStat("StoutWrBlackLDiseaseResistP",L);
											else
												return 0;
											end
										else
											return CalcStat("StoutWrBlackLAgility",L);
										end
									elseif SN > "STOUTAXERDTRAITFATE" then
										if SN < "STOUTAXERDTRAITPHYMITP" then
											if SN == "STOUTAXERDTRAITMIGHT" then
												return CalcStat("StoutWrBlackLMight",L);
											else
												return 0;
											end
										elseif SN > "STOUTAXERDTRAITPHYMITP" then
											if SN == "STOUTAXERDTRAITSHADOWMITP" then
												return CalcStat("StoutWrBlackLShadowMitP",L);
											else
												return 0;
											end
										else
											return CalcStat("StoutUnyieldingPhyMitP",L);
										end
									else
										return CalcStat("StoutDoomDrasaFate",L);
									end
								elseif SN > "STOUTAXERDTRAITVITALITY" then
									if SN < "STOUTUNWRITDESTVITALITY" then
										if SN < "STOUTDOOMDRASAFATE" then
											if SN == "STOUTAXERDTRAITWILL" then
												return CalcStat("StoutUnyieldingWill",L);
											else
												return 0;
											end
										elseif SN > "STOUTDOOMDRASAFATE" then
											if SN == "STOUTSHADOWEYEVITALITY" then
												return -CalcStat("VitalityT",L,0.4);
											else
												return 0;
											end
										else
											return -CalcStat("FateT",L,0.4);
										end
									elseif SN > "STOUTUNWRITDESTVITALITY" then
										if SN < "STOUTUNYIELDINGWILL" then
											if SN == "STOUTUNYIELDINGPHYMITP" then
												return 1;
											else
												return 0;
											end
										elseif SN > "STOUTUNYIELDINGWILL" then
											if SN == "STOUTWRBLACKLAGILITY" then
												return CalcStat("AgilityT",L,1.0);
											else
												return 0;
											end
										else
											return CalcStat("WillT",L,1.0);
										end
									else
										return CalcStat("VitalityT",L,1.0);
									end
								else
									return CalcStat("StoutShadowEyeVitality",L);
								end
							else
								return CalcStat("StoutUnwritDestVitality",L);
							end
						elseif SN > "STOUTWRBLACKLDISEASERESISTP" then
							if SN < "TACMASC" then
								if SN < "TACDMGPPRAT" then
									if SN < "T2PENBPE" then
										if SN < "STOUTWRBLACKLSHADOWMITP" then
											if SN == "STOUTWRBLACKLMIGHT" then
												return CalcStat("MightT",L,1.0);
											else
												return 0;
											end
										elseif SN > "STOUTWRBLACKLSHADOWMITP" then
											if SN == "T2PENARMOUR" then
												return CalcStat("T2penMit",L);
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "T2PENBPE" then
										if SN < "T2PENRESIST" then
											if SN == "T2PENMIT" then
												if Lm <= 115 then
													return RoundDblDown(L*13.5)*-5;
												else
													return CalcStat("ProgExtComLowRaw",L,CalcStat("T2PenMit",115));
												end
											else
												return 0;
											end
										elseif SN > "T2PENRESIST" then
											if SN == "TACDMGPBONUS" then
												return CalcStat("OutDmgPBonus",L);
											else
												return 0;
											end
										else
											if Lm <= 115 then
												return (-90)*L;
											else
												return CalcStat("ProgExtComLowRaw",L,CalcStat("T2PenResist",115));
											end
										end
									else
										if Lm <= 115 then
											return (-40)*L;
										else
											return CalcStat("ProgExtComLowRaw",L,CalcStat("T2PenBPE",115));
										end
									end
								elseif SN > "TACDMGPPRAT" then
									if SN < "TACDMGPRATPC" then
										if SN < "TACDMGPRATPA" then
											if SN == "TACDMGPRATP" then
												return CalcStat("OutDmgPRatP",L,N);
											else
												return 0;
											end
										elseif SN > "TACDMGPRATPA" then
											if SN == "TACDMGPRATPB" then
												return CalcStat("OutDmgPRatPB",L);
											else
												return 0;
											end
										else
											return CalcStat("OutDmgPRatPA",L);
										end
									elseif SN > "TACDMGPRATPC" then
										if SN < "TACDMGPRATPCAPR" then
											if SN == "TACDMGPRATPCAP" then
												return CalcStat("OutDmgPRatPCap",L);
											else
												return 0;
											end
										elseif SN > "TACDMGPRATPCAPR" then
											if SN == "TACMAS" then
												return CalcStat("Mastery",L,N);
											else
												return 0;
											end
										else
											return CalcStat("OutDmgPRatPCapR",L);
										end
									else
										return CalcStat("OutDmgPRatPC",L);
									end
								else
									return CalcStat("OutDmgPPRat",L,N);
								end
							elseif SN > "TACMASC" then
								if SN < "TACMITHPRATPA" then
									if SN < "TACMITC" then
										if SN < "TACMAST" then
											if SN == "TACMASOLD" then
												return CalcStat("Mastery",L,N);
											else
												return 0;
											end
										elseif SN > "TACMAST" then
											if SN == "TACMIT" then
												return StatLinInter("PntMPTacMit","ItemPntS","ProgBMitigation","AdjUmbarItemMit",L,N,0);
											else
												return 0;
											end
										else
											return CalcStat("MasteryT",L,N);
										end
									elseif SN > "TACMITC" then
										if SN < "TACMITHPPRAT" then
											if SN == "TACMITHPBONUS" then
												return CalcStat("MitHeavyPBonus",L);
											else
												return 0;
											end
										elseif SN > "TACMITHPPRAT" then
											if SN == "TACMITHPRATP" then
												return CalcStat("MitHeavyPRatP",L,N);
											else
												return 0;
											end
										else
											return CalcStat("MitHeavyPPRat",L,N);
										end
									else
										return StatLinInter("PntMPTacMitC","CreepPntS","ProgBMitigationC","",L,N,0);
									end
								elseif SN > "TACMITHPRATPA" then
									if SN < "TACMITHPRATPCAPR" then
										if SN < "TACMITHPRATPC" then
											if SN == "TACMITHPRATPB" then
												return CalcStat("MitHeavyPRatPB",L);
											else
												return 0;
											end
										elseif SN > "TACMITHPRATPC" then
											if SN == "TACMITHPRATPCAP" then
												return CalcStat("MitHeavyPRatPCap",L);
											else
												return 0;
											end
										else
											return CalcStat("MitHeavyPRatPC",L);
										end
									elseif SN > "TACMITHPRATPCAPR" then
										if SN < "TACMITLPPRAT" then
											if SN == "TACMITLPBONUS" then
												return CalcStat("MitLightPBonus",L);
											else
												return 0;
											end
										elseif SN > "TACMITLPPRAT" then
											if SN == "TACMITLPRATP" then
												return CalcStat("MitLightPRatP",L,N);
											else
												return 0;
											end
										else
											return CalcStat("MitLightPPRat",L,N);
										end
									else
										return CalcStat("MitHeavyPRatPCapR",L);
									end
								else
									return CalcStat("MitHeavyPRatPA",L);
								end
							else
								return CalcStat("MasteryC",L,N);
							end
						else
							return 1;
						end
					else
						return 1;
					end
				else
					return ReverseCalc(C,L);
				end
			else
				return 40/1200;
			end
		elseif SN > "TACMITLPRATPA" then
			if SN < "WARDENCDMIGHTTOPHYMAS" then
				if SN < "VIRTWISDOMFINESSE" then
					if SN < "VIRTDETERMINATIONPHYMAS" then
						if SN < "TPENRESIST" then
							if SN < "TOMEFATE" then
								if SN < "TACMITMPRATP" then
									if SN < "TACMITLPRATPCAP" then
										if SN > "TACMITLPRATPB" then
											if SN == "TACMITLPRATPC" then
												return CalcStat("MitLightPRatPC",L);
											else
												return 0;
											end
										elseif SN == "TACMITLPRATPB" then
											return CalcStat("MitLightPRatPB",L);
										else
											return 0;
										end
									elseif SN > "TACMITLPRATPCAP" then
										if SN < "TACMITMPBONUS" then
											if SN == "TACMITLPRATPCAPR" then
												return CalcStat("MitLightPRatPCapR",L);
											else
												return 0;
											end
										elseif SN > "TACMITMPBONUS" then
											if SN == "TACMITMPPRAT" then
												return CalcStat("MitMediumPPRat",L,N);
											else
												return 0;
											end
										else
											return CalcStat("MitMediumPBonus",L);
										end
									else
										return CalcStat("MitLightPRatPCap",L);
									end
								elseif SN > "TACMITMPRATP" then
									if SN < "TACMITMPRATPCAP" then
										if SN < "TACMITMPRATPB" then
											if SN == "TACMITMPRATPA" then
												return CalcStat("MitMediumPRatPA",L);
											else
												return 0;
											end
										elseif SN > "TACMITMPRATPB" then
											if SN == "TACMITMPRATPC" then
												return CalcStat("MitMediumPRatPC",L);
											else
												return 0;
											end
										else
											return CalcStat("MitMediumPRatPB",L);
										end
									elseif SN > "TACMITMPRATPCAP" then
										if SN < "TACMITT" then
											if SN == "TACMITMPRATPCAPR" then
												return CalcStat("MitMediumPRatPCapR",L);
											else
												return 0;
											end
										elseif SN > "TACMITT" then
											if SN == "TACRESISTT" then
												return CalcStat("ResistAddT",L,N);
											else
												return 0;
											end
										else
											return StatLinInter("PntMPTacMit","TraitPntS","ProgBMitigation","AdjUmbarTraitMit",L,N,0);
										end
									else
										return CalcStat("MitMediumPRatPCap",L);
									end
								else
									return CalcStat("MitMediumPRatP",L,N);
								end
							elseif SN > "TOMEFATE" then
								if SN < "TOMETOTALMAINDEC" then
									if SN < "TOMETOTALFATE" then
										if SN < "TOMEMAIN" then
											if SN == "TOMEFATEDEC" then
												return CalcStat("TomeTotalFateDec",L)-CalcStat("TomeTotalFateDec",L-1);
											else
												return 0;
											end
										elseif SN > "TOMEMAIN" then
											if SN == "TOMEMAINDEC" then
												return CalcStat("TomeTotalMainDec",L)-CalcStat("TomeTotalMainDec",L-1);
											else
												return 0;
											end
										else
											return CalcStat("TomeMainDec",RomanRankDecode(C));
										end
									elseif SN > "TOMETOTALFATE" then
										if SN < "TOMETOTALLEVEL" then
											if SN == "TOMETOTALFATEDEC" then
												return CalcStat("FateT",CalcStat("TomeTotalLevel",L),2.0);
											else
												return 0;
											end
										elseif SN > "TOMETOTALLEVEL" then
											if SN == "TOMETOTALMAIN" then
												return CalcStat("TomeTotalMainDec",RomanRankDecode(C));
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											else
												return DataTableValue({4,15,27,38,48,54,60,63,67,71,75,78,85,90,95,98,101,104,106,110,114,116,121},L);
											end
										end
									else
										return CalcStat("TomeTotalFateDec",RomanRankDecode(C));
									end
								elseif SN > "TOMETOTALMAINDEC" then
									if SN < "TOMEVITALITYDEC" then
										if SN < "TOMETOTALVITALITYDEC" then
											if SN == "TOMETOTALVITALITY" then
												return CalcStat("TomeTotalVitalityDec",RomanRankDecode(C));
											else
												return 0;
											end
										elseif SN > "TOMETOTALVITALITYDEC" then
											if SN == "TOMEVITALITY" then
												return CalcStat("TomeVitalityDec",RomanRankDecode(C));
											else
												return 0;
											end
										else
											return CalcStat("VitalityT",CalcStat("TomeTotalLevel",L),2.0);
										end
									elseif SN > "TOMEVITALITYDEC" then
										if SN < "TPENBPE" then
											if SN == "TPENARMOUR" then
												return -CalcStat("ArmourPenT",L,CalcStat("TpenChoice",N));
											else
												return 0;
											end
										elseif SN > "TPENBPE" then
											if SN == "TPENCHOICE" then
												return DataTableValue({0,1,2},L);
											else
												return 0;
											end
										else
											return -CalcStat("BPET",L,CalcStat("TpenChoice",N));
										end
									else
										return CalcStat("TomeTotalVitalityDec",L)-CalcStat("TomeTotalVitalityDec",L-1);
									end
								else
									return CalcStat("MainT",CalcStat("TomeTotalLevel",L),2.0);
								end
							else
								return CalcStat("TomeFateDec",RomanRankDecode(C));
							end
						elseif SN > "TPENRESIST" then
							if SN < "VARMOUR" then
								if SN < "TRAIT357912CHOICE" then
									if SN < "TRAIT123CHOICE" then
										if SN < "TRAIT12347CHOICE" then
											if SN == "TRAIT12345CHOICE" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({1,2,3,4,5},L);
												end
											else
												return 0;
											end
										elseif SN > "TRAIT12347CHOICE" then
											if SN == "TRAIT1234CHOICE" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({1,2,3,4},L);
												end
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											else
												return DataTableValue({1,2,3,4,7},L);
											end
										end
									elseif SN > "TRAIT123CHOICE" then
										if SN < "TRAIT23456CHOICE" then
											if SN == "TRAIT13510CHOICE" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({1,3,5,10},L);
												end
											else
												return 0;
											end
										elseif SN > "TRAIT23456CHOICE" then
											if SN == "TRAIT234CHOICE" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({2,3,4},L);
												end
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											else
												return DataTableValue({2,3,4,5,6},L);
											end
										end
									else
										if Lm <= 0 then
											return 0;
										else
											return DataTableValue({1,2,3},L);
										end
									end
								elseif SN > "TRAIT357912CHOICE" then
									if SN < "TRAIT58121620CHOICE" then
										if SN < "TRAIT567810CHOICE" then
											if SN == "TRAIT47101316CHOICE" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({4,7,10,13,16},L);
												end
											else
												return 0;
											end
										elseif SN > "TRAIT567810CHOICE" then
											if SN == "TRAIT56789CHOICE" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({5,6,7,8,9},L);
												end
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											else
												return DataTableValue({5,6,7,8,10},L);
											end
										end
									elseif SN > "TRAIT58121620CHOICE" then
										if SN < "TRAITPNTSVITAL" then
											if SN == "TRAITPNTS" then
												return {{1,25,50,60,65,75,85,95,100,105,115,120,130,131,140,141,150},{1,25,50,60,65,75,85,95,100,105,115,120,130,131,140,141,150}};
											else
												return 0;
											end
										elseif SN > "TRAITPNTSVITAL" then
											if SN == "U371LEGACYSTATFIX" then
												if Lm <= 2 then
													return 0;
												else
													return RoundDblUp(CalcStat(C,L-2)*0.07);
												end
											else
												return 0;
											end
										else
											return {{1,25,50,60,65,75,85,95,100,105,115,120,130,140,141,150},{1,25,50,60,65,75,85,95,100,105,115,120,130,140,141,150}};
										end
									else
										if Lm <= 0 then
											return 0;
										else
											return DataTableValue({5,8,12,16,20},L);
										end
									end
								else
									if Lm <= 0 then
										return 0;
									else
										return DataTableValue({3,5,7,9,12},L);
									end
								end
							elseif SN > "VARMOUR" then
								if SN < "VIRTCOMPASSIONVPMORALE" then
									if SN < "VIRTCHARITYVPMORALE" then
										if SN < "VIRTCHARITYRESIST" then
											if SN == "VIRTCHARITYPHYMIT" then
												return CalcStat("VSPhyMitM",L);
											else
												return 0;
											end
										elseif SN > "VIRTCHARITYRESIST" then
											if SN == "VIRTCHARITYVITALITY" then
												return CalcStat("VSVitalityL",L);
											else
												return 0;
											end
										else
											return CalcStat("VSResistH",L);
										end
									elseif SN > "VIRTCHARITYVPMORALE" then
										if SN < "VIRTCOMPASSIONPHYMIT" then
											if SN == "VIRTCOMPASSIONARMOUR" then
												return CalcStat("VSArmourL",L);
											else
												return 0;
											end
										elseif SN > "VIRTCOMPASSIONPHYMIT" then
											if SN == "VIRTCOMPASSIONTACMIT" then
												return CalcStat("VSTacMitM",L);
											else
												return 0;
											end
										else
											return CalcStat("VSPhyMitH",L);
										end
									else
										return CalcStat("VSVPMorale",L);
									end
								elseif SN > "VIRTCOMPASSIONVPMORALE" then
									if SN < "VIRTCONFIDENCEVPPHYMAS" then
										if SN < "VIRTCONFIDENCEEVADE" then
											if SN == "VIRTCONFIDENCECRITHIT" then
												return CalcStat("VSCritHitH",L);
											else
												return 0;
											end
										elseif SN > "VIRTCONFIDENCEEVADE" then
											if SN == "VIRTCONFIDENCEFINESSE" then
												return CalcStat("VSFinesseM",L);
											else
												return 0;
											end
										else
											return CalcStat("VSEvadeL",L);
										end
									elseif SN > "VIRTCONFIDENCEVPPHYMAS" then
										if SN < "VIRTDETERMINATIONAGILITY" then
											if SN == "VIRTCONFIDENCEVPTACMAS" then
												return CalcStat("VSVPTacMas",L);
											else
												return 0;
											end
										elseif SN > "VIRTDETERMINATIONAGILITY" then
											if SN == "VIRTDETERMINATIONCRITHIT" then
												return CalcStat("VSCritHitL",L);
											else
												return 0;
											end
										else
											return CalcStat("VSAgilityH",L);
										end
									else
										return CalcStat("VSVPPhyMas",L);
									end
								else
									return CalcStat("VSVPMorale",L);
								end
							else
								return RoundDbl(StatLinInter("PntMPArmourVirtues","ItemPntS","ProgBArmourLight","ArmourAdjTypeOther",L,N,0));
							end
						else
							return -CalcStat("ResistT",L,CalcStat("TpenChoice",N)*2);
						end
					elseif SN > "VIRTDETERMINATIONPHYMAS" then
						if SN < "VIRTIDEALISMVPMORALE" then
							if SN < "VIRTFORTITUDECRITDEF" then
								if SN < "VIRTEMPATHYARMOUR" then
									if SN < "VIRTDISCIPLINEINHEAL" then
										if SN > "VIRTDETERMINATIONVPPHYMAS" then
											if SN == "VIRTDETERMINATIONVPTACMAS" then
												return CalcStat("VSVPTacMas",L);
											else
												return 0;
											end
										elseif SN == "VIRTDETERMINATIONVPPHYMAS" then
											return CalcStat("VSVPPhyMas",L);
										else
											return 0;
										end
									elseif SN > "VIRTDISCIPLINEINHEAL" then
										if SN < "VIRTDISCIPLINERESIST" then
											if SN == "VIRTDISCIPLINEPHYMIT" then
												return CalcStat("VSPhyMitL",L);
											else
												return 0;
											end
										elseif SN > "VIRTDISCIPLINERESIST" then
											if SN == "VIRTDISCIPLINEVPMORALE" then
												return CalcStat("VSVPMorale",L);
											else
												return 0;
											end
										else
											return CalcStat("VSResistH",L);
										end
									else
										return CalcStat("VSInHealM",L);
									end
								elseif SN > "VIRTEMPATHYARMOUR" then
									if SN < "VIRTFIDELITYPHYMIT" then
										if SN < "VIRTEMPATHYRESIST" then
											if SN == "VIRTEMPATHYCRITDEF" then
												return CalcStat("VSCritDefM",L);
											else
												return 0;
											end
										elseif SN > "VIRTEMPATHYRESIST" then
											if SN == "VIRTEMPATHYVPMORALE" then
												return CalcStat("VSVPMorale",L);
											else
												return 0;
											end
										else
											return CalcStat("VSResistL",L);
										end
									elseif SN > "VIRTFIDELITYPHYMIT" then
										if SN < "VIRTFIDELITYVITALITY" then
											if SN == "VIRTFIDELITYTACMIT" then
												return CalcStat("VSTacMitH",L);
											else
												return 0;
											end
										elseif SN > "VIRTFIDELITYVITALITY" then
											if SN == "VIRTFIDELITYVPMORALE" then
												return CalcStat("VSVPMorale",L);
											else
												return 0;
											end
										else
											return CalcStat("VSVitalityM",L);
										end
									else
										return CalcStat("VSPhyMitL",L);
									end
								else
									return CalcStat("VSArmourH",L);
								end
							elseif SN > "VIRTFORTITUDECRITDEF" then
								if SN < "VIRTHONESTYWILL" then
									if SN < "VIRTHONESTYCRITHIT" then
										if SN < "VIRTFORTITUDERESIST" then
											if SN == "VIRTFORTITUDEMORALE" then
												return CalcStat("VSMoraleH",L);
											else
												return 0;
											end
										elseif SN > "VIRTFORTITUDERESIST" then
											if SN == "VIRTFORTITUDEVPMORALE" then
												return CalcStat("VSVPMorale",L);
											else
												return 0;
											end
										else
											return CalcStat("VSResistL",L);
										end
									elseif SN > "VIRTHONESTYCRITHIT" then
										if SN < "VIRTHONESTYVPPHYMAS" then
											if SN == "VIRTHONESTYTACMAS" then
												return CalcStat("VSTacMasH",L);
											else
												return 0;
											end
										elseif SN > "VIRTHONESTYVPPHYMAS" then
											if SN == "VIRTHONESTYVPTACMAS" then
												return CalcStat("VSVPTacMas",L);
											else
												return 0;
											end
										else
											return CalcStat("VSVPPhyMas",L);
										end
									else
										return CalcStat("VSCritHitL",L);
									end
								elseif SN > "VIRTHONESTYWILL" then
									if SN < "VIRTHONOURVPMORALE" then
										if SN < "VIRTHONOURMORALE" then
											if SN == "VIRTHONOURCRITDEF" then
												return CalcStat("VSCritDefL",L);
											else
												return 0;
											end
										elseif SN > "VIRTHONOURMORALE" then
											if SN == "VIRTHONOURTACMIT" then
												return CalcStat("VSTacMitM",L);
											else
												return 0;
											end
										else
											return CalcStat("VSMoraleH",L);
										end
									elseif SN > "VIRTHONOURVPMORALE" then
										if SN < "VIRTIDEALISMINHEAL" then
											if SN == "VIRTIDEALISMFATE" then
												return CalcStat("VSFateH",L);
											else
												return 0;
											end
										elseif SN > "VIRTIDEALISMINHEAL" then
											if SN == "VIRTIDEALISMMORALE" then
												return CalcStat("VSMoraleL",L);
											else
												return 0;
											end
										else
											return CalcStat("VSInHealM",L);
										end
									else
										return CalcStat("VSVPMorale",L);
									end
								else
									return CalcStat("VSWillM",L);
								end
							else
								return CalcStat("VSCritDefM",L);
							end
						elseif SN > "VIRTIDEALISMVPMORALE" then
							if SN < "VIRTMERCYVPMORALE" then
								if SN < "VIRTJUSTICEVPMORALE" then
									if SN < "VIRTINNOCENCEVPMORALE" then
										if SN < "VIRTINNOCENCERESIST" then
											if SN == "VIRTINNOCENCEPHYMIT" then
												return CalcStat("VSPhyMitH",L);
											else
												return 0;
											end
										elseif SN > "VIRTINNOCENCERESIST" then
											if SN == "VIRTINNOCENCETACMIT" then
												return CalcStat("VSTacMitL",L);
											else
												return 0;
											end
										else
											return CalcStat("VSResistM",L);
										end
									elseif SN > "VIRTINNOCENCEVPMORALE" then
										if SN < "VIRTJUSTICEMORALE" then
											if SN == "VIRTJUSTICEICMR" then
												return CalcStat("VSICMRH",L);
											else
												return 0;
											end
										elseif SN > "VIRTJUSTICEMORALE" then
											if SN == "VIRTJUSTICETACMIT" then
												return CalcStat("VSTacMitL",L);
											else
												return 0;
											end
										else
											return CalcStat("VSMoraleM",L);
										end
									else
										return CalcStat("VSVPMorale",L);
									end
								elseif SN > "VIRTJUSTICEVPMORALE" then
									if SN < "VIRTLOYALTYVPMORALE" then
										if SN < "VIRTLOYALTYINHEAL" then
											if SN == "VIRTLOYALTYARMOUR" then
												return CalcStat("VSArmourM",L);
											else
												return 0;
											end
										elseif SN > "VIRTLOYALTYINHEAL" then
											if SN == "VIRTLOYALTYVITALITY" then
												return CalcStat("VSVitalityH",L);
											else
												return 0;
											end
										else
											return CalcStat("VSInHealL",L);
										end
									elseif SN > "VIRTLOYALTYVPMORALE" then
										if SN < "VIRTMERCYFATE" then
											if SN == "VIRTMERCYEVADE" then
												return CalcStat("VSEvadeH",L);
											else
												return 0;
											end
										elseif SN > "VIRTMERCYFATE" then
											if SN == "VIRTMERCYVITALITY" then
												return CalcStat("VSVitalityL",L);
											else
												return 0;
											end
										else
											return CalcStat("VSFateM",L);
										end
									else
										return CalcStat("VSVPMorale",L);
									end
								else
									return CalcStat("VSVPMorale",L);
								end
							elseif SN > "VIRTMERCYVPMORALE" then
								if SN < "VIRTTOLERANCERESIST" then
									if SN < "VIRTPATIENCEVPMORALE" then
										if SN < "VIRTPATIENCEEVADE" then
											if SN == "VIRTPATIENCECRITHIT" then
												return CalcStat("VSCritHitL",L);
											else
												return 0;
											end
										elseif SN > "VIRTPATIENCEEVADE" then
											if SN == "VIRTPATIENCEPOWER" then
												return CalcStat("VSPowerH",L);
											else
												return 0;
											end
										else
											return CalcStat("VSEvadeM",L);
										end
									elseif SN > "VIRTPATIENCEVPMORALE" then
										if SN < "VIRTRNKCOSTTOT" then
											if SN == "VIRTRNKCOST" then
												if Lm <= 0 then
													return 0;
												elseif Lm <= 10 then
													return 1000;
												elseif Lm <= 60 then
													return RoundDbl(18*L+878,-2);
												elseif Lm <= 73 then
													return RoundDbl(18.75*L+878,-2);
												elseif Lm <= 90 then
													return RoundDbl(17.45*L+878,-2);
												else
													return 2500;
												end
											else
												return 0;
											end
										elseif SN > "VIRTRNKCOSTTOT" then
											if SN == "VIRTTOLERANCEPHYMIT" then
												return CalcStat("VSPhyMitL",L);
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											else
												return CalcStat("VirtRnkCostTot",L-1)+CalcStat("VirtRnkCost",L);
											end
										end
									else
										return CalcStat("VSVPMorale",L);
									end
								elseif SN > "VIRTTOLERANCERESIST" then
									if SN < "VIRTVALOURFINESSE" then
										if SN < "VIRTTOLERANCEVPMORALE" then
											if SN == "VIRTTOLERANCETACMIT" then
												return CalcStat("VSTacMitH",L);
											else
												return 0;
											end
										elseif SN > "VIRTTOLERANCEVPMORALE" then
											if SN == "VIRTVALOURCRITHIT" then
												return CalcStat("VSCritHitL",L);
											else
												return 0;
											end
										else
											return CalcStat("VSVPMorale",L);
										end
									elseif SN > "VIRTVALOURFINESSE" then
										if SN < "VIRTVALOURVPPHYMAS" then
											if SN == "VIRTVALOURPHYMAS" then
												return CalcStat("VSPhyMasH",L);
											else
												return 0;
											end
										elseif SN > "VIRTVALOURVPPHYMAS" then
											if SN == "VIRTVALOURVPTACMAS" then
												return CalcStat("VSVPTacMas",L);
											else
												return 0;
											end
										else
											return CalcStat("VSVPPhyMas",L);
										end
									else
										return CalcStat("VSFinesseM",L);
									end
								else
									return CalcStat("VSResistM",L);
								end
							else
								return CalcStat("VSVPMorale",L);
							end
						else
							return CalcStat("VSVPMorale",L);
						end
					else
						return CalcStat("VSPhyMasM",L);
					end
				elseif SN > "VIRTWISDOMFINESSE" then
					if SN < "VSMIGHTM" then
						if SN < "VRNKCAP" then
							if SN < "VIRTZEALVPTACMAS" then
								if SN < "VIRTWITPHYMAS" then
									if SN < "VIRTWISDOMVPTACMAS" then
										if SN > "VIRTWISDOMTACMAS" then
											if SN == "VIRTWISDOMVPPHYMAS" then
												return CalcStat("VSVPPhyMas",L);
											else
												return 0;
											end
										elseif SN == "VIRTWISDOMTACMAS" then
											return CalcStat("VSTacMasM",L);
										else
											return 0;
										end
									elseif SN > "VIRTWISDOMVPTACMAS" then
										if SN < "VIRTWITCRITHIT" then
											if SN == "VIRTWISDOMWILL" then
												return CalcStat("VSWillH",L);
											else
												return 0;
											end
										elseif SN > "VIRTWITCRITHIT" then
											if SN == "VIRTWITFINESSE" then
												return CalcStat("VSFinesseH",L);
											else
												return 0;
											end
										else
											return CalcStat("VSCritHitM",L);
										end
									else
										return CalcStat("VSVPTacMas",L);
									end
								elseif SN > "VIRTWITPHYMAS" then
									if SN < "VIRTZEALCRITHIT" then
										if SN < "VIRTWITVPPHYMAS" then
											if SN == "VIRTWITTACMAS" then
												return CalcStat("VSTacMasL",L);
											else
												return 0;
											end
										elseif SN > "VIRTWITVPPHYMAS" then
											if SN == "VIRTWITVPTACMAS" then
												return CalcStat("VSVPTacMas",L);
											else
												return 0;
											end
										else
											return CalcStat("VSVPPhyMas",L);
										end
									elseif SN > "VIRTZEALCRITHIT" then
										if SN < "VIRTZEALPHYMAS" then
											if SN == "VIRTZEALMIGHT" then
												return CalcStat("VSMightH",L);
											else
												return 0;
											end
										elseif SN > "VIRTZEALPHYMAS" then
											if SN == "VIRTZEALVPPHYMAS" then
												return CalcStat("VSVPPhyMas",L);
											else
												return 0;
											end
										else
											return CalcStat("VSPhyMasM",L);
										end
									else
										return CalcStat("VSCritHitL",L);
									end
								else
									return CalcStat("VSPhyMasL",L);
								end
							elseif SN > "VIRTZEALVPTACMAS" then
								if SN < "VMASTERYOLD" then
									if SN < "VITALITYT" then
										if SN < "VITALITYADJ" then
											if SN == "VITALITY" then
												return RoundDblDown(StatLinInter("PntMPVitality","ItemPntSVital","ProgBVitality","VitalityAdj",L,N,0));
											else
												return 0;
											end
										elseif SN > "VITALITYADJ" then
											if SN == "VITALITYC" then
												return RoundDblDown(StatLinInter("PntMPVitalityC","CreepPntSOld","ProgBVitalityC","",L,N,0));
											else
												return 0;
											end
										else
											if Lm <= 25 then
												return 0.5;
											elseif Lm <= 50 then
												return 0.6;
											elseif Lm <= 60 then
												return 0.7;
											elseif Lm <= 79 then
												return 0.8;
											elseif Lm <= 80 then
												return 0.9;
											else
												return 1;
											end
										end
									elseif SN > "VITALITYT" then
										if SN < "VMASTERY" then
											if SN == "VITALITYTADJ" then
												if Lm <= 25 then
													return 0.5;
												elseif Lm <= 50 then
													return 0.6;
												elseif Lm <= 60 then
													return 0.7;
												elseif Lm <= 65 then
													return 0.8;
												elseif Lm <= 75 then
													return 0.9;
												else
													return 1;
												end
											else
												return 0;
											end
										elseif SN > "VMASTERY" then
											if SN == "VMASTERYADJ" then
												if Lm <= 0 then
													return 0;
												else
													return CalcStat("MasteryAdj",L);
												end
											else
												return 0;
											end
										else
											return StatLinInter("PntMPMastery","ItemPntSVirtueMastery","ProgBMastery","VMasteryAdj",L,N,0);
										end
									else
										return RoundDblDown(StatLinInter("PntMPVitalityT","TraitPntSVital","ProgBVitality","VitalityTAdj",L,N,0));
									end
								elseif SN > "VMASTERYOLD" then
									if SN < "VMMEDIUM" then
										if SN < "VMLOW" then
											if SN == "VMHIGH" then
												if Lm <= 0 then
													return 0;
												else
													return CalcStat(C,CalcStat("VRnkToILvl",L),2.0);
												end
											else
												return 0;
											end
										elseif SN > "VMLOW" then
											if SN == "VMMASTERYPSV" then
												if Lm <= 0 then
													return 0;
												else
													return CalcStat("VMastery",CalcStat("VRnkToILvl",L),0.2);
												end
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											else
												return CalcStat(C,CalcStat("VRnkToILvl",L),0.6);
											end
										end
									elseif SN > "VMMEDIUM" then
										if SN < "VMORALE" then
											if SN == "VMMORALEPSV" then
												if Lm <= 0 then
													return 0;
												else
													return CalcStat("VMorale",CalcStat("VRnkToILvl",L),0.3);
												end
											else
												return 0;
											end
										elseif SN > "VMORALE" then
											if SN == "VMORALEADJ" then
												if Lm <= 0 then
													return 0;
												elseif Lm <= 2 then
													return 1;
												elseif Lm <= 50 then
													return 2;
												elseif Lm <= 80 then
													return 1.5;
												elseif Lm <= 450 then
													return 1;
												elseif Lm <= 499 then
													return 0.9475;
												else
													return 1;
												end
											else
												return 0;
											end
										else
											return StatLinInter("PntMPMoraleVirtues","ItemPntSVirtueMorale","ProgBMorale","VMoraleAdj",L,N,0);
										end
									else
										if Lm <= 0 then
											return 0;
										else
											return CalcStat(C,CalcStat("VRnkToILvl",L),1.0);
										end
									end
								else
									return CalcStat("VMastery",L,N);
								end
							else
								return CalcStat("VSVPTacMas",L);
							end
						elseif SN > "VRNKCAP" then
							if SN < "VSEVADEL" then
								if SN < "VSARMOURM" then
									if SN < "VSAGILITYL" then
										if SN < "VRNKTOILVL" then
											if SN == "VRNKLVLCAP" then
												if Lm <= 4 then
													return 2;
												elseif Lm <= 110 then
													return RoundDblDown(L/2);
												elseif Lm <= 139 then
													return L-55;
												elseif Lm <= 140 then
													return L-54;
												elseif Lm <= 149 then
													return L-53;
												else
													return 98;
												end
											else
												return 0;
											end
										elseif SN > "VRNKTOILVL" then
											if SN == "VSAGILITYH" then
												return CalcStat("VMHigh",L,"Agility");
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											elseif Lm <= 38 then
												return LinFmod(1,4,78,1,38,L);
											elseif Lm <= 48 then
												return LinFmod(1,78,178,38,48,L);
											elseif Lm <= 49 then
												return LinFmod(1,178,190,48,49,L);
											elseif Lm <= 50 then
												return LinFmod(1,190,210,49,50,L);
											elseif Lm <= 51 then
												return LinFmod(1,210,222,50,51,L);
											elseif Lm <= 52 then
												return LinFmod(1,222,236,51,52,L);
											elseif Lm <= 53 then
												return LinFmod(1,236,260,52,53,L);
											elseif Lm <= 55 then
												return LinFmod(1,260,292,53,55,L);
											elseif Lm <= 68 then
												return LinFmod(1,292,396,55,68,L);
											else
												return LinFmod(1,396,706,68,130,L);
											end
										end
									elseif SN > "VSAGILITYL" then
										if SN < "VSARMOURH" then
											if SN == "VSAGILITYM" then
												return CalcStat("VMMedium",L,"Agility");
											else
												return 0;
											end
										elseif SN > "VSARMOURH" then
											if SN == "VSARMOURL" then
												return CalcStat("VMLow",L,"Varmour");
											else
												return 0;
											end
										else
											return CalcStat("VMHigh",L,"Varmour");
										end
									else
										return CalcStat("VMLow",L,"Agility");
									end
								elseif SN > "VSARMOURM" then
									if SN < "VSCRITHITH" then
										if SN < "VSCRITDEFL" then
											if SN == "VSCRITDEFH" then
												return CalcStat("VMHigh",L,"CritDef");
											else
												return 0;
											end
										elseif SN > "VSCRITDEFL" then
											if SN == "VSCRITDEFM" then
												return CalcStat("VMMedium",L,"CritDef");
											else
												return 0;
											end
										else
											return CalcStat("VMLow",L,"CritDef");
										end
									elseif SN > "VSCRITHITH" then
										if SN < "VSCRITHITM" then
											if SN == "VSCRITHITL" then
												return CalcStat("VMLow",L,"CritHit");
											else
												return 0;
											end
										elseif SN > "VSCRITHITM" then
											if SN == "VSEVADEH" then
												return CalcStat("VMHigh",L,"Evade");
											else
												return 0;
											end
										else
											return CalcStat("VMMedium",L,"CritHit");
										end
									else
										return CalcStat("VMHigh",L,"CritHit");
									end
								else
									return CalcStat("VMMedium",L,"Varmour");
								end
							elseif SN > "VSEVADEL" then
								if SN < "VSICMRH" then
									if SN < "VSFATEM" then
										if SN < "VSFATEH" then
											if SN == "VSEVADEM" then
												return CalcStat("VMMedium",L,"Evade");
											else
												return 0;
											end
										elseif SN > "VSFATEH" then
											if SN == "VSFATEL" then
												return CalcStat("VMLow",L,"Fate");
											else
												return 0;
											end
										else
											return CalcStat("VMHigh",L,"Fate");
										end
									elseif SN > "VSFATEM" then
										if SN < "VSFINESSEL" then
											if SN == "VSFINESSEH" then
												return CalcStat("VMHigh",L,"Finesse");
											else
												return 0;
											end
										elseif SN > "VSFINESSEL" then
											if SN == "VSFINESSEM" then
												return CalcStat("VMMedium",L,"Finesse");
											else
												return 0;
											end
										else
											return CalcStat("VMLow",L,"Finesse");
										end
									else
										return CalcStat("VMMedium",L,"Fate");
									end
								elseif SN > "VSICMRH" then
									if SN < "VSINHEALL" then
										if SN < "VSICMRM" then
											if SN == "VSICMRL" then
												return CalcStat("VMLow",L,"ICMR");
											else
												return 0;
											end
										elseif SN > "VSICMRM" then
											if SN == "VSINHEALH" then
												return CalcStat("VMHigh",L,"InHeal");
											else
												return 0;
											end
										else
											return CalcStat("VMMedium",L,"ICMR");
										end
									elseif SN > "VSINHEALL" then
										if SN < "VSMIGHTH" then
											if SN == "VSINHEALM" then
												return CalcStat("VMMedium",L,"InHeal");
											else
												return 0;
											end
										elseif SN > "VSMIGHTH" then
											if SN == "VSMIGHTL" then
												return CalcStat("VMLow",L,"Might");
											else
												return 0;
											end
										else
											return CalcStat("VMHigh",L,"Might");
										end
									else
										return CalcStat("VMLow",L,"InHeal");
									end
								else
									return CalcStat("VMHigh",L,"ICMR");
								end
							else
								return CalcStat("VMLow",L,"Evade");
							end
						else
							return 90;
						end
					elseif SN > "VSMIGHTM" then
						if SN < "WARDENCDAGILITYTOCRITHIT" then
							if SN < "VSTACMASH" then
								if SN < "VSPHYMITL" then
									if SN < "VSPHYMASH" then
										if SN < "VSMORALEL" then
											if SN == "VSMORALEH" then
												return CalcStat("VMHigh",L,"VMorale");
											else
												return 0;
											end
										elseif SN > "VSMORALEL" then
											if SN == "VSMORALEM" then
												return CalcStat("VMMedium",L,"VMorale");
											else
												return 0;
											end
										else
											return CalcStat("VMLow",L,"VMorale");
										end
									elseif SN > "VSPHYMASH" then
										if SN < "VSPHYMASM" then
											if SN == "VSPHYMASL" then
												return CalcStat("VMLow",L,"PhyMas");
											else
												return 0;
											end
										elseif SN > "VSPHYMASM" then
											if SN == "VSPHYMITH" then
												return CalcStat("VMHigh",L,"PhyMit");
											else
												return 0;
											end
										else
											return CalcStat("VMMedium",L,"PhyMas");
										end
									else
										return CalcStat("VMHigh",L,"PhyMas");
									end
								elseif SN > "VSPHYMITL" then
									if SN < "VSPOWERM" then
										if SN < "VSPOWERH" then
											if SN == "VSPHYMITM" then
												return CalcStat("VMMedium",L,"PhyMit");
											else
												return 0;
											end
										elseif SN > "VSPOWERH" then
											if SN == "VSPOWERL" then
												return CalcStat("VMLow",L,"Power");
											else
												return 0;
											end
										else
											return CalcStat("VMHigh",L,"Power");
										end
									elseif SN > "VSPOWERM" then
										if SN < "VSRESISTL" then
											if SN == "VSRESISTH" then
												return CalcStat("VMHigh",L,"Resist");
											else
												return 0;
											end
										elseif SN > "VSRESISTL" then
											if SN == "VSRESISTM" then
												return CalcStat("VMMedium",L,"Resist");
											else
												return 0;
											end
										else
											return CalcStat("VMLow",L,"Resist");
										end
									else
										return CalcStat("VMMedium",L,"Power");
									end
								else
									return CalcStat("VMLow",L,"PhyMit");
								end
							elseif SN > "VSTACMASH" then
								if SN < "VSVITALITYM" then
									if SN < "VSTACMITL" then
										if SN < "VSTACMASM" then
											if SN == "VSTACMASL" then
												return CalcStat("VMLow",L,"TacMas");
											else
												return 0;
											end
										elseif SN > "VSTACMASM" then
											if SN == "VSTACMITH" then
												return CalcStat("VMHigh",L,"TacMit");
											else
												return 0;
											end
										else
											return CalcStat("VMMedium",L,"TacMas");
										end
									elseif SN > "VSTACMITL" then
										if SN < "VSVITALITYH" then
											if SN == "VSTACMITM" then
												return CalcStat("VMMedium",L,"TacMit");
											else
												return 0;
											end
										elseif SN > "VSVITALITYH" then
											if SN == "VSVITALITYL" then
												return CalcStat("VMLow",L,"Vitality");
											else
												return 0;
											end
										else
											return CalcStat("VMHigh",L,"Vitality");
										end
									else
										return CalcStat("VMLow",L,"TacMit");
									end
								elseif SN > "VSVITALITYM" then
									if SN < "VSWILLH" then
										if SN < "VSVPPHYMAS" then
											if SN == "VSVPMORALE" then
												return CalcStat("VMMoralePsv",L);
											else
												return 0;
											end
										elseif SN > "VSVPPHYMAS" then
											if SN == "VSVPTACMAS" then
												return CalcStat("VMMasteryPsv",L);
											else
												return 0;
											end
										else
											return CalcStat("VMMasteryPsv",L);
										end
									elseif SN > "VSWILLH" then
										if SN < "VSWILLM" then
											if SN == "VSWILLL" then
												return CalcStat("VMLow",L,"Will");
											else
												return 0;
											end
										elseif SN > "VSWILLM" then
											if SN == "WARDENCDAGILITYTOBLOCK" then
												return 2;
											else
												return 0;
											end
										else
											return CalcStat("VMMedium",L,"Will");
										end
									else
										return CalcStat("VMHigh",L,"Will");
									end
								else
									return CalcStat("VMMedium",L,"Vitality");
								end
							else
								return CalcStat("VMHigh",L,"TacMas");
							end
						elseif SN > "WARDENCDAGILITYTOCRITHIT" then
							if SN < "WARDENCDBASENCMR" then
								if SN < "WARDENCDARMOURTOTACMIT" then
									if SN < "WARDENCDAGILITYTOPHYMIT" then
										if SN < "WARDENCDAGILITYTOPARRY" then
											if SN == "WARDENCDAGILITYTOOUTHEAL" then
												return 3;
											else
												return 0;
											end
										elseif SN > "WARDENCDAGILITYTOPARRY" then
											if SN == "WARDENCDAGILITYTOPHYMAS" then
												return 3;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "WARDENCDAGILITYTOPHYMIT" then
										if SN < "WARDENCDARMOURTOCOMPHYMIT" then
											if SN == "WARDENCDAGILITYTOTACMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN > "WARDENCDARMOURTOCOMPHYMIT" then
											if SN == "WARDENCDARMOURTONONPHYMIT" then
												return 0.2;
											else
												return 0;
											end
										else
											return 1;
										end
									else
										return 1;
									end
								elseif SN > "WARDENCDARMOURTOTACMIT" then
									if SN < "WARDENCDBASEICMR" then
										if SN < "WARDENCDBASEAGILITY" then
											if SN == "WARDENCDARMOURTYPE" then
												return 2;
											else
												return 0;
											end
										elseif SN > "WARDENCDBASEAGILITY" then
											if SN == "WARDENCDBASEFATE" then
												return CalcStat("ClassBaseFate",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseAgilityH",L);
										end
									elseif SN > "WARDENCDBASEICMR" then
										if SN < "WARDENCDBASEMIGHT" then
											if SN == "WARDENCDBASEICPR" then
												return CalcStat("ClassBaseICPR",L);
											else
												return 0;
											end
										elseif SN > "WARDENCDBASEMIGHT" then
											if SN == "WARDENCDBASEMORALE" then
												return CalcStat("ClassBaseMorale",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBaseMightM",L);
										end
									else
										return CalcStat("ClassBaseICMRH",L);
									end
								else
									return 0.2;
								end
							elseif SN > "WARDENCDBASENCMR" then
								if SN < "WARDENCDCANBLOCK" then
									if SN < "WARDENCDBASEWILL" then
										if SN < "WARDENCDBASEPOWER" then
											if SN == "WARDENCDBASENCPR" then
												return CalcStat("ClassBaseNCPR",L);
											else
												return 0;
											end
										elseif SN > "WARDENCDBASEPOWER" then
											if SN == "WARDENCDBASEVITALITY" then
												return CalcStat("ClassBaseVitality",L);
											else
												return 0;
											end
										else
											return CalcStat("ClassBasePower",L);
										end
									elseif SN > "WARDENCDBASEWILL" then
										if SN < "WARDENCDCALCTYPENONPHYMIT" then
											if SN == "WARDENCDCALCTYPECOMPHYMIT" then
												return 13;
											else
												return 0;
											end
										elseif SN > "WARDENCDCALCTYPENONPHYMIT" then
											if SN == "WARDENCDCALCTYPETACMIT" then
												return 26;
											else
												return 0;
											end
										else
											return 13;
										end
									else
										return CalcStat("ClassBaseWillL",L);
									end
								elseif SN > "WARDENCDCANBLOCK" then
									if SN < "WARDENCDMIGHTTOBLOCK" then
										if SN < "WARDENCDFATETOPOWER" then
											if SN == "WARDENCDFATETONCPR" then
												return 0.07;
											else
												return 0;
											end
										elseif SN > "WARDENCDFATETOPOWER" then
											if SN == "WARDENCDHASPOWER" then
												return 1;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "WARDENCDMIGHTTOBLOCK" then
										if SN < "WARDENCDMIGHTTOFINESSE" then
											if SN == "WARDENCDMIGHTTOCRITHIT" then
												return 1.5;
											else
												return 0;
											end
										elseif SN > "WARDENCDMIGHTTOFINESSE" then
											if SN == "WARDENCDMIGHTTOOUTHEAL" then
												return 2;
											else
												return 0;
											end
										else
											return 1.5;
										end
									else
										return 1;
									end
								else
									return 1;
								end
							else
								return CalcStat("ClassBaseNCMRH",L);
							end
						else
							return 1;
						end
					else
						return CalcStat("VMMedium",L,"Might");
					end
				else
					return CalcStat("VSFinesseL",L);
				end
			elseif SN > "WARDENCDMIGHTTOPHYMAS" then
				if SN < "WORTHTABM" then
					if SN < "WORTHTABAT" then
						if SN < "WORTHMPA" then
							if SN < "WARLEADERCANBLOCK" then
								if SN < "WARDENCDWILLTOFINESSE" then
									if SN < "WARDENCDTACMASTOOUTHEAL" then
										if SN > "WARDENCDPHYMITTOCOMPHYMIT" then
											if SN == "WARDENCDPHYMITTONONPHYMIT" then
												return 1;
											else
												return 0;
											end
										elseif SN == "WARDENCDPHYMITTOCOMPHYMIT" then
											return 1;
										else
											return 0;
										end
									elseif SN > "WARDENCDTACMASTOOUTHEAL" then
										if SN < "WARDENCDVITALITYTOMORALE" then
											if SN == "WARDENCDVITALITYTOICMR" then
												return 0.012;
											else
												return 0;
											end
										elseif SN > "WARDENCDVITALITYTOMORALE" then
											if SN == "WARDENCDVITALITYTONCMR" then
												return 0.12;
											else
												return 0;
											end
										else
											return 4.5;
										end
									else
										return 1;
									end
								elseif SN > "WARDENCDWILLTOFINESSE" then
									if SN < "WARDENCDWILLTORESIST" then
										if SN < "WARDENCDWILLTOPHYMAS" then
											if SN == "WARDENCDWILLTOOUTHEAL" then
												return 1;
											else
												return 0;
											end
										elseif SN > "WARDENCDWILLTOPHYMAS" then
											if SN == "WARDENCDWILLTOPHYMIT" then
												return 1.5;
											else
												return 0;
											end
										else
											return 1;
										end
									elseif SN > "WARDENCDWILLTORESIST" then
										if SN < "WARDINGLOREPHYMIT" then
											if SN == "WARDENCDWILLTOTACMIT" then
												return 1.5;
											else
												return 0;
											end
										elseif SN > "WARDINGLOREPHYMIT" then
											if SN == "WARDINGLORETACMIT" then
												if Lm <= 105 then
													return CalcStat("Mitigation",L,1.6);
												elseif Lm <= 119 then
													return CalcStat("TacMitT",L,1.2);
												elseif Lm <= 120 then
													return CalcStat("TacMitT",L,1.6);
												elseif Lm <= 129 then
													return CalcStat("TacMitT",L,1.2);
												elseif Lm <= 130 then
													return CalcStat("TacMitT",L,1.6);
												elseif Lm <= 139 then
													return CalcStat("TacMitT",L,1.2);
												else
													return CalcStat("TacMitT",L,1.6);
												end
											else
												return 0;
											end
										else
											if Lm <= 105 then
												return CalcStat("Mitigation",L,1.6);
											elseif Lm <= 119 then
												return CalcStat("PhyMitT",L,1.2);
											elseif Lm <= 120 then
												return CalcStat("PhyMitT",L,1.6);
											elseif Lm <= 129 then
												return CalcStat("PhyMitT",L,1.2);
											elseif Lm <= 130 then
												return CalcStat("PhyMitT",L,1.6);
											elseif Lm <= 139 then
												return CalcStat("PhyMitT",L,1.2);
											else
												return CalcStat("PhyMitT",L,1.6);
											end
										end
									else
										return 1;
									end
								else
									return 1;
								end
							elseif SN > "WARLEADERCANBLOCK" then
								if SN < "WEAVERCDCALCTYPETACMIT" then
									if SN < "WARLEADERCDHASPOWER" then
										if SN < "WARLEADERCDCALCTYPENONPHYMIT" then
											if SN == "WARLEADERCDCALCTYPECOMPHYMIT" then
												return 14;
											else
												return 0;
											end
										elseif SN > "WARLEADERCDCALCTYPENONPHYMIT" then
											if SN == "WARLEADERCDCALCTYPETACMIT" then
												return 27;
											else
												return 0;
											end
										else
											return 14;
										end
									elseif SN > "WARLEADERCDHASPOWER" then
										if SN < "WEAVERCDCALCTYPECOMPHYMIT" then
											if SN == "WEAVERCANBLOCK" then
												return 1;
											else
												return 0;
											end
										elseif SN > "WEAVERCDCALCTYPECOMPHYMIT" then
											if SN == "WEAVERCDCALCTYPENONPHYMIT" then
												return 14;
											else
												return 0;
											end
										else
											return 13;
										end
									else
										return 1;
									end
								elseif SN > "WEAVERCDCALCTYPETACMIT" then
									if SN < "WILLT" then
										if SN < "WILL" then
											if SN == "WEAVERCDHASPOWER" then
												return 1;
											else
												return 0;
											end
										elseif SN > "WILL" then
											if SN == "WILLC" then
												return CalcStat("MainC",L,N);
											else
												return 0;
											end
										else
											return CalcStat("Main",L,N);
										end
									elseif SN > "WILLT" then
										if SN < "WORTHEXT4LIN" then
											if SN == "WORTHEXT" then
												if Lm <= 360 then
													return RoundDbl(CalcStat("StatC",L,C));
												elseif Lm <= 601 then
													return RoundDbl(CalcStat("StatC",L-1,C));
												else
													return 0;
												end
											else
												return 0;
											end
										elseif SN > "WORTHEXT4LIN" then
											if SN == "WORTHEXT8LIN" then
												if Lm <= 501 then
													return CalcStat("WorthExt",L,C);
												elseif Lm <= 601 then
													return CalcStat("WorthExt",501,C)+(L-501)*8;
												else
													return 0;
												end
											else
												return 0;
											end
										else
											if Lm <= 501 then
												return CalcStat("WorthExt",L,C);
											elseif Lm <= 601 then
												return CalcStat("WorthExt",501,C)+(L-501)*4;
											else
												return 0;
											end
										end
									else
										return CalcStat("MainT",L,N);
									end
								else
									return 27;
								end
							else
								return 1;
							end
						elseif SN > "WORTHMPA" then
							if SN < "WORTHTABAE" then
								if SN < "WORTHMPI" then
									if SN < "WORTHMPE" then
										if SN < "WORTHMPC" then
											if SN == "WORTHMPB" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({1,1.2,2,3,4},L);
												end
											else
												return 0;
											end
										elseif SN > "WORTHMPC" then
											if SN == "WORTHMPD" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({1,1,1,2,3},L);
												end
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											else
												return 1;
											end
										end
									elseif SN > "WORTHMPE" then
										if SN < "WORTHMPG" then
											if SN == "WORTHMPF" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({0.5,1,1.25,1.5,2},L);
												end
											else
												return 0;
											end
										elseif SN > "WORTHMPG" then
											if SN == "WORTHMPH" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({1,1.2,1.8,3.2,5},L);
												end
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											else
												return DataTableValue({1,2,3,4,5},L);
											end
										end
									else
										if Lm <= 0 then
											return 0;
										else
											return DataTableValue({1,1.1,1.15,1.2,1.25},L);
										end
									end
								elseif SN > "WORTHMPI" then
									if SN < "WORTHTABAA" then
										if SN < "WORTHMPK" then
											if SN == "WORTHMPJ" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({1,1,1,1,5},L);
												end
											else
												return 0;
											end
										elseif SN > "WORTHMPK" then
											if SN == "WORTHTABA" then
												if Lm <= 1 then
													return 1;
												else
													return CalcStat("WorthTabAF",L);
												end
											else
												return 0;
											end
										else
											if Lm <= 0 then
												return 0;
											else
												return DataTableValue({1,1.2,1.3,1.35,1.4},L);
											end
										end
									elseif SN > "WORTHTABAA" then
										if SN < "WORTHTABAC" then
											if SN == "WORTHTABAB" then
												return 7*L+50;
											else
												return 0;
											end
										elseif SN > "WORTHTABAC" then
											if SN == "WORTHTABAD" then
												return 7*L+100;
											else
												return 0;
											end
										else
											return CalcStat("WorthTabE",L)-30;
										end
									else
										return CalcStat("WorthTabD",L)+20;
									end
								else
									if Lm <= 0 then
										return 0;
									else
										return DataTableValue({1,2,2.5,3,10},L);
									end
								end
							elseif SN > "WORTHTABAE" then
								if SN < "WORTHTABALBASE" then
									if SN < "WORTHTABAI" then
										if SN < "WORTHTABAG" then
											if SN == "WORTHTABAF" then
												if Lm <= 49 then
													return 2.5*L;
												else
													return 3*L-25;
												end
											else
												return 0;
											end
										elseif SN > "WORTHTABAG" then
											if SN == "WORTHTABAH" then
												if Lm <= 49 then
													return CalcStat("WorthTabALBase",L+7)-66;
												else
													return 9*L+72;
												end
											else
												return 0;
											end
										else
											return CalcStat("WorthTabAF",L)+25;
										end
									elseif SN > "WORTHTABAI" then
										if SN < "WORTHTABAK" then
											if SN == "WORTHTABAJ" then
												return CalcStat("WorthTabAH",L);
											else
												return 0;
											end
										elseif SN > "WORTHTABAK" then
											if SN == "WORTHTABAL" then
												if Lm <= 49 then
													return CalcStat("WorthTabALBase",L);
												else
													return 9*L+69;
												end
											else
												return 0;
											end
										else
											if Lm <= 49 then
												return CalcStat("WorthTabALBase",L+1);
											else
												return 9*L+78;
											end
										end
									else
										if Lm <= 16 then
											return 10.73*L+54.3;
										elseif Lm <= 34 then
											return 10.735*L+54;
										elseif Lm <= 35 then
											return 429;
										elseif Lm <= 41 then
											return 10.65*L+57.1;
										elseif Lm <= 49 then
											return 10.7*L+55.3;
										else
											return 9*L+141;
										end
									end
								elseif SN > "WORTHTABALBASE" then
									if SN < "WORTHTABAP" then
										if SN < "WORTHTABAN" then
											if SN == "WORTHTABAM" then
												return CalcStat("WorthTabB",L);
											else
												return 0;
											end
										elseif SN > "WORTHTABAN" then
											if SN == "WORTHTABAO" then
												return CalcStat("WorthTabE",L);
											else
												return 0;
											end
										else
											if Lm <= 50 then
												return 8.25*L+27.75;
											else
												return 8*L+40;
											end
										end
									elseif SN > "WORTHTABAP" then
										if SN < "WORTHTABAR" then
											if SN == "WORTHTABAQ" then
												if Lm <= 10 then
													return 7.5*L+60;
												elseif Lm <= 49 then
													return 5.5*L+80;
												else
													return 6*L+55;
												end
											else
												return 0;
											end
										elseif SN > "WORTHTABAR" then
											if SN == "WORTHTABAS" then
												return CalcStat("WorthTabU",L);
											else
												return 0;
											end
										else
											return CalcStat("WorthTabD",L)+37.5;
										end
									else
										return CalcStat("WorthTabAQ",L);
									end
								else
									return 9.86*L+23.51+RoundDbl(L*0.1+0.3)*0.4;
								end
							else
								return CalcStat("WorthTabE",L);
							end
						else
							if Lm <= 0 then
								return 0;
							else
								return DataTableValue({1,1.1,1.15,1.2,1.3},L);
							end
						end
					elseif SN > "WORTHTABAT" then
						if SN < "WORTHTABBW" then
							if SN < "WORTHTABBG" then
								if SN < "WORTHTABAZBASE" then
									if SN < "WORTHTABAW" then
										if SN > "WORTHTABAU" then
											if SN == "WORTHTABAV" then
												if Lm <= 4 then
													return RoundDbl(3*L+20,-1);
												elseif Lm <= 7 then
													return 70;
												elseif Lm <= 10 then
													return 140;
												elseif Lm <= 13 then
													return 270;
												elseif Lm <= 16 then
													return 400;
												elseif Lm <= 19 then
													return 460;
												elseif Lm <= 25 then
													return RoundDbl(3*L+447.5,-1);
												elseif Lm <= 46 then
													return RoundDbl(3.2*L+455,-1);
												elseif Lm <= 50 then
													return 620;
												else
													return 20*L-360;
												end
											else
												return 0;
											end
										elseif SN == "WORTHTABAU" then
											return CalcStat("WorthTabBN",L)*1.25;
										else
											return 0;
										end
									elseif SN > "WORTHTABAW" then
										if SN < "WORTHTABAY" then
											if SN == "WORTHTABAX" then
												if Lm <= 16 then
													return 10.75*L+54;
												elseif Lm <= 34 then
													return 10.75*L+53.7;
												elseif Lm <= 35 then
													return 429;
												elseif Lm <= 41 then
													return 10.65*L+57.1;
												elseif Lm <= 49 then
													return 10.68*L+56.25;
												else
													return 12*L-9;
												end
											else
												return 0;
											end
										elseif SN > "WORTHTABAY" then
											if SN == "WORTHTABAZ" then
												if Lm <= 10 then
													return CalcStat("WorthTabAZBase",L)*62.5;
												elseif Lm <= 65 then
													return CalcStat("WorthTabAZBase",L)*125;
												else
													return CalcStat("WorthTabAZBase",L)*25;
												end
											else
												return 0;
											end
										else
											return 5*L;
										end
									else
										if Lm <= 1 then
											return 50;
										elseif Lm <= 49 then
											return 2.5*L+102.5;
										elseif Lm <= 80 then
											return 3*L+78;
										elseif Lm <= 120 then
											return 2.97*L+79.5;
										else
											return 3*L+75;
										end
									end
								elseif SN > "WORTHTABAZBASE" then
									if SN < "WORTHTABBC" then
										if SN < "WORTHTABBA" then
											if SN == "WORTHTABB" then
												if Lm <= 50 then
													return 8.25*L+22.25;
												else
													return 8*L+35;
												end
											else
												return 0;
											end
										elseif SN > "WORTHTABBA" then
											if SN == "WORTHTABBB" then
												if Lm <= 1 then
													return 40;
												elseif Lm <= 10 then
													return RoundDbl(0.35*L-0.1)*20;
												elseif Lm <= 13 then
													return 100;
												elseif Lm <= 19 then
													return RoundDbl(0.35*L+1.6)*20;
												elseif Lm <= 25 then
													return RoundDbl(2*L+150,-1);
												elseif Lm <= 40 then
													return RoundDbl(2*L+164,-1);
												elseif Lm <= 49 then
													return RoundDbl(L+201,-1);
												else
													return 20*L-740;
												end
											else
												return 0;
											end
										else
											return 5*L+385;
										end
									elseif SN > "WORTHTABBC" then
										if SN < "WORTHTABBE" then
											if SN == "WORTHTABBD" then
												return CalcStat("WorthTabK",L)+1;
											else
												return 0;
											end
										elseif SN > "WORTHTABBE" then
											if SN == "WORTHTABBF" then
												return CalcStat("WorthTabAV",L)+20;
											else
												return 0;
											end
										else
											if Lm <= 1 then
												return 60;
											elseif Lm <= 7 then
												return RoundDbl(L/3)*40+30;
											elseif Lm <= 13 then
												return RoundDbl(L/3)*130-210;
											elseif Lm <= 19 then
												return RoundDbl(L/3)*60+140;
											elseif Lm <= 25 then
												return RoundDbl(L/3)*10+480;
											elseif Lm <= 46 then
												return RoundDbl(L/3)*10+490;
											elseif Lm <= 50 then
												return 660;
											else
												return 20*L-320;
											end
										end
									else
										if Lm <= 34 then
											return RoundDbl(L/15+0.8)*3750+1250;
										elseif Lm <= 35 then
											return 100000;
										else
											return 125500;
										end
									end
								else
									if Lm <= 44 then
										return RoundDbl(0.0525*L+0.7);
									elseif Lm <= 65 then
										return RoundDbl(0.19*L-4.85);
									elseif Lm <= 81 then
										return RoundDbl(0.19*L+28.15);
									else
										return RoundDbl(0.19*L+28.15+RoundDbl(L*0.05-4.55)*0.2);
									end
								end
							elseif SN > "WORTHTABBG" then
								if SN < "WORTHTABBO" then
									if SN < "WORTHTABBK" then
										if SN < "WORTHTABBI" then
											if SN == "WORTHTABBH" then
												if Lm <= 80 then
													return RoundDbl(0.05*L-0.05)+RoundDbl(0.05*L+0.45);
												else
													return RoundDbl(0.05*L-0.1)+RoundDbl(0.05*L+0.45);
												end
											else
												return 0;
											end
										elseif SN > "WORTHTABBI" then
											if SN == "WORTHTABBJ" then
												return RoundDbl(0.1*L+0.45)*3;
											else
												return 0;
											end
										else
											return CalcStat("WorthTabG",L)-25;
										end
									elseif SN > "WORTHTABBK" then
										if SN < "WORTHTABBM" then
											if SN == "WORTHTABBL" then
												if Lm <= 35 then
													return 126600;
												elseif Lm <= 46 then
													return 150600;
												elseif Lm <= 47 then
													return 180720;
												else
													return 150600;
												end
											else
												return 0;
											end
										elseif SN > "WORTHTABBM" then
											if SN == "WORTHTABBN" then
												if Lm <= 1 then
													return 400;
												else
													return 20*L+800;
												end
											else
												return 0;
											end
										else
											if Lm <= 1 then
												return 10;
											else
												return 20*L-20;
											end
										end
									else
										if Lm <= 10 then
											return RoundDbl(0.1*L+0.45);
										else
											return RoundDbl(0.1*L-0.6)*2;
										end
									end
								elseif SN > "WORTHTABBO" then
									if SN < "WORTHTABBS" then
										if SN < "WORTHTABBQ" then
											if SN == "WORTHTABBP" then
												if Lm <= 10 then
													return 156.25*L+1562.5;
												elseif Lm <= 20 then
													return 312.5*L;
												elseif Lm <= 30 then
													return 625*L-6250;
												elseif Lm <= 40 then
													return 1250*L-25000;
												else
													return 2500*L-75000;
												end
											else
												return 0;
											end
										elseif SN > "WORTHTABBQ" then
											if SN == "WORTHTABBR" then
												if Lm <= 49 then
													return CalcStat("WorthTabBQ",L)*2;
												else
													return 4*L+250;
												end
											else
												return 0;
											end
										else
											if Lm <= 1 then
												return 50;
											elseif Lm <= 49 then
												return RoundDbl(2.5*L+100);
											else
												return 3*L+75;
											end
										end
									elseif SN > "WORTHTABBS" then
										if SN < "WORTHTABBU" then
											if SN == "WORTHTABBT" then
												return 62500;
											else
												return 0;
											end
										elseif SN > "WORTHTABBU" then
											if SN == "WORTHTABBV" then
												if Lm <= 29 then
													return 1250;
												else
													return RoundDbl(0.05*L-1)*2500;
												end
											else
												return 0;
											end
										else
											if Lm <= 80 then
												return 20*L+300;
											else
												return 10*L+1100;
											end
										end
									else
										return CalcStat("WorthTabBR",L)*2;
									end
								else
									if Lm <= 10 then
										return 10;
									elseif Lm <= 40 then
										return RoundDbl(0.1*L-0.55)*50-25;
									elseif Lm <= 80 then
										return RoundDbl(0.1*L-0.55)*50;
									else
										return RoundDbl(0.1*L-0.55)*25+175;
									end
								end
							else
								if Lm <= 7 then
									return RoundDbl(0.2*L-0.4)*2+1;
								elseif Lm <= 16 then
									return RoundDbl(L/3-2)*6;
								elseif Lm <= 22 then
									return RoundDbl(L/3+1)*3;
								elseif Lm <= 25 then
									return RoundDbl(L/3+1)*3-2;
								elseif Lm <= 80 then
									return RoundDbl(L/3+18)-2;
								else
									return L-37;
								end
							end
						elseif SN > "WORTHTABBW" then
							if SN < "WORTHTABCL" then
								if SN < "WORTHTABCD" then
									if SN < "WORTHTABC" then
										if SN < "WORTHTABBY" then
											if SN == "WORTHTABBX" then
												if Lm <= 10 then
													return RoundDbl(0.1*L+0.45)*3;
												elseif Lm <= 140 then
													return RoundDbl(0.1*L-0.6)*6;
												else
													return RoundDbl(0.1*L+0.4)*4+22;
												end
											else
												return 0;
											end
										elseif SN > "WORTHTABBY" then
											if SN == "WORTHTABBZ" then
												if Lm <= 10 then
													return 27.42*L+273.1;
												elseif Lm <= 20 then
													return 54.69*L;
												elseif Lm <= 30 then
													return 109.35*L-1093;
												elseif Lm <= 40 then
													return 218.75*L-4375;
												elseif Lm <= 80 then
													return 437.5*L-13125;
												else
													return 437*L-13085;
												end
											else
												return 0;
											end
										else
											return 90000;
										end
									elseif SN > "WORTHTABC" then
										if SN < "WORTHTABCB" then
											if SN == "WORTHTABCA" then
												if Lm <= 10 then
													return 7.25*L+72.25;
												elseif Lm <= 20 then
													return 14.49*L+0.11;
												elseif Lm <= 30 then
													return 29*L-290;
												elseif Lm <= 35 then
													return 57.99*L-1160.16;
												elseif Lm <= 40 then
													return 57.99*L-1160.12;
												elseif Lm <= 80 then
													return 115.94*L-3478.2;
												else
													return 116*L-3483;
												end
											else
												return 0;
											end
										elseif SN > "WORTHTABCB" then
											if SN == "WORTHTABCC" then
												return CalcStat("WorthTabBK",L)*5;
											else
												return 0;
											end
										else
											return 0.1;
										end
									else
										return CalcStat("WorthTabD",L)+20;
									end
								elseif SN > "WORTHTABCD" then
									if SN < "WORTHTABCH" then
										if SN < "WORTHTABCF" then
											if SN == "WORTHTABCE" then
												return CalcStat("WorthTabBN",L)*10;
											else
												return 0;
											end
										elseif SN > "WORTHTABCF" then
											if SN == "WORTHTABCG" then
												return 20;
											else
												return 0;
											end
										else
											if Lm <= 20 then
												return RoundDbl(0.1*L-0.55)*600+200;
											elseif Lm <= 40 then
												return RoundDbl(0.1*L-0.55)*1000-500;
											elseif Lm <= 60 then
												return RoundDbl(0.1*L-0.55)*2000-4000;
											elseif Lm <= 70 then
												return 8500;
											elseif Lm <= 140 then
												return RoundDbl(0.1*L-0.55)*2500-7500;
											elseif Lm <= 200 then
												return RoundDbl(0.1*L-0.55)*3000-14000;
											else
												return RoundDbl(0.1*L-0.55)*2500-3500;
											end
										end
									elseif SN > "WORTHTABCH" then
										if SN < "WORTHTABCJ" then
											if SN == "WORTHTABCI" then
												return 40000;
											else
												return 0;
											end
										elseif SN > "WORTHTABCJ" then
											if SN == "WORTHTABCK" then
												return 15000;
											else
												return 0;
											end
										else
											return 20000;
										end
									else
										return 50000;
									end
								else
									return CalcStat("WorthTabBK",L)*25;
								end
							elseif SN > "WORTHTABCL" then
								if SN < "WORTHTABE" then
									if SN < "WORTHTABCP" then
										if SN < "WORTHTABCN" then
											if SN == "WORTHTABCM" then
												return 7500;
											else
												return 0;
											end
										elseif SN > "WORTHTABCN" then
											if SN == "WORTHTABCO" then
												return CalcStat("WorthTabAB",L);
											else
												return 0;
											end
										else
											return RoundDbl(0.1*L+0.5)*10000;
										end
									elseif SN > "WORTHTABCP" then
										if SN < "WORTHTABCR" then
											if SN == "WORTHTABCQ" then
												if Lm <= 10 then
													return RoundDbl(0.3*L+0.2)*2;
												elseif Lm <= 16 then
													return RoundDbl(0.25*L-1)*6;
												elseif Lm <= 22 then
													return RoundDbl(0.3*L+5.5)*2;
												elseif Lm <= 50 then
													return RoundDbl((1/6)*L+8.75)*2;
												elseif Lm <= 80 then
													return RoundDbl((1/3)*L-11.5)*6;
												else
													return RoundDbl(0.25*L-4.6)*6;
												end
											else
												return 0;
											end
										elseif SN > "WORTHTABCR" then
											if SN == "WORTHTABD" then
												if Lm <= 49 then
													return 7.5*L;
												else
													return 8*L-25;
												end
											else
												return 0;
											end
										else
											return CalcStat("WorthTabM",L)-15;
										end
									else
										return 1;
									end
								elseif SN > "WORTHTABE" then
									if SN < "WORTHTABI" then
										if SN < "WORTHTABG" then
											if SN == "WORTHTABF" then
												return 0.1;
											else
												return 0;
											end
										elseif SN > "WORTHTABG" then
											if SN == "WORTHTABH" then
												if Lm <= 2 then
													return L;
												elseif Lm <= 9 then
													return 1.48*L-2.85;
												elseif Lm <= 11 then
													return 2.5*L-13;
												elseif Lm <= 24 then
													return 2.5*L-10;
												else
													return 5*L-70;
												end
											else
												return 0;
											end
										else
											if Lm <= 1 then
												return 50;
											else
												return CalcStat("WorthTabAF",L)+100;
											end
										end
									elseif SN > "WORTHTABI" then
										if SN < "WORTHTABK" then
											if SN == "WORTHTABJ" then
												if Lm <= 4 then
													return 2.5*L+7.5;
												elseif Lm <= 5 then
													return 23;
												else
													return 4*L;
												end
											else
												return 0;
											end
										elseif SN > "WORTHTABK" then
											if SN == "WORTHTABL" then
												return CalcStat("WorthTabB",L)+19.25;
											else
												return 0;
											end
										else
											if Lm <= 9 then
												return 12*L+24;
											else
												return 7*L+74;
											end
										end
									else
										if Lm <= 4 then
											return 1;
										elseif Lm <= 10 then
											return 0.7*L-1;
										elseif Lm <= 15 then
											return 1.4*L-7;
										elseif Lm <= 24 then
											return 1.25*L-5;
										elseif Lm <= 49 then
											return 2.5*L-35;
										else
											return 3*L-60;
										end
									end
								else
									if Lm <= 9 then
										return 30*L+50;
									else
										return 7*L+280;
									end
								end
							else
								return 12500;
							end
						else
							if Lm <= 1 then
								return 645;
							elseif Lm <= 9 then
								return 20*L+980;
							else
								return 50*L+920;
							end
						end
					else
						if Lm <= 4 then
							return RoundDbl(3*L+20,-1);
						elseif Lm <= 7 then
							return 60;
						elseif Lm <= 10 then
							return 100;
						elseif Lm <= 13 then
							return 180;
						elseif Lm <= 16 then
							return 270;
						elseif Lm <= 19 then
							return 310;
						elseif Lm <= 40 then
							return RoundDbl(3.2*L+274,-1);
						elseif Lm <= 43 then
							return 400;
						elseif Lm <= 53 then
							return RoundDbl(1.9*L+334,-1);
						elseif Lm <= 56 then
							return 460;
						elseif Lm <= 59 then
							return 480;
						else
							return 20*L-680;
						end
					end
				elseif SN > "WORTHTABM" then
					if SN < "WORTHVALBV" then
						if SN < "WORTHVALAQ" then
							if SN < "WORTHVALAA" then
								if SN < "WORTHTABT" then
									if SN < "WORTHTABP" then
										if SN > "WORTHTABN" then
											if SN == "WORTHTABO" then
												return CalcStat("WorthTabB",L)+11;
											else
												return 0;
											end
										elseif SN == "WORTHTABN" then
											return CalcStat("WorthTabAF",L)+25;
										else
											return 0;
										end
									elseif SN > "WORTHTABP" then
										if SN < "WORTHTABR" then
											if SN == "WORTHTABQ" then
												return 7*L+25;
											else
												return 0;
											end
										elseif SN > "WORTHTABR" then
											if SN == "WORTHTABS" then
												return CalcStat("WorthTabD",L)+17.5;
											else
												return 0;
											end
										else
											if Lm <= 9 then
												return 12*L+30;
											else
												return 7*L+75;
											end
										end
									else
										return CalcStat("WorthTabE",L);
									end
								elseif SN > "WORTHTABT" then
									if SN < "WORTHTABX" then
										if SN < "WORTHTABV" then
											if SN == "WORTHTABU" then
												if Lm <= 10 then
													return 9*L+20;
												elseif Lm <= 49 then
													return 5.5*L+55;
												else
													return 6*L+30;
												end
											else
												return 0;
											end
										elseif SN > "WORTHTABV" then
											if SN == "WORTHTABW" then
												return CalcStat("WorthTabD",L)+25;
											else
												return 0;
											end
										else
											return CalcStat("WorthTabB",L)-2.75;
										end
									elseif SN > "WORTHTABX" then
										if SN < "WORTHTABZ" then
											if SN == "WORTHTABY" then
												return CalcStat("WorthTabD",L)+30;
											else
												return 0;
											end
										elseif SN > "WORTHTABZ" then
											if SN == "WORTHVALA" then
												return RoundDbl(CalcStat("WorthMpA",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabA"));
											else
												return 0;
											end
										else
											return CalcStat("WorthTabR",L)-15;
										end
									else
										return CalcStat("WorthTabAF",L)+75;
									end
								else
									if Lm <= 1 then
										return 54;
									elseif Lm <= 17 then
										return 10.73*L+43.57;
									elseif Lm <= 35 then
										return 10.735*L+43.265;
									elseif Lm <= 36 then
										return 429;
									elseif Lm <= 42 then
										return 10.65*L+46.45;
									elseif Lm <= 49 then
										return 10.7*L+44.6;
									else
										return 9*L+130;
									end
								end
							elseif SN > "WORTHVALAA" then
								if SN < "WORTHVALAI" then
									if SN < "WORTHVALAE" then
										if SN < "WORTHVALAC" then
											if SN == "WORTHVALAB" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAB"));
											else
												return 0;
											end
										elseif SN > "WORTHVALAC" then
											if SN == "WORTHVALAD" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAD"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAC"));
										end
									elseif SN > "WORTHVALAE" then
										if SN < "WORTHVALAG" then
											if SN == "WORTHVALAF" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAF"));
											else
												return 0;
											end
										elseif SN > "WORTHVALAG" then
											if SN == "WORTHVALAH" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt8Lin",L,"WorthTabAH"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAG"));
										end
									else
										return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAE"));
									end
								elseif SN > "WORTHVALAI" then
									if SN < "WORTHVALAM" then
										if SN < "WORTHVALAK" then
											if SN == "WORTHVALAJ" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt8Lin",L,"WorthTabAJ"));
											else
												return 0;
											end
										elseif SN > "WORTHVALAK" then
											if SN == "WORTHVALAL" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt8Lin",L,"WorthTabAL"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt8Lin",L,"WorthTabAK"));
										end
									elseif SN > "WORTHVALAM" then
										if SN < "WORTHVALAO" then
											if SN == "WORTHVALAN" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAN"));
											else
												return 0;
											end
										elseif SN > "WORTHVALAO" then
											if SN == "WORTHVALAP" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAP"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAO"));
										end
									else
										return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAM"));
									end
								else
									return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt8Lin",L,"WorthTabAI"));
								end
							else
								return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAA"));
							end
						elseif SN > "WORTHVALAQ" then
							if SN < "WORTHVALBF" then
								if SN < "WORTHVALAY" then
									if SN < "WORTHVALAU" then
										if SN < "WORTHVALAS" then
											if SN == "WORTHVALAR" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAR"));
											else
												return 0;
											end
										elseif SN > "WORTHVALAS" then
											if SN == "WORTHVALAT" then
												return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAT"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAS"));
										end
									elseif SN > "WORTHVALAU" then
										if SN < "WORTHVALAW" then
											if SN == "WORTHVALAV" then
												return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAV"));
											else
												return 0;
											end
										elseif SN > "WORTHVALAW" then
											if SN == "WORTHVALAX" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAX"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpA",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAW"));
										end
									else
										return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAU"));
									end
								elseif SN > "WORTHVALAY" then
									if SN < "WORTHVALBB" then
										if SN < "WORTHVALB" then
											if SN == "WORTHVALAZ" then
												return RoundDbl(CalcStat("WorthMpA",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabAZ"));
											else
												return 0;
											end
										elseif SN > "WORTHVALB" then
											if SN == "WORTHVALBA" then
												return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabBA"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabB"));
										end
									elseif SN > "WORTHVALBB" then
										if SN < "WORTHVALBD" then
											if SN == "WORTHVALBC" then
												return RoundDbl(CalcStat("WorthMpE",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBC"));
											else
												return 0;
											end
										elseif SN > "WORTHVALBD" then
											if SN == "WORTHVALBE" then
												return RoundDbl(CalcStat("WorthMpJ",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBE"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBD"));
										end
									else
										return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBB"));
									end
								else
									return RoundDbl(CalcStat("WorthMpA",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabAY"));
								end
							elseif SN > "WORTHVALBF" then
								if SN < "WORTHVALBN" then
									if SN < "WORTHVALBJ" then
										if SN < "WORTHVALBH" then
											if SN == "WORTHVALBG" then
												return RoundDbl(CalcStat("WorthMpA",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabBG"));
											else
												return 0;
											end
										elseif SN > "WORTHVALBH" then
											if SN == "WORTHVALBI" then
												return RoundDbl(CalcStat("WorthMpA",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBI"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabBH"));
										end
									elseif SN > "WORTHVALBJ" then
										if SN < "WORTHVALBL" then
											if SN == "WORTHVALBK" then
												return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabBK"));
											else
												return 0;
											end
										elseif SN > "WORTHVALBL" then
											if SN == "WORTHVALBM" then
												return RoundDbl(CalcStat("WorthMpA",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBM"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpE",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBL"));
										end
									else
										return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabBJ"));
									end
								elseif SN > "WORTHVALBN" then
									if SN < "WORTHVALBR" then
										if SN < "WORTHVALBP" then
											if SN == "WORTHVALBO" then
												return RoundDbl(CalcStat("WorthMpG",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBO"));
											else
												return 0;
											end
										elseif SN > "WORTHVALBP" then
											if SN == "WORTHVALBQ" then
												return RoundDbl(CalcStat("WorthMpE",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBQ"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBP"));
										end
									elseif SN > "WORTHVALBR" then
										if SN < "WORTHVALBT" then
											if SN == "WORTHVALBS" then
												return RoundDbl(CalcStat("WorthMpE",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBS"));
											else
												return 0;
											end
										elseif SN > "WORTHVALBT" then
											if SN == "WORTHVALBU" then
												return RoundDbl(CalcStat("WorthMpF",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabBU"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBT"));
										end
									else
										return RoundDbl(CalcStat("WorthMpE",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBR"));
									end
								else
									return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBN"));
								end
							else
								return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBF"));
							end
						else
							return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabAQ"));
						end
					elseif SN > "WORTHVALBV" then
						if SN < "WORTHVALL" then
							if SN < "WORTHVALCK" then
								if SN < "WORTHVALCC" then
									if SN < "WORTHVALBZ" then
										if SN < "WORTHVALBX" then
											if SN == "WORTHVALBW" then
												return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBW"));
											else
												return 0;
											end
										elseif SN > "WORTHVALBX" then
											if SN == "WORTHVALBY" then
												return RoundDbl(CalcStat("WorthMpE",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBY"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabBX"));
										end
									elseif SN > "WORTHVALBZ" then
										if SN < "WORTHVALCA" then
											if SN == "WORTHVALC" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabC"));
											else
												return 0;
											end
										elseif SN > "WORTHVALCA" then
											if SN == "WORTHVALCB" then
												return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCB"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCA"));
										end
									else
										return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabBZ"));
									end
								elseif SN > "WORTHVALCC" then
									if SN < "WORTHVALCG" then
										if SN < "WORTHVALCE" then
											if SN == "WORTHVALCD" then
												return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabCD"));
											else
												return 0;
											end
										elseif SN > "WORTHVALCE" then
											if SN == "WORTHVALCF" then
												return RoundDbl(CalcStat("WorthMpA",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabCF"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpH",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCE"));
										end
									elseif SN > "WORTHVALCG" then
										if SN < "WORTHVALCI" then
											if SN == "WORTHVALCH" then
												return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCH"));
											else
												return 0;
											end
										elseif SN > "WORTHVALCI" then
											if SN == "WORTHVALCJ" then
												return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCJ"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCI"));
										end
									else
										return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCG"));
									end
								else
									return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabCC"));
								end
							elseif SN > "WORTHVALCK" then
								if SN < "WORTHVALD" then
									if SN < "WORTHVALCO" then
										if SN < "WORTHVALCM" then
											if SN == "WORTHVALCL" then
												return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCL"));
											else
												return 0;
											end
										elseif SN > "WORTHVALCM" then
											if SN == "WORTHVALCN" then
												return RoundDbl(CalcStat("WorthMpI",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCN"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCM"));
										end
									elseif SN > "WORTHVALCO" then
										if SN < "WORTHVALCQ" then
											if SN == "WORTHVALCP" then
												return RoundDbl(CalcStat("WorthMpA",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCP"));
											else
												return 0;
											end
										elseif SN > "WORTHVALCQ" then
											if SN == "WORTHVALCR" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCR"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpK",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCQ"));
										end
									else
										return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCO"));
									end
								elseif SN > "WORTHVALD" then
									if SN < "WORTHVALH" then
										if SN < "WORTHVALF" then
											if SN == "WORTHVALE" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabE"));
											else
												return 0;
											end
										elseif SN > "WORTHVALF" then
											if SN == "WORTHVALG" then
												return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabG"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabF"));
										end
									elseif SN > "WORTHVALH" then
										if SN < "WORTHVALJ" then
											if SN == "WORTHVALI" then
												return RoundDbl(CalcStat("WorthMpA",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabI"));
											else
												return 0;
											end
										elseif SN > "WORTHVALJ" then
											if SN == "WORTHVALK" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabK"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpA",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabJ"));
										end
									else
										return RoundDbl(CalcStat("WorthMpA",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabH"));
									end
								else
									return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabD"));
								end
							else
								return RoundDbl(CalcStat("WorthMpC",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabCK"));
							end
						elseif SN > "WORTHVALL" then
							if SN < "WPNDMGMAX" then
								if SN < "WORTHVALT" then
									if SN < "WORTHVALP" then
										if SN < "WORTHVALN" then
											if SN == "WORTHVALM" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabM"));
											else
												return 0;
											end
										elseif SN > "WORTHVALN" then
											if SN == "WORTHVALO" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabO"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabN"));
										end
									elseif SN > "WORTHVALP" then
										if SN < "WORTHVALR" then
											if SN == "WORTHVALQ" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabQ"));
											else
												return 0;
											end
										elseif SN > "WORTHVALR" then
											if SN == "WORTHVALS" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabS"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabR"));
										end
									else
										return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabP"));
									end
								elseif SN > "WORTHVALT" then
									if SN < "WORTHVALX" then
										if SN < "WORTHVALV" then
											if SN == "WORTHVALU" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabU"));
											else
												return 0;
											end
										elseif SN > "WORTHVALV" then
											if SN == "WORTHVALW" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabW"));
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabV"));
										end
									elseif SN > "WORTHVALX" then
										if SN < "WORTHVALZ" then
											if SN == "WORTHVALY" then
												return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabY"));
											else
												return 0;
											end
										elseif SN > "WORTHVALZ" then
											if SN == "WOUNDRESISTT" then
												return CalcStat("ResistAddT",L,N);
											else
												return 0;
											end
										else
											return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabZ"));
										end
									else
										return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabX"));
									end
								else
									return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt8Lin",L,"WorthTabT"));
								end
							elseif SN > "WPNDMGMAX" then
								if SN < "WRDPHYMAS" then
									if SN < "WRDBATSTRIKESCRITDEF" then
										if SN < "WPNDPS" then
											if SN == "WPNDMGMIN" then
												return ((2-2*CalcStat("WpnDPSVarianceType",WpnCodeIndex(C,2)))/(2-CalcStat("WpnDPSVarianceType",WpnCodeIndex(C,2))))*CalcStat("CombatBase",L,C);
											else
												return 0;
											end
										elseif SN > "WPNDPS" then
											if SN == "WPNDPSVARIANCETYPE" then
												if Lm <= 0 then
													return 0;
												else
													return DataTableValue({0.25,0.25,0.25},L);
												end
											else
												return 0;
											end
										else
											return CalcStat("CombatBase",L,C);
										end
									elseif SN > "WRDBATSTRIKESCRITDEF" then
										if SN < "WRDFINESSE" then
											if SN == "WRDCRITDEF" then
												return CalcStat("CritDefT",L,1.0);
											else
												return 0;
											end
										elseif SN > "WRDFINESSE" then
											if SN == "WRDIMPRBLADESPARRY" then
												return CalcStat("ParryT",L,2.8);
											else
												return 0;
											end
										else
											return CalcStat("FinesseT",L,CalcStat("Trait12345Choice",N)*0.4);
										end
									else
										return CalcStat("CritDefT",L,CalcStat("Trait123Choice",N)*0.4);
									end
								elseif SN > "WRDPHYMAS" then
									if SN < "WRDSSSHPIERCERBLOCK" then
										if SN < "WRDSHIELDMASBLOCK" then
											if SN == "WRDRECKLESSNCRITHIT" then
												return CalcStat("CritHitT",L,2.4);
											else
												return 0;
											end
										elseif SN > "WRDSHIELDMASBLOCK" then
											if SN == "WRDSHIELDTACTCRITDEF" then
												return CalcStat("CritDefT",L,2);
											else
												return 0;
											end
										else
											return CalcStat("BlockT",L,2.8);
										end
									elseif SN > "WRDSSSHPIERCERBLOCK" then
										if SN < "WRDSTDYOURGREVADE" then
											if SN == "WRDSTDYOURGRBLOCK" then
												return CalcStat("BlockT",L,CalcStat("Trait1234Choice",N)*0.4);
											else
												return 0;
											end
										elseif SN > "WRDSTDYOURGREVADE" then
											if SN == "WRDSTDYOURGRPARRY" then
												return CalcStat("ParryT",L,CalcStat("Trait1234Choice",N)*0.4);
											else
												return 0;
											end
										else
											return -CalcStat("EvadeT",L,CalcStat("Trait1234Choice",N)*0.4);
										end
									else
										return -CalcStat("BlockT",L,4);
									end
								else
									return CalcStat("PhyMasT",L,CalcStat("Trait12345Choice",N)*0.4);
								end
							else
								return (2/(2-CalcStat("WpnDPSVarianceType",WpnCodeIndex(C,2))))*CalcStat("CombatBase",L,C);
							end
						else
							return RoundDbl(CalcStat("WorthMpB",QualityCodeIndex(C))*CalcStat("WorthExt",L,"WorthTabL"));
						end
					else
						return RoundDbl(CalcStat("WorthMpD",QualityCodeIndex(C))*CalcStat("WorthExt4Lin",L,"WorthTabBV"));
					end
				else
					if Lm <= 9 then
						return 10*L+11;
					elseif Lm <= 49 then
						return 4*L+65;
					else
						return 5*L+15;
					end
				end
			else
				return 2;
			end
		else
			return CalcStat("MitLightPRatPA",L);
		end
	else
		return CalcStat("ClassBaseWillH",L);
	end

end

-- Support functions for CalcStat. These consist of implementations of more complex calculation types, decode methods for parameter "C" and rounding/min/max/compare functions for floating point numbers.

-- ****************** Calculation Type support functions ******************

-- DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
-- DataTableValue: Takes a value from an array table.

function DataTableValue(vDataArray, dIndex)

	local lIndex = RoundDbl(dIndex);
	if lIndex <= 1 then
		return vDataArray[1];
	elseif lIndex > #vDataArray then
		return vDataArray[#vDataArray];
	else
		return vDataArray[lIndex];
	end

end

-- EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
-- ExpFmod: Exponential function based on percentage.
-- Common percentage values are around ~5.5% for between levels and ~20% jumps between level segments.

function ExpFmod(dVal, dLstart, dPlvl, dLvl, vDec, vAdd)

	local dRng = dLvl-dLstart+1;
	if dRng <= DblCalcDev then
		return dVal;
	else
		local dFac = 1+dPlvl/100;
		local dAdd;
		if vAdd == nil then
			dAdd = 0;
		else
			dAdd = vAdd;
		end
		if vDec == nil then
			local dFacExp = dFac^dRng;
			return dVal*dFacExp+dAdd*((dFacExp-1)/(dFac-1));
		else
			local dResult = dVal;
			local dLm = dLstart-DblCalcDev;
			while dLm <= dLvl do
				dResult = RoundDbl(dResult*dFac+dAdd,vDec);
				dLm = dLm+1;
			end
			return dResult;
		end
	end

end

-- PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP
-- CalcPercAB: Calculates the percentage out of a rating based on the AB formula.

function CalcPercAB(dA, dB, dPCap, dR)

	if dR <= DblCalcDev then
		return 0.0;
	else
		local dResult = dA/(1+dB/dR);
		if dResult >= dPCap-DblCalcDev then
			return dPCap;
		else
			return dResult;
		end
	end

end

-- RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
-- CalcRatAB: Calculates the rating out of a percentage based on the AB formula.

function CalcRatAB(dA, dB, dCapR, dP)

	if dP <= DblCalcDev then
		return 0.0;
	else
		local dResult = dB/(dA/dP-1);
		if dResult >= dCapR-DblCalcDev then
			return dCapR;
		else
			return dResult;
		end
	end

end

-- SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS
-- StatLinInter: (Normalized) Stat Linear Interpolating

function StatLinInter(sPntMP, sProgScheme, sProgBase, sAdj, dLvl, vNorC, vRoundType)

	-- parameter processing
	local dN = 1;
	local sC = "";
	if type(vNorC) == "number" then
		dN = vNorC;
	elseif type(vNorC) == "string" then
		sC = vNorC;
	end

	local dRoundType = 0;
	if type(vRoundType) == "number" then
		dRoundType = vRoundType;
	end
	
	local dProgScheme = CalcStat(sProgScheme,dLvl);
	if type(dProgScheme) ~= "table" then
		return 0.0;
	end

	-- find level interval
	local dLvlMinus = dLvl-DblCalcDev;
	local iPointIndexHigh = 2;
	local iPointIndexMax = #dProgScheme[1];
	while iPointIndexHigh < iPointIndexMax do
		if dLvlMinus <= dProgScheme[1][iPointIndexHigh] then
			break;
		end
		iPointIndexHigh = iPointIndexHigh+1;
	end
	local iPointIndexLow = iPointIndexHigh-1;
		
	local dAccessLvlLow = dProgScheme[1][iPointIndexLow];
	local dAccessLvlHigh = dProgScheme[1][iPointIndexHigh];
	local dBaseLvlLow = dProgScheme[2][iPointIndexLow];
	local dBaseLvlHigh = dProgScheme[2][iPointIndexHigh];
	
	-- get values from base progression
	local dValLow = CalcStat(sProgBase,dBaseLvlLow,sC);
	local dValHigh = CalcStat(sProgBase,dBaseLvlHigh,sC);

	-- graph point multiplications
	if type(sPntMP) == "string" and sPntMP ~= "" then
		dValLow = dValLow*CalcStat(sPntMP,dAccessLvlLow,sC);
		dValHigh = dValHigh*CalcStat(sPntMP,dAccessLvlHigh,sC);
	end
	if type(sAdj) == "string" and sAdj ~= "" then
		dValLow = dValLow*CalcStat(sAdj,dAccessLvlLow,sC);
		dValHigh = dValHigh*CalcStat(sAdj,dAccessLvlHigh,sC);
	end
	dValLow = dValLow*dN;
	dValHigh = dValHigh*dN;

	-- graph point roundings
	if dRoundType == 0 then
		dValLow = RoundDblLotro(dValLow);
		dValHigh = RoundDblLotro(dValHigh);
	elseif dRoundType == 1 then
		if -100.0 <= dValLow and dValLow <= 100.0 then
			dValLow = RoundDblUp(dValLow,2);
		elseif -1000.0 <= dValLow and dValLow <= 1000.0 then
			dValLow = RoundDblUp(dValLow,1);
		else
			dValLow = RoundDblLotro(dValLow);
		end
		if -100.0 <= dValHigh and dValHigh <= 100.0 then
			dValHigh = RoundDblUp(dValHigh,2);
		elseif -1000.0 <= dValHigh and dValHigh <= 1000.0 then
			dValHigh = RoundDblUp(dValHigh,1);
		else
			dValHigh = RoundDblLotro(dValHigh);
		end
	elseif dRoundType == 2 then
		dValLow = RoundDblLotro(dValLow);
		if dValLow == -1 then
			dValLow = -2;
		end
		dValHigh = RoundDblLotro(dValHigh);
		if dValHigh == -1 then
			dValHigh = -2;
		end
	elseif dRoundType == 3 then
		dValLow = RoundDblProg(dValLow);
		dValHigh = RoundDblProg(dValHigh);
	end

	-- return interpolated value from the calculated graph points
	return LinFmod(1,dValLow,dValHigh,dAccessLvlLow,dAccessLvlHigh,dLvl);

end

-- TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
-- LinFmod: Linear line function between 2 points with some optional modifications.
-- Connects point (dLstart,dVal*dFstart) with (dLend,dVal*dFend).
-- Usually used with dVal=1 and dFstart/dFend containing unrelated points or dVal=# and dFstart/dFend containing multiplier factors.
-- Modification for in-between points on the line: rounding.

function LinFmod(dVal, dFstart, dFend, dLstart, dLend, dLvl, vDec)

	if type(vDec) == "string" then
		local sRoundType = string.upper(vDec);
		if sRoundType == "P" then
			return LinFmod(1,RoundDblProg(dVal*dFstart),RoundDblProg(dVal*dFend),dLstart,dLend,dLvl);
		elseif sRoundType == "L" then
			return LinFmod(1,RoundDblLotro(dVal*dFstart),RoundDblLotro(dVal*dFend),dLstart,dLend,dLvl);
		else
			return LinFmod(1,dVal*dFstart,dVal*dFend,dLstart,dLend,dLvl);
		end
	end
	if dLstart-DblCalcDev <= dLvl and dLvl <= dLstart+DblCalcDev then
		return dVal*dFstart;
	elseif dLend-DblCalcDev <= dLvl and dLvl <= dLend+DblCalcDev then
		return dVal*dFend;
	elseif dLstart == dLend then
		return 0.0;
	elseif vDec == nil then
		return dVal*(dFstart*(dLend-dLvl)+(dLvl-dLstart)*dFend)/(dLend-dLstart);
	else
		return RoundDbl(dVal*(dFstart*(dLend-dLvl)+(dLvl-dLstart)*dFend)/(dLend-dLstart),vDec);
	end

end

-- ****************** Parameter "C" decode support functions ******************

-- ArmCodeIndex: returns a specified index from an Armour Code.
-- sACode string:
-- 1st position: H=heavy, M=medium, L=light
-- 2nd position: H=head, S=shoulders, CL=cloak/back, C=chest, G=gloves, L=leggings, B=boots, Sh=shield
-- 3rd position: W=white/common, Y=yellow/uncommon, P=purple/rare, T=teal/blue/incomparable, G=gold/legendary/epic
-- Note: no such thing exists as a heavy, medium or light cloak, so no H/M/L in cloak codes (cloaks go automatically in the M class since U23, although historically this was L)

function ArmCodeIndex(sACode, iI)

	if sACode == nil or iI == nil then
		return 0;
	end
	if type(sACode) ~= "string" or type(iI) ~= "number" then
		return 0;
	end

	local sArmCode = string.match(sACode,"(%a+)");
	if not sArmCode then
		return 0;
	end
	sArmCode = string.upper(sArmCode).."    ";
	
	local sArmCat = string.sub(sArmCode,1,1);
	local sArmType = string.sub(sArmCode,2,2);
	local sArmCol = string.sub(sArmCode,3,3);

	if sArmType == "S" and sArmCol == "H" then
		sArmType = "SH";
		sArmCol = string.sub(sArmCode,4,4);
	elseif sArmCat == "C" and sArmType == "L" then
		sArmCat = "M";
		sArmType = "CL";
	elseif sArmType then
		sArmType = " "..sArmType;
	end
	
	local result = 0;
	if iI == 1 then
		if sArmCat then
			result = string.find("HML",sArmCat);
		end
	elseif iI == 2 then
		if sArmType then
			result = string.find(" H SCL C G L BSH",sArmType);
			if result then
				result = (result+1)/2;
			end
		end
	elseif iI == 3 then
		if sArmCol then
			result = string.find("WYPTG",sArmCol);
		end
	end

	if result then
		return result;
	else
		return 0;
	end
	
end

-- QualityCodeIndex: returns a quality index from a Quality Code.
-- sQCode string: W=white/common, Y=yellow/uncommon, P=purple/rare, T=teal/blue/incomparable, G=gold/legendary/epic

function QualityCodeIndex(sQCode)

	if sQCode == nil then
		return 0;
	end
	if type(sQCode) ~= "string" then
		return 0;
	end

	local sQtyCode = string.match(sQCode,"(%a+)");
	if not sQtyCode then
		return 0;
	end
	sQtyCode = string.upper(sQtyCode).." ";

	local sQtyCol = string.sub(sQtyCode,1,1);
	
	local result = 0;
	if sQtyCol then
		result = string.find("WYPTG",sQtyCol);
	end
	
	if result then
		return result;
	else
		return 0;
	end
	
end

-- WpnCodeIndex: returns a specified index from a Weapon Code.
-- sWCode string:
-- 1st position: H=heavy, L=light
-- 2nd position: O=one-handed, T=two-handed, B=bow
-- 3rd position: W=white/common, Y=yellow/uncommon, P=purple/rare, T=teal/blue/incomparable, G=gold/legendary/epic

function WpnCodeIndex(sWCode, iI)

	if sWCode == nil or iI == nil then
		return 0;
	end
	if type(sWCode) ~= "string" or type(iI) ~= "number" then
		return 0;
	end

	local sWpnCode = string.match(sWCode,"(%a+)");
	if not sWpnCode then
		return 0;
	end
	sWpnCode = string.upper(sWpnCode).."   ";
	
	local sWpnCat = string.sub(sWpnCode,1,1);
	local sWpnType = string.sub(sWpnCode,2,2);
	local sWpnCol = string.sub(sWpnCode,3,3);

	local result = 0;
	if iI == 1 then
		if sWpnCat then
			result = string.find("HL",sWpnCat);
		end
	elseif iI == 2 then
		if sWpnType then
			result = string.find("OTB",sWpnType);
		end
	elseif iI == 3 then
		if sWpnCol then
			result = string.find("WYPTG",sWpnCol);
		end
	end

	if result then
		return result;
	else
		return 0;
	end
	
end

-- RomanRankDecode: converts a string with a Roman number in characters, to an integer number.
-- used for Legendary Item Title calculation.

local RomanCharsToValues = {["M"]=1000,["CM"]=900,["D"]=500,["CD"]=400,["C"]=100,["XC"]=90,["L"]=50,["XL"]=40,["X"]=10,["IX"]=9,["V"]=5,["IV"]=4,["I"]=1};

function RomanRankDecode(sNumber)

	if sNumber ~= nil and type(sNumber) == "string" and sNumber ~= "" then
		for sRomanRankChar, iRomanRankValue in pairs(RomanCharsToValues) do
			if string.sub(string.upper(sNumber),1,string.len(sRomanRankChar)) == sRomanRankChar then
				return iRomanRankValue+RomanRankDecode(string.sub(sNumber,string.len(sRomanRankChar)+1));
			end
		end
	end
	
	return 0;
	
end

-- ReverseCalc: tries to calculate back a calculation result to the original (integer) level.
-- Does not support N.

function ReverseCalc(sStat, dNum)

	if string.len(string.match(sStat,"([-%w]+)")) > 0 then
		local dNumMinus = dNum-DblCalcDev;
		local dNumPlus = dNum+DblCalcDev;
		local minlvl = 1;
		local maxlvl = 549;
		local devlvl = 3;
	
		local left = minlvl-1;
		local right = maxlvl;
		local middle;
		
		local count = minlvl;

		while right > left+1 and count <= maxlvl do
			count = count+1;
			middle = math.floor((left+right)/2);
			if CalcStat(sStat,middle) >= dNumMinus then
				right = middle;
			else
				left = middle;
			end
		end

		local mintest = right-devlvl;
		if mintest < minlvl then
			mintest = minlvl;
		end
		local maxtest = right+devlvl;
		if maxtest > maxlvl then
			maxtest = maxlvl;
		end

		local dFound;
	
		-- we check nearby in case the progression is not completely ascending/sorted.
		for test = mintest, maxtest do
			dFound = CalcStat(sStat,test);
			if dNumMinus <= dFound and dFound <= dNumPlus then
				return test;
			end
		end
	end

	return 0;

end

-- ****************** Misc. floating point support functions ******************

-- Misc. functions for floating point rounding.
-- 2nd parameter is number of decimals.

function RoundDbl(dNum, vDec)

	local dCorrection = 0.5+DblCalcDev;
	local iSign = 1;
	if dNum < 0 then
		iSign = -1;
	end
	if vDec == nil or (-DblCalcDev <= vDec and vDec <= DblCalcDev) then
		return iSign*math.floor(iSign*dNum+dCorrection);
	else
		local dFactor = 10^vDec;
		return iSign*math.floor(iSign*dNum*dFactor+dCorrection)/dFactor;
	end
	
end

function RoundDblDown(dNum, vDec)

	local dCorrection = DblCalcDev;
	local iSign = 1;
	if dNum < 0 then
		iSign = -1;
	end
	if vDec == nil or (-DblCalcDev <= vDec and vDec <= DblCalcDev) then
		return iSign*math.floor(iSign*dNum+dCorrection);
	else
		local dFactor = 10^vDec;
		return iSign*math.floor(iSign*dNum*dFactor+dCorrection)/dFactor;
	end
	
end

function RoundDblUp(dNum, vDec)

	local dCorrection = 1-DblCalcDev;
	local iSign = 1;
	if dNum < 0 then
		iSign = -1;
	end
	if vDec == nil or (-DblCalcDev <= vDec and vDec <= DblCalcDev) then
		return iSign*math.floor(iSign*dNum+dCorrection);
	else
		local dFactor = 10^vDec;
		return iSign*math.floor(iSign*dNum*dFactor+dCorrection)/dFactor;
	end
	
end

function RoundDblLotro(dNum)

	local dCorrection = 1-DblCalcDev;
	local iSign = 1;
	if dNum < 0 then
		iSign = -1;
	end

	local iNumCeiled = math.floor(iSign*dNum+dCorrection);
	if iNumCeiled <= 1000 then
		return iSign*iNumCeiled;
	end

	local iFactor = 1;
	local iTestNum = math.floor(iNumCeiled/1000);
	while iTestNum > 0 do
		iTestNum = math.floor(iTestNum/10);
		iFactor = iFactor*10;
	end

	return iSign*math.floor(iNumCeiled/iFactor+dCorrection)*iFactor;

end

function RoundDblProg(dNum)

	local dCorrection = 0.5+DblCalcDev;
	local iSign = 1;
	if dNum < 0 then
		iSign = -1;
	end
	
	local dTestNum = dNum/(0.5*(iSign*63));
	local dDec = -math.floor(math.log10(dTestNum));

	if -DblCalcDev <= dDec and dDec <= DblCalcDev then
		return iSign*math.floor(iSign*dNum+dCorrection);
	else
		local dFactor = 10^dDec;
		return iSign*math.floor(iSign*dNum*dFactor+dCorrection)/dFactor;
	end

end

-- ******************************* End CalcStat *******************************