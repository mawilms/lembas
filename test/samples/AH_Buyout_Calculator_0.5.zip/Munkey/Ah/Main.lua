import "Turbine"

AhCmd = Turbine.ShellCommand();

function AhCmd:Execute(cmd, args)
	val1, opr, val2 = args:match("^([%-%(%s]*[%d%.,%)]+%s*)([^%w%s.,])([%-%(%s]*[%d%.,%)]+.*)$"); --TODO: find a better way to do this
	if (val1 ~= nil and val2 ~= nil and opr ~= nil) then -- Checks if it's an expression
		AhCmd:AhCal(val1 .. opr .. val2); -- Evaluate expression
	else
		args = split(args, " "); -- Splits the argument string at the space
		if (args[1] and args[2] ~= nil) then -- Checks if split produced two values
			-- Compares string length then orders the arguments sent to function
			if (string.len(math.floor(args[1])) == string.len(math.floor(args[2]))) then
				if (args[1] < args[2]) then
					arg1 = args[2];
					arg2 = args[1];
				elseif (args[1] >= args[2]) then
					arg1 = args[1];
					arg2 = args[2];
				end
			elseif (string.len(math.floor(args[1])) < string.len(math.floor(args[2]))) then
				arg1 = args[2];
				arg2 = args[1];
			elseif (string.len(math.floor(args[1])) > string.len(math.floor(args[2]))) then
				arg1 = args[1];
				arg2 = args[2];
			end
		else
			arg1 = args[1];
			arg2 = args[2];
		end
		if (type(tonumber(arg1)) == "number"  and  arg2 == nil) then -- Checks arg1 type and if arg2 is nil
			AhCmd:AucPri(arg1);
		elseif (type(tonumber(arg1)) == "number" and type(tonumber(arg2)) == "number") then -- Checks arg1 and 2 types
			AhCmd:AucPri(arg1, arg2);
		else -- Couldn't make sense of the input
			AhCmd:GetHelp();
		end
	end
end

function AhCmd:AucPri(buyout, bid)
	buyout_c = math.floor((buyout/0.95)*(10^2))/(10^2);
	if (bid == nil) then
		Turbine.Shell.WriteLine( "<rgb=#00FF00>Set Buyout to</rgb> <rgb=#FFFF00>" .. buyout_c .. "s</rgb> <rgb=#00FF00>to get</rgb> <rgb=#80FF00>" .. buyout .. "s</rgb>" );
	else
		Turbine.Shell.WriteLine( "<rgb=#00FF00>Set Starting Bid to</rgb> <rgb=#FFBF00>" .. math.floor((bid/0.95)*(10^2))/(10^2) .. "s</rgb><rgb=#00FF00> and Buyout to</rgb> <rgb=#FFFF00>" .. buyout_c .. "s</rgb> <rgb=#00FF00>to get between</rgb> <rgb=#80FF00>" .. bid .. "s</rgb> <rgb=#00FF00>and</rgb> <rgb=#80FF00>" .. buyout .. "s</rgb>" );
	end
end

function AhCmd:GetHelp()
	Turbine.Shell.WriteLine( "Syntax: /ah <price>" );
	Turbine.Shell.WriteLine( "Calc Syntax: /ah <expression>" );
end
function AhCmd:GetShortHelp()
	return "AH Buyout Calculator"
end

function AhCmd:AhCal(expr)
	eval = loadstring("return " .. expr)();
	if (eval ~= nil) then
		Turbine.Shell.WriteLine("<rgb=#00FF00>" .. expr .. "</rgb> <rgb=#FFBF00>=</rgb> <rgb=#80FF00>" .. eval .. "</rgb>");
	else
		AhCmd:GetHelp();
	end
end

function split(pString, pPattern)
	local Table = {} -- NOTE: use {n = 0} in Lua-5.0
	local fpat = "(.-)" .. pPattern
	local last_end = 1
	local s, e, cap = pString:find(fpat, 1)
	while s do
		if s ~= 1 or cap ~= "" then
			table.insert(Table,cap)
		end
		last_end = e+1
		s, e, cap = pString:find(fpat, last_end)
	end
	if last_end <= #pString then
		cap = pString:sub(last_end)
		table.insert(Table, cap)
	end
	return Table
end

Turbine.Shell.AddCommand( "ah", AhCmd );