-- Utils constants

-- cool down categories
CoolDownCategory = {};
CoolDownCategory.Morale = "morale";
CoolDownCategory.Power = "power";
CoolDownCategory.Disease = "disease";
CoolDownCategory.Fear = "fear";
CoolDownCategory.Poison = "poison";
CoolDownCategory.Wound = "wound";
