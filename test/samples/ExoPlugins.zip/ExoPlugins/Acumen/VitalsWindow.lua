VitalsWindow = class( Turbine.UI.Window );
function VitalsWindow:Constructor()
	Turbine.UI.Window.Constructor( self );	
	local screenWidth, screenHeight = Turbine.UI.Display:GetSize();
	self:SetPosition(Settings.Player.Position.X*screenWidth, Settings.Player.Position.Y*screenHeight);

	-- Time to calculate the size, this will get confusing
	local moraleX = Settings.Player.Vitals.Morale.Size.X + Settings.Player.Vitals.Morale.Position.X;
	local powerX = Settings.Player.Vitals.Power.Size.X + Settings.Player.Vitals.Power.Position.X;

	local moraleY = Settings.Player.Vitals.Morale.Size.Y + Settings.Player.Vitals.Morale.Position.Y;
	local powerY = Settings.Player.Vitals.Power.Size.Y + Settings.Player.Vitals.Power.Position.Y;

	self:SetSize( math.max(moraleX, powerX), math.max(moraleY, powerY)+Settings.Player.Effects.Size.Y*2 );

	-- Grab the player for use with callbacks
	self.player = Turbine.Gameplay.LocalPlayer.GetInstance();
	self.playerCallbacks = {};
	self.classCallbacks = {};

	self.WhiteList = Settings["Effects"]["Buffs"];

	self.DebuffList = Settings["Effects"]["Debuffs"];

	self:ConfigureVisuals();
	self:ConfigureCallbacks();

	self.dragbar = DragBar( self, "Acumen Vitals" );
end

function VitalsWindow:ConfigureVisuals()
	local class = GetClass(self.player);

	--Border for the morale bar
	self.moraleBorder = Turbine.UI.Control();
	self.moraleBorder:SetParent(self);
	self.moraleBorder:SetBackColor(Turbine.UI.Color.Black);
	self.moraleBorder:SetPosition(Settings.Player.Vitals.Morale.Position.X, Settings.Player.Vitals.Morale.Position.Y);
	self.moraleBorder:SetSize(Settings.Player.Vitals.Morale.Size.X, Settings.Player.Vitals.Morale.Size.Y);

	self.Name = TextDisplay();
	self.Name:SetParent(self.moraleBorder);
	self.Name:SetSize(self.moraleBorder:GetSize());
	local nameFormat = Settings.Player.Vitals.Text.Format;
	nameFormat = string.gsub(nameFormat, "%%n", self.player:GetName());
	nameFormat = string.gsub(nameFormat, "%%l", self.player:GetLevel());

	self.Name:SetText(nameFormat);
	self.Name:SetForeColor(TableToColor(Settings.Player.Vitals.Text.Color));
	self.Name:SetTextScale(Settings.Player.Vitals.Text.Scale);
	self.Name:SetZOrder(103)
	self.Name:SetOffset(Settings.Player.Vitals.Text.Offset.X, Settings.Player.Vitals.Text.Offset.Y)

	-- Construct the morale bar.
	self.moraleBar = VitalsBar(self.moraleBorder, self.moraleBorder:GetWidth()-2, self.moraleBorder:GetHeight()-2, true);
	self.moraleBar:SetParent( self.moraleBorder );
	self.moraleBar:SetZOrder( 100 );
	local moraleColor, bubbleColor, dreadColor = Turbine.UI.Color( 1, 0.1, 1, 0.1 ),Turbine.UI.Color(0.86,0.3,1),Turbine.UI.Color( 1, 1.0, 0.4, 0 );
	if Settings.Player.Vitals.Morale.Display == "Custom" then
		moraleColor = TableToColor(Settings.Player.Vitals.Morale.Color);
	else
		moraleColor = GetClassColour(class);
	end

	if Settings.Player.Vitals.Morale.BubbleDisplay == "Custom" then
		bubbleColor = TableToColor(Settings.Player.Vitals.Morale.Color);
	end

	if Settings.Player.Vitals.Morale.DreadDisplay == "Custom" then
		dreadColor = TableToColor(Settings.Player.Vitals.Morale.Color);
	end

	self.moraleBar:SetColors( moraleColor, bubbleColor, dreadColor );
	self.moraleBar:SetPosition( 1, 1 );
	self.moraleBar:SetMouseVisible( false );
	self.moraleBar:SetStretchMode(1);

	if Settings.Player.Vitals.Morale.BubbleText.Enabled then
		self.moraleBar:ConfigureBubbleText(
			Settings.Player.Vitals.Morale.BubbleText.Anchor, 
			Settings.Player.Vitals.Morale.BubbleText.Offset,
			Settings.Player.Vitals.Morale.BubbleText.Color,
			Settings.Player.Vitals.Morale.BubbleText.Scale
		);
	end

	self.moraleBar:ConfigureTextDisplay(
		Settings.Player.Vitals.Morale.Text.Anchor,
		Settings.Player.Vitals.Morale.Text.Offset,
		Settings.Player.Vitals.Morale.Text.Color,
		Settings.Player.Vitals.Morale.Text.Scale,
		Settings.Player.Vitals.Morale.Text.Format);

	--Border for the power bar
	self.powerBorder = Turbine.UI.Control();
	self.powerBorder:SetParent(self);
	self.powerBorder:SetBackColor(Turbine.UI.Color.Black);
	self.powerBorder:SetPosition(Settings.Player.Vitals.Power.Position.X, Settings.Player.Vitals.Power.Position.Y);
	self.powerBorder:SetSize(Settings.Player.Vitals.Power.Size.X, Settings.Player.Vitals.Power.Size.Y);
	
	-- Construct the power bar.
	self.powerBar = VitalsBar(self, self.powerBorder:GetWidth()-2, self.powerBorder:GetHeight()-2);
	self.powerBar:SetParent( self.powerBorder );
	self.powerBar:SetZOrder( 100 );
	if Settings.Player.Vitals.Power.Display == "Custom" then
		self.powerBar:SetColors( TableToColor(Settings.Player.Vitals.Power.Color), Turbine.UI.Color(0.86,0.3,1), Turbine.UI.Color( 1, 1.0, 0.4, 0 ));
	elseif class == "Beorning" then
		self.powerBar:SetColors( Turbine.UI.Color( 1, 1.0, 0.4, 0 ), Turbine.UI.Color(0.86,0.3,1), Turbine.UI.Color( 1, 1.0, 0.4, 0 ));
	else
		self.powerBar:SetColors( Turbine.UI.Color( 1, 0, 0.82, 1 ), Turbine.UI.Color(0.86,0.3,1), Turbine.UI.Color( 1, 1.0, 0.4, 0 ));
	end
	self.powerBar:SetPosition( 1, 1 );
	self.powerBar:SetMouseVisible( false );
	self.powerBar:SetStretchMode(1);

	--Set the entity control to match the player
	self.E = Turbine.UI.Lotro.EntityControl();
    self.E:SetParent(self);
    self.E:SetVisible(true);
    self.E:SetSize(self.moraleBorder:GetWidth(), self.powerBorder:GetTop()+self.powerBorder:GetHeight());
	self.E:SetPosition(Settings.Player.Vitals.Morale.Position.X, Settings.Player.Vitals.Morale.Position.Y)
    self.E:SetEntity(self.player);
	self.E:SetZOrder(105);

	-- Construct the effects lists
	self.buffsEffectsList = Turbine.UI.ListBox();
	self.buffsEffectsList:SetParent( self );
	self.buffsEffectsList:SetPosition( 0, 0 );
	self.buffsEffectsList:SetSize( Settings.Player.Vitals.Morale.Size.X, Settings.Player.Effects.Size.Y );
	self.buffsEffectsList:SetOrientation( Turbine.UI.Orientation.Horizontal );
	self.buffsEffectsList:SetMaxItemsPerLine( Settings.Player.Vitals.Morale.Size.X/Settings.Player.Effects.Size.Y );
	self.buffsEffectsList:SetMouseVisible( true );
	self.buffsEffectsList:SetZOrder(103);
	self.buffsEffectsList:SetReverseFill(true);

	self.debuffsEffectsList = Turbine.UI.ListBox();
	self.debuffsEffectsList:SetParent( self );
	self.debuffsEffectsList:SetPosition( 0, self.powerBorder:GetHeight()+self.powerBorder:GetTop()+4)
	self.debuffsEffectsList:SetSize( Settings.Player.Vitals.Morale.Size.X, Settings.Player.Effects.Size.Y*1.4 );
	self.debuffsEffectsList:SetOrientation( Turbine.UI.Orientation.Horizontal );
	self.debuffsEffectsList:SetMaxItemsPerLine( Settings.Player.Vitals.Morale.Size.X/Settings.Player.Effects.Size.Y );
	self.debuffsEffectsList:SetMouseVisible( true );
	self.debuffsEffectsList:SetZOrder(103);

	local effects = self.player:GetEffects();

	local i;
	for i = 1, effects:GetCount() do
		self:AddEffect( i );
	end
end

function VitalsWindow:ConfigureCallbacks()
	-- Set callbacks
    self.playerCallbacks["MoraleChanged"] = AddCallback(self.player, "MoraleChanged", function(sender, args) self:UpdateMorale() end);
    self.playerCallbacks["MaxMoraleChanged"] = AddCallback(self.player, "MaxMoraleChanged", function(sender, args) self:UpdateMorale() end);
    self.playerCallbacks["BaseMaxMoraleChanged"] = AddCallback(self.player, "BaseMaxMoraleChanged", function(sender, args) self:UpdateMorale() end);
    self.playerCallbacks["TemporaryMoraleChanged"] = AddCallback(self.player, "TemporaryMoraleChanged", function(sender, args) self:UpdateMorale() end);

	self:UpdateMorale();
	local class = GetClass(self.player);
	if class == "Beorning" then
		self:UpdateWrath();
		self.classCallbacks["WrathChanged"] = AddCallback(self.player:GetClassAttributes(), "WrathChanged", function(sender, args) self:UpdateWrath() end);
	else
		self.playerCallbacks["PowerChanged"] = AddCallback(self.player, "PowerChanged", function(sender, args) self:UpdatePower() end);
    	self.playerCallbacks["MaxPowerChanged"] = AddCallback(self.player, "MaxPowerChanged", function(sender, args) self:UpdatePower() end);
    	self.playerCallbacks["BaseMaxPowerChanged"] = AddCallback(self.player, "BaseMaxPowerChanged", function(sender, args) self:UpdatePower() end);
		self:UpdatePower();
	end

	--Configure morale text display
	self.moraleBar:SetTextVisible(true);

	self.EffectsCallbacks = {};
	self.EffectsCallbacks["EffectAdded"] = AddCallback(self.player:GetEffects(), "EffectAdded", function(sender, args) self:AddEffect(args.Index) end);
	self.EffectsCallbacks["EffectRemoved"] = AddCallback(self.player:GetEffects(), "EffectRemoved", function(sender, args) self:RemoveEffect(args.Effect) end);
end

function VitalsWindow:UpdateMorale()
	local morale        = self.player:GetMorale();
	local maxMorale     = self.player:GetMaxMorale();
	local baseMaxMorale = self.player:GetBaseMaxMorale();
	local tempMorale    = self.player:GetTemporaryMorale();

	self.moraleBar:SetValue( morale );
	self.moraleBar:SetMax( maxMorale );
	self.moraleBar:SetBaseMax( baseMaxMorale );
	self.moraleBar:SetTempValue( tempMorale );
end

function VitalsWindow:UpdatePower()
	local power = self.player:GetPower()
	self.powerBar:SetValue( power );

	local maxPower = self.player:GetMaxPower()
	self.powerBar:SetMax( maxPower );

	local baseMaxPower = self.player:GetBaseMaxPower()
	self.powerBar:SetBaseMax( baseMaxPower );
end

function VitalsWindow:UpdateWrath()
	local wrath = self.player:GetClassAttributes():GetWrath();
	self.powerBar:SetValue( wrath );

	self.powerBar:SetMax( 100 );
	self.powerBar:SetBaseMax( 100 );
end

function VitalsWindow:AddEffect( effectIndex )
	local effect = self.player:GetEffects():Get( effectIndex );

	local effectDisplay = EffectDisplay()
	effectDisplay:SetEffect( effect );

	local insertionList = nil;
	local effectEndTime = effect:GetStartTime() + effect:GetDuration();

	if ( effectDisplay:GetEffect():IsDebuff() ) then
		if (self.DebuffList[effect:GetName()] == nil) then
			insertionList = self.debuffsEffectsList;
		end
	elseif self.WhiteList[effect:GetName()] then
		insertionList = self.buffsEffectsList;
	end

	local i = 0;
	local insertAt = -1;

	if insertionList ~= nil then
		for i = 1, insertionList:GetItemCount() do
			local testEffect = insertionList:GetItem( i ):GetEffect();
			local testEffectEndTime = testEffect:GetStartTime() + testEffect:GetDuration();

			if ( effectEndTime < testEffectEndTime ) then
				insertAt = i;
				break;
			end
		end

		if ( insertAt == -1 ) then
			insertionList:AddItem( effectDisplay );
		else
			insertionList:InsertItem( insertAt, effectDisplay );
		end
	end
end

function VitalsWindow:RemoveEffect( effect )
	local i;

	if ( effect:IsDebuff() ) then
		for i = 1, self.debuffsEffectsList:GetItemCount() do
			local effectListItem = self.debuffsEffectsList:GetItem( i ):GetEffect();

			if ( effect == effectListItem ) then
				local effectElement = self.debuffsEffectsList:GetItem( i );
				effectElement:SetVisible( false );
				effectElement:Unload();
				self.debuffsEffectsList:RemoveItemAt( i );
				break;
			end
		end
	else
		for i = 1, self.buffsEffectsList:GetItemCount() do
			local effectListItem = self.buffsEffectsList:GetItem( i ):GetEffect();

			if ( effect == effectListItem ) then
				local effectElement = self.buffsEffectsList:GetItem( i );
				effectElement:SetVisible( false );
				effectElement:Unload();
				self.buffsEffectsList:RemoveItemAt( i );
				break;
			end
		end
	end
end

function VitalsWindow:RemoveCallbacks()
	for key, value in pairs(self.playerCallbacks) do
        RemoveCallback(self.player, key, value);
        self.playerCallbacks[key] = nil;
    end
	if GetClass(self.player) == "Beorning" then
		RemoveCallback(self.player:GetClassAttributes(), "WrathChanged", self.classCallbacks["WrathChanged"]);
	end

	if self.CombatCallback ~= nil then
		RemoveCallback(self.player, "InCombatChanged", self.CombatCallback);
	end

	self.playerCallbacks = {};
	self.classCallbacks = {};
	self.CombatCallback = nil;
end

function VitalsWindow:SavePosition()
	local screenWidth, screenHeight = Turbine.UI.Display:GetSize();
	Data = {
		X = self:GetLeft()/screenWidth,
		Y = self:GetTop()/screenHeight,
	};
	Settings.Player.Position = Data;
end

function VitalsWindow:Unload()
	self:RemoveCallbacks();
	self.moraleBar:Unload();
	self.powerBar:Unload();
	self.moraleBar = nil;
	self.powerBar = nil;
	if self.class ~= nil then
		self.class:Unload();
	end
    self.E:SetEntity(nil);
	self.E = nil;
	self:SetStretchMode(0);
end

function VitalsWindow:Reload()
	self:Unload();
	self:ConfigureVisuals();
	self:ConfigureCallbacks();
end