------------------------------------------------------------------------------------------
-- localization file
-- Written by Homeopatix
-- 7 january 2021
------------------------------------------------------------------------------------------
function CreateLocalizationInfo()
	Strings = {
		Teleport = {}
	};

		------------------------------------------------------------------------------------------
		-- English --
		------------------------------------------------------------------------------------------
		Strings.PluginName = "Voyage";
		Strings.PluginText = "By Homeopatix";
		Strings.PluginEscEnable = "Escape key Activated";
		Strings.PluginEscDesable = "Escape key Desactivated";
		Strings.PluginOptionsText = "Options Voyage";
		Strings.PluginTitreHelpWindow = "Help for Voyage";
		Strings.PluginHouseText = "House location";
		------------------------------------------------------------------------------------------
		-- help --
		------------------------------------------------------------------------------------------
		Strings.PluginHelp1 = "\n\nList of all commands:\n";
		Strings.PluginHelp2 = "/Voy help - Show the help window.\n";
		Strings.PluginHelp3 = "/Voy show - Show the window.\n";
		Strings.PluginHelp4 = "/Voy hide - Hide the window.\n";
		Strings.PluginHelp5 = "/Voy default - Reset shortcuts.\n";
		Strings.PluginHelp6 = "/Voy lock to lock or unlock the icons\n";
		Strings.PluginHelp7 = "/Voy options - Display the options window.\n";
		Strings.PluginHelp8 = "/Voy clear - Delete all shortcuts.\n";
		Strings.PluginHelp9 = "/Voy clearteleport - Delete all the milestones location.\n";
		Strings.PluginHelp10 = "/Voy clearhouse - Delete all the houses locations.\n\n";
		Strings.PluginHelp11 = "Right click the icon to show the options panel\n\n";
		Strings.PluginHelp12 = "Display default reputation shortcuts, you can disable the checkBox\n";
		Strings.PluginHelp13 = "< Show reputation trip > to turn them off\n\n";
		Strings.PluginHelp14 = "You can change the location of the shortcuts or add more by dragging and dropping and click on\n";
		Strings.PluginHelp15 = "< Keep shortcuts > to disable automatic generation\n";
		Strings.PluginHelp16 = "of shortcuts and keep your changes\n\n";
		Strings.PluginHelp17 = "You can define the location of your different houses by clicking on the icon of the little house\n";
		Strings.PluginHelp18 = "on the right of the text\n\n";
		Strings.PluginHelp19 = "You can define the location of your milestones by clicking on the icon\n\n";
		Strings.PluginHelp20 = "You can delete a shortcut with the mouse wheel\n\n";
		Strings.PluginHelp21 = "You can right click on a shortcut to display the map of the destination ";
		Strings.PluginHelp22 = "and right click on the same shortcut to close it\n\n";
		------------------------------------------------------------------------------------------
		-- map window --
		------------------------------------------------------------------------------------------
		Strings.PluginMap1 = "Close the window";
		Strings.PluginMap2 = "Undefined";
		------------------------------------------------------------------------------------------
		-- house location  --
		------------------------------------------------------------------------------------------
		Strings.PluginHousePersonal = "Personal house location";
		Strings.PluginHouseConfrerie = "Kingship house location";
		Strings.PluginHouseConfrerieFriend = "Kingship Member's house location";
		Strings.PluginHousePremium = "Premium house location";
		Strings.PluginHouse1 = " Bree-Land";
		Strings.PluginHouse2 = " Falathlorn";
		Strings.PluginHouse3 = " Thorin's hall";
		Strings.PluginHouse4 = " The Shire";
		Strings.PluginHouse5 = " Eastfold hills";
		Strings.PluginHouse6 = " Kingstead meaddows";
		Strings.PluginHouse7 = " Cape of Belfalas";
		Strings.PluginHouseAlert = "Personal house not defined in the options";
		Strings.PluginTeleportAlert = "Milestone not defined in options";
		------------------------------------------------------------------------------------------
		-- command text  --
		------------------------------------------------------------------------------------------
		Strings.PluginWindowShow = "Show the window.";
		Strings.PluginWindowHide = "Hide the window.";
		Strings.PluginWindowDefault = "Reset to default settings.";
		Strings.PluginWindowClear = "Delete all shortcuts.";
		Strings.PluginWindowClearTeleport = "Delete all the milestones location.";
		Strings.PluginWindowClearHouse = "Delete all the houses locations.";
		Strings.PluginLocked = "Icons Locked";
		Strings.PluginUnlocked = "Icons Unlocked";
		------------------------------------------------------------------------------------------
		-- option window --
		------------------------------------------------------------------------------------------
		Strings.PluginOption1 = "Number of lines";
		Strings.PluginOption2 = "Number of slots per line";
		Strings.PluginOption3 = "Number of Return to a linked cue point";
		Strings.PluginOption4 = "Return to home...";
		Strings.PluginOption5 = " Personal House";
		Strings.PluginOption6 = " Kinship House";
		Strings.PluginOption7 = " Premium House";
		Strings.PluginOption8 = "Show reputation trip";
		Strings.PluginOption9 = " Yes";
		Strings.PluginOption10 = "Validate Changes";
		Strings.PluginOption11 = "Kinship Member's House";
		Strings.PluginOption12 = " Keep your changes";
		Strings.PluginOptionAlert = "!!! REINITIALIZE ALL SHORTCUTS !!!";
		Strings.PluginOptionShowWindow = "Display the options Window";
		------------------------------------------------------------------------------------------
		-- label text  --
		------------------------------------------------------------------------------------------
		Strings.PluginLabel1 = "Personal house location";
		Strings.PluginLabel2 = "Kinship house location";
		Strings.PluginLabel3 = "Kinship's friend house location";
		Strings.PluginLabel4 = "Premium house location";
		Strings.PluginLabel5 = "Show the Help";
		Strings.PluginButtonHelpWindow = "Close Help";
		------------------------------------------------------------------------------------------
		-- TELEPORT LOCATIONS --
		------------------------------------------------------------------------------------------
		Strings.PluginDefinTeleport = "Define Milestone";
		------------------------------------------------------------------------------------------
		-- Teleport Location  REGION --
		------------------------------------------------------------------------------------------
		Strings.TeleportRegion1 = "Eregion";
		Strings.TeleportRegion2 = "Rhovanion";
		Strings.TeleportRegion3 = "Gondor";
		Strings.TeleportRegion4 = "Mordor";
		------------------------------------------------------------------------------------------
		-- Teleport sous Location  Eregion --
		------------------------------------------------------------------------------------------
		Strings.TeleportSousRegion1 = "Angmar";
		Strings.TeleportSousRegion2 = "Bree-land";
		Strings.TeleportSousRegion3 = "Enedwaith ";
		Strings.TeleportSousRegion4 = "Ered Luin";
		Strings.TeleportSousRegion5 = "Eregion";
		Strings.TeleportSousRegion6 = "Evendim";
		Strings.TeleportSousRegion7 = "Forochel";
		Strings.TeleportSousRegion8 = "The Lone-lands";
		Strings.TeleportSousRegion9 = "The Misty Mountains";
		Strings.TeleportSousRegion10 = "The North Downs";
		Strings.TeleportSousRegion11 = "The Shire";
		Strings.TeleportSousRegion12 = "The Trollshaws";
		------------------------------------------------------------------------------------------
		-- Teleport sous Location Rhovanion --
		------------------------------------------------------------------------------------------
		Strings.TeleportSousRegion13 = "Lothl\195\179rien";
		Strings.TeleportSousRegion14 = "Mirkwood";
		Strings.TeleportSousRegion15 = "Moria";
		Strings.TeleportSousRegion16 = "Trum Dreng";
		Strings.TeleportSousRegion17 = "Bonevales";
		Strings.TeleportSousRegion18 = "Pren Gwydh";
		Strings.TeleportSousRegion19 = "T\195\162l Methedras";
		Strings.TeleportSousRegion20 = "Starkmoor";
		Strings.TeleportSousRegion21 = "Gravenwood";
		Strings.TeleportSousRegion22 = "Dunbog";
		Strings.TeleportSousRegion23 = "Carreglyn";
		Strings.TeleportSousRegion24 = "Heathfells";
		Strings.TeleportSousRegion25 = "Nan Curun\195\173r";
		Strings.TeleportSousRegion26 = "Isengard";
		Strings.TeleportSousRegion27 = "Nan Curun\195\173r";
		Strings.TeleportSousRegion28 = "Brown Lands";
		Strings.TeleportSousRegion29 = "Eorlsmead";
		Strings.TeleportSousRegion30 = "Eorlsmead";
		Strings.TeleportSousRegion31 = "Parth Celebrant";
		Strings.TeleportSousRegion32 = "The Rushgore";
		Strings.TeleportSousRegion33 = "Thinglad";
		Strings.TeleportSousRegion34 = "Entwash Vale";
		Strings.TeleportSousRegion35 = "Norcrofts";
		Strings.TeleportSousRegion36 = "Sutcrofts";
		Strings.TeleportSousRegion37 = "The East Wall";
		Strings.TeleportSousRegion38 = "The Wold";
		Strings.TeleportSousRegion39 = "Kingstead";
		Strings.TeleportSousRegion40 = "Eastfold";
		Strings.TeleportSousRegion41 = "Broadacres";
		Strings.TeleportSousRegion42 = "Stonedeans";
		Strings.TeleportSousRegion43 = "Westfold";
		Strings.TeleportSousRegion44 = "Helm's Deep";
		------------------------------------------------------------------------------------------
		-- Teleport sous Location Gondor --
		------------------------------------------------------------------------------------------
		Strings.TeleportSousRegion45 = "Blackroot Vale";
		Strings.TeleportSousRegion46 = "Lamedon";
		Strings.TeleportSousRegion47 = "Havens of Belfalas";
		Strings.TeleportSousRegion48 = "Ringl\195\179 Vale";
		Strings.TeleportSousRegion49 = "Dor-en-Ernil";
		Strings.TeleportSousRegion50 = "Lower Lebennin";
		Strings.TeleportSousRegion51 = "Upper Lebennin";
		Strings.TeleportSousRegion52 = "Lossarnach";
		Strings.TeleportSousRegion53 = "South Ithilien";
		------------------------------------------------------------------------------------------
		-- Teleport sous Location Mordor --
		------------------------------------------------------------------------------------------
		Strings.TeleportSousRegion54 = "Torech Ungol";
		Strings.TeleportSousRegion55 = "Minas Morgul";
		Strings.TeleportSousRegion56 = "Gorgoroth";
		Strings.TeleportSousRegion57 = "Lhingris";
		Strings.TeleportSousRegion58 = "Agarnaith";
		Strings.TeleportSousRegion59 = "Talath \195\186rui";
		Strings.TeleportSousRegion60 = "The Morgul vale";

		------------------------------------------------------------------------------------------
		-- Teleport Location Angmar --
		------------------------------------------------------------------------------------------
		Strings.Teleport[1] = " Aughaire";
		Strings.Teleport[2] = " Gath Forthn\195\173r";
		Strings.Teleport[3] = " Imlad Balchorth";
		Strings.Teleport[4] = " T\195\161rmunn S\195\186rsa";
		Strings.Teleport[5] = " Gabilshath\195\187r";
		------------------------------------------------------------------------------------------
		-- Teleport Location Bree-land --
		------------------------------------------------------------------------------------------
		Strings.Teleport[6] = " Archet";
		Strings.Teleport[7] = " Bree - South Gate";
		Strings.Teleport[8] = " Bree - The Prancing Pony";
		Strings.Teleport[9] = " Bree - West Gate";
		Strings.Teleport[10] = " Bree-land Homesteads";
		Strings.Teleport[11] = " Buckland";
		Strings.Teleport[12] = " Combe";
		------------------------------------------------------------------------------------------
		-- Teleport Location Enedwaith  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[13] = " Echad Dagoras";
		Strings.Teleport[14] = " Lhanuch";
		Strings.Teleport[15] = " Harndirion";
		Strings.Teleport[16] = " Maur Tulhau";
		Strings.Teleport[17] = " N\195\161r's Peak";
		Strings.Teleport[18] = " Lich Bluffs";
		Strings.Teleport[19] = " Mournshaws";
		------------------------------------------------------------------------------------------
		-- Teleport Location Ered Luin  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[20] = " Celondim";
		Strings.Teleport[21] = " Duillond";
		Strings.Teleport[22] = " Gondamon";
		Strings.Teleport[23] = " Falathlorn Homesteads";
		Strings.Teleport[24] = " Thorin's Hall";
		Strings.Teleport[25] = " Thorin's Hall Homesteads";
		------------------------------------------------------------------------------------------
		-- Teleport Location Eregion  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[26] = " Gwingris";
		Strings.Teleport[27] = " Echad Eregion";
		Strings.Teleport[28] = " Echad Dunann";
		Strings.Teleport[29] = " Echad Mirobel";
		------------------------------------------------------------------------------------------
		-- Teleport Location Evendim  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[30] = " Tinnudir";
		Strings.Teleport[31] = " Ann\195\186minas";
		Strings.Teleport[32] = " The Eavespires";
		Strings.Teleport[33] = " Ost Forod";
		Strings.Teleport[34] = " High King's Crossing";
		Strings.Teleport[35] = " Oatbarton";
		Strings.Teleport[36] = " Dwaling";
		------------------------------------------------------------------------------------------
		-- Teleport Location Forochel  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[37] = " Kauppa-kohta";
		Strings.Teleport[38] = " Pynti-peldot";
		Strings.Teleport[39] = " Zigilgund";
		Strings.Teleport[40] = " Kuru-leiri";
		Strings.Teleport[41] = " S\195\187ri-kyl\195\164";
		------------------------------------------------------------------------------------------
		-- Teleport Location The Lone-lands  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[42] = " Ost Guruth";
		Strings.Teleport[43] = " The Forsaken Inn";

		------------------------------------------------------------------------------------------
		-- Teleport Location The misty moutains  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[44] = " Gl\195\179in's Camp";
		Strings.Teleport[45] = " Vindurhal";
		------------------------------------------------------------------------------------------
		-- Teleport Location The north Downs  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[46] = " Esteld\195\173n";
		Strings.Teleport[47] = " Trestlebridge";
		------------------------------------------------------------------------------------------
		-- Teleport Location The shire  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[48] = " Brockenborings";
		Strings.Teleport[49] = " Budgeford";
		Strings.Teleport[50] = " Hobbiton";
		Strings.Teleport[51] = " Little Delving";
		Strings.Teleport[52] = " Michel Delving";
		Strings.Teleport[53] = " Shire Homesteads";
		------------------------------------------------------------------------------------------
		-- Teleport Location The trollshaws  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[54] = " Echad Candelleth";
		Strings.Teleport[55] = " Rivendell";
		Strings.Teleport[56] = " Thorenhad";
		------------------------------------------------------------------------------------------
		-- Teleport Region Rhovanion  --
		------------------------------------------------------------------------------------------
		------------------------------------------------------------------------------------------
		-- Teleport Location Lothorien  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[57] = " Caras Galadhon";
		Strings.Teleport[58] = " Mekhem-bizru";
		Strings.Teleport[59] = " Echad Andestel";
		Strings.Teleport[60] = " Imlad Lalaith";
		------------------------------------------------------------------------------------------
		-- Teleport Location Mirkwood  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[61] = " Mirk-eaves";
		Strings.Teleport[62] = " The Haunted Inn";
		Strings.Teleport[63] = " Ost Galadh";
		Strings.Teleport[64] = " Estolad Mernael";
		Strings.Teleport[65] = " Mithechad";
		Strings.Teleport[66] = " Thang\195\186lhad";
		------------------------------------------------------------------------------------------
		-- Teleport Location Moria  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[67] = " The great delving";
		Strings.Teleport[68] = " Dolven-view";
		Strings.Teleport[69] = " Deep Descent";
		Strings.Teleport[70] = " The Chamber of the Crossroads";
		Strings.Teleport[71] = " The Twenty-first Hall";
		Strings.Teleport[72] = " The Rotting Cellar";
		Strings.Teleport[73] = " The Water-Works";
		Strings.Teleport[74] = " Foundations of stone";
		Strings.Teleport[75] = " Redhornes lodes";
		Strings.Teleport[76] = " Jaz\195\162rgund";
		Strings.Teleport[77] = " The Fanged Pit";
		------------------------------------------------------------------------------------------
		-- Teleport Location Trum Dreng  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[78] = " Lhan Tarren";
		------------------------------------------------------------------------------------------
		-- Teleport Location Bonevales  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[79] = " Echad Naeglanc";
		------------------------------------------------------------------------------------------
		-- Teleport Location Pren Gwydh  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[80] = " Galtrev";
		------------------------------------------------------------------------------------------
		-- Teleport Location T\195\162l Methedras  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[81] = " T\195\162l Methedras Gate";
		------------------------------------------------------------------------------------------
		-- Teleport Location Starkmoor  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[82] = " Avardin";
		------------------------------------------------------------------------------------------
		-- Teleport Location Gravenwood  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[83] = " Rohirrim Scout-camp";
		------------------------------------------------------------------------------------------
		-- Teleport Location Dunbog  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[84] = " Lhan Rhos";
		------------------------------------------------------------------------------------------
		-- Teleport Location Carreglyn  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[85] = " Barnavon";
		------------------------------------------------------------------------------------------
		-- Teleport Location Heathfells  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[86] = " Forthbrond";
		Strings.Teleport[87] = " Grimbold's Camp";
		------------------------------------------------------------------------------------------
		-- Teleport Location Nan Curun\195\173r  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[88] = " Dagoras' Camp";
		------------------------------------------------------------------------------------------
		-- Teleport Location Isengard  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[89] = " Ox-clan Merchant Camp";
		------------------------------------------------------------------------------------------
		-- Teleport Location Nan Curun\195\173r  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[90] = " Isengard (after)";
		------------------------------------------------------------------------------------------
		-- Teleport Location Brown Lands  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[91] = " Etheburg";
		-----------------------------------------------------------------------------------------
		-- Teleport Location Eorlsmead  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[92] = " Stangard";
		------------------------------------------------------------------------------------------
		-- Teleport Location Eorlsmead  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[93] = " Wailing hills";
		------------------------------------------------------------------------------------------
		-- Teleport Location Parth Celebrant  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[94] = " Parth Celebrant";
		------------------------------------------------------------------------------------------
		-- Teleport Location The Rushgore  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[95] = " Aculf's Camp";
		------------------------------------------------------------------------------------------
		-- Teleport Location Thinglad  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[96] = " Haldirith";
		------------------------------------------------------------------------------------------
		-- Teleport Location Entwash Vale  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[97] = " Eaworth";
		Strings.Teleport[98] = " Thornhope";
		------------------------------------------------------------------------------------------
		-- Teleport Location Norcrofts  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[99] = " Cliving";
		Strings.Teleport[100] = " Elthengels";
		Strings.Teleport[101] = " Faldham";
		------------------------------------------------------------------------------------------
		-- Teleport Location Sutcrofts  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[102] = " Garsfeld";
		Strings.Teleport[103] = " Hytbold";
		Strings.Teleport[104] = " Snowbourn";
		Strings.Teleport[105] = " Walstow";
		------------------------------------------------------------------------------------------
		-- Teleport Location The East Wall  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[106] = " Mansig's Encampment";
		Strings.Teleport[107] = " Parth Galen";
		------------------------------------------------------------------------------------------
		-- Teleport Location The Wold  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[108] = " Harwick";
		Strings.Teleport[109] = " Floodwend";
		Strings.Teleport[110] = " Langhold";
		------------------------------------------------------------------------------------------
		-- Teleport Location Kingstead  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[111] = " Entwade";
		Strings.Teleport[112] = " Middlemead";
		Strings.Teleport[113] = " Edoras";
		Strings.Teleport[114] = " Upbourn";
		Strings.Teleport[115] = " Underharrow";
		Strings.Teleport[116] = " Dunharrow";
		------------------------------------------------------------------------------------------
		-- Teleport Location Eastfold  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[117] = " Aldburg";
		Strings.Teleport[118] = " Beaconwatch";
		Strings.Teleport[119] = " Fenmarch";
		------------------------------------------------------------------------------------------
		-- Teleport Location Eastfold  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[120] = " Oserley";
		Strings.Teleport[121] = " Stoke";
		------------------------------------------------------------------------------------------
		-- Teleport Location Stonedeans  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[122] = " Woodhurst";
		Strings.Teleport[123] = " Brockbridge";
		Strings.Teleport[124] = " Gapholt";
		------------------------------------------------------------------------------------------
		-- Teleport Location Westfold  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[125] = " Grimslade";
		Strings.Teleport[126] = " Grimslade";
		------------------------------------------------------------------------------------------
		-- Teleport Location Helm's Deep  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[127] = " Helm's Deep";
	------------------------------------------------------------------------------------------
		-- Teleport sous Location Gondor  --
		------------------------------------------------------------------------------------------
		------------------------------------------------------------------------------------------
		-- Teleport Location Blackroot Vale  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[128] = " Morlad";
		Strings.Teleport[129] = " Alagrant";
		Strings.Teleport[130] = " Sardol";
		Strings.Teleport[131] = " Lancrath";
		------------------------------------------------------------------------------------------
		-- Teleport Location Lamedon  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[132] = " D\195\173nadab";
		Strings.Teleport[133] = " Calembel";
		------------------------------------------------------------------------------------------
		-- Teleport Location Havens of Belfalas  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[134] = " Tadrent";
		Strings.Teleport[135] = " Ost Lontir";
		Strings.Teleport[136] = " Dol Amroth";
		------------------------------------------------------------------------------------------
		-- Teleport Location Ringl\195\179 Vale  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[137] = " Ethring";
		------------------------------------------------------------------------------------------
		-- Teleport Location Dor-en-Ernil  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[138] = " Linhir";
		------------------------------------------------------------------------------------------
		-- Teleport Location Lebennin  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[139] = " Ost Anglebed";
		Strings.Teleport[140] = " Pelargir";
		------------------------------------------------------------------------------------------
		-- Teleport Location Upper Lebennin  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[141] = " Glaniath";
		Strings.Teleport[142] = " Tumladen";
		------------------------------------------------------------------------------------------
		-- Teleport Location Lossarnach  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[143] = " Arnach";
		Strings.Teleport[144] = " Imloth Melui";
		------------------------------------------------------------------------------------------
		-- Teleport Location South Ithilien  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[145] = " B\195\162r H\195\186rin";
		Strings.Teleport[146] = " Faramir's Lookout";
		------------------------------------------------------------------------------------------
		-- Teleport sous Location Mordor  --
		------------------------------------------------------------------------------------------
		------------------------------------------------------------------------------------------
		-- Teleport Location torech ungol  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[147] = " Amon Amarth";
		------------------------------------------------------------------------------------------
		-- Teleport Location minas morgul  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[148] = " Minas Morgul";
		------------------------------------------------------------------------------------------
		-- Teleport Location gorgoroth  --
		------------------------------------------------------------------------------------------
		Strings.Teleport[149] = " Cirith Gorgor";
		Strings.Teleport[150] = " Isenmouthe";
		Strings.Teleport[151] = " Rath Cail";
		Strings.Teleport[152] = " Dath Nethryn";
		Strings.Teleport[153] = " Talath \195\186rui";
		Strings.Teleport[154] = " Norgroth";
end