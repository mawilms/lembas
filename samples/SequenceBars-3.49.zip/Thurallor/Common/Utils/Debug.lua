import "Turbine.UI.Lotro";

function _G.CountEvents(id)
    if (not _G.dbgwin) then
        local win = Turbine.UI.Lotro.Window();
        win:SetText("Events");
        win:SetWidth(200);
        win.y = 50;
        win.control = {};
        win:SetVisible(true);
        _G.dbgwin = win;
        function win.Closing()
            _G.dbgwin = nil;
        end
    end    
    local win = _G.dbgwin;
    
    if (not win.control[id]) then
        local control = Turbine.UI.Label();
        control:SetParent(win);
        control:SetPosition(50, win.y);
        win.y = win.y + 20;
        win:SetHeight(win.y + 30);
        control:SetSize(100, 20);
        control.count = 0;
        win.control[id] = control;
    end
    local control = win.control[id];
    
    control.count = control.count + 1;
    control:SetText(tostring(id) .. ": " .. tostring(control.count));
end
