OneTimeHelp = class(Turbine.UI.Lotro.Window);

local translations = {};
translations.Help = {};
translations.Help.DoNotShowAgain = {
    [Turbine.Language.English] = "Do not show this message again";
    [Turbine.Language.German] = "Diese Meldung nicht mehr anzeigen.";
    [Turbine.Language.French] = "Ne plus montrer ce message.";
    [Turbine.Language.Russian] = "Больше не показывать это сообщение."
};
L:AddText(translations);

OneTimeHelp.windows = {};
OneTimeHelp.settings = {};
Turbine.PluginData.Load(Turbine.DataScope.Character, "OneTimeHelp", function(loadStr)
    if (loadStr) then
        OneTimeHelp.settings = ImportTable(loadStr);
        if (not OneTimeHelp.settings) then
            Turbine.Shell.WriteLine("Failed to parse OneTimeHelp.plugindata file!");
            return;
        end
        for id, win in pairs(OneTimeHelp.windows) do
            win.checkBox:SetChecked(OneTimeHelp.settings[id]);
        end
    end
end);

function OneTimeHelp:Constructor(id)
    Turbine.UI.Lotro.Window.Constructor(self);
    self:SetVisible(true);
    self.id = id;
    
    -- Add text area
    local background = Turbine.UI.Control();
    background:SetParent(self);
    background:SetBackground(0x411348A7);
    background:SetPosition(14, 47);
    self.background = background;
    
    local label = Turbine.UI.Label();
    label:SetParent(self);
    label:SetMultiline(true);
    label:SetMarkupEnabled(true);
    label:SetSelectable(true);
    label:SetPosition(19, 52);
    self.label = label;
    
    -- Add vertical scrollbar
    local scrollBar = Turbine.UI.Lotro.ScrollBar();
    scrollBar:SetParent(self);
    scrollBar:SetOrientation(Turbine.UI.Orientation.Vertical);
    scrollBar:SetWidth(10);
    scrollBar:SetTop(47);
    self.scrollBar = scrollBar;
    label:SetVerticalScrollBar(scrollBar);

    -- Add checkbox
    local checkBox = Turbine.UI.Lotro.CheckBox();
    checkBox:SetParent(self);
    checkBox:SetFont(Turbine.UI.Lotro.Font.Verdana13);
    checkBox:SetText(" " .. L:GetText("/Help/DoNotShowAgain"));
    checkBox:SetLeft(30);
    checkBox.CheckedChanged = function()
        self:CheckedChanged();
    end
    self.checkBox = checkBox;
    
    -- Set initial size and position
    w, h = 400, 500;
    dw, dh = Turbine.UI.Display:GetSize();
    self:SetSize(w, h);
    self:SetPosition(math.floor((dw - w) / 2), math.floor((dh - h) / 2));
    self:SetResizable(true);

    -- If already open, or previously the user said they didn't want to see it any more, close immediately.
    if (OneTimeHelp.windows[id] or OneTimeHelp.settings[id]) then
        self:Close();
    end
    
    -- Ensure that the window stays open until closed by the user
    OneTimeHelp.windows[id] = self;
end

function OneTimeHelp:Closing()
    OneTimeHelp.windows[self.id] = nil;
end

function OneTimeHelp:SizeChanged()
    local width, height = self:GetSize();
    self.background:SetSize(width - 27, height - 90);
    self.label:SetSize(width - 37, height - 100);
    self.scrollBar:SetHeight(height - 90);
    self.scrollBar:SetLeft(width - 14);
    self.checkBox:SetTop(height - 50);
    self.checkBox:SetWidth(width - 27);
end

function OneTimeHelp:SetTitle(title)
    Turbine.UI.Window.SetText(self, title);
end

function OneTimeHelp:SetFont(font)
    self.label:SetFont(font);
end

function OneTimeHelp:SetText(text)
    self.label:SetText(text);
end

function OneTimeHelp:CheckedChanged()
    OneTimeHelp.settings[self.id] = self.checkBox:IsChecked();
    local saveData = ExportTable(OneTimeHelp.settings);
    Turbine.PluginData.Save(Turbine.DataScope.Character, "OneTimeHelp", saveData, function()
--Puts("Save complete.");
    end);
end

Thurallor = Thurallor or {};
Thurallor.Utils = Thurallor.Utils or {};
Thurallor.Utils.OneTimeHelp = OneTimeHelp;
