local importPath = getfenv(1)._.Name;
local commonPath = string.gsub(importPath, "%.Utils%.LibCompress$", "");

import (commonPath .. ".Utils.LibCompress.LibCompress");

Thurallor = Thurallor or {};
Thurallor.Utils = Thurallor.Utils or {};
Thurallor.Utils.LibCompress = LibCompress;
