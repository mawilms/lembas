PullDownMenu = class(Turbine.UI.Control);
-- Based on Galuhad's DropDown class.

function PullDownMenu:Constructor(items, default)
    Turbine.UI.Control.Constructor(self);

    self:SetBackColor(Turbine.UI.Color(0.63, 0.63, 0.63));

    self.interior = Turbine.UI.Control();
	self.interior:SetParent(self);
	self.interior:SetPosition(2,2);
	self.interior:SetBackColor(Turbine.UI.Color(0, 0, 0));
	self.interior:SetMouseVisible(false);

    self.selection = Turbine.UI.Label();
	self.selection:SetParent(self.interior);
	self.selection:SetForeColor(Turbine.UI.Color((229/255), (209/255), (136/255)));
	self.selection:SetTextAlignment(Turbine.UI.ContentAlignment.TopCenter);
	self.selection:SetFont(Turbine.UI.Lotro.Font.TrajanPro14);
	self.selection:SetMultiline(false);
	self.selection:SetMouseVisible(false);

    self.arrow = Turbine.UI.Control();
	self.arrow:SetParent(self.interior);
	self.arrow:SetSize(14,14);
	self.arrow:SetBackground(0x41007e18);
	self.arrow:SetBlendMode(4);
	self.arrow:SetMouseVisible(false);

    self:SetHeight(19);
    self:SetItems(items);
    self:SetSelection(default);
end

-- items should be a list of lists, each of the form { itemID, itemText, parentItemID }.
function PullDownMenu:SetItems(items)
    self.menu = nil;
    self.menuItems = {};
    if (items and (#items > 0)) then
        self.menu = Turbine.UI.ContextMenu();
        for i = 1, #items, 1 do
            local item = items[i];
            local id, text = item[1], item[2];
            local selected = (self.selectedId == id);
            local menuItem = Turbine.UI.MenuItem(text, true, selected);
            function menuItem.Click()
                self:SetSelection(id);
            end
            self.menuItems[id] = menuItem;
        end
        for i = 1, #items, 1 do
            local item = items[i];
            local id, parentID = item[1], item[3];
            local parentObject = self.menu;
            if (parentID) then
                parentObject = self.menuItems[parentID];
            end
            parentObject:GetItems():Add(self.menuItems[id]);
        end
    end
end

function PullDownMenu:SetSelection(id)
    if (self.selectedID) then
        local menuItem = self.menuItems[self.selectedID];
        if (menuItem) then
            menuItem:SetChecked(false);
            menuItem:SetEnabled(true);
        end
    end
    local text = nil;
    if (id) then
        local menuItem = self.menuItems[id];
        if (menuItem) then
            text = menuItem:GetText();
            menuItem:SetChecked(true);
            menuItem:SetEnabled(false);
        end
    end
    self.selection:SetText(text);
    if ((self.selectedID ~= id) and self.SelectionChanged) then
        self:SelectionChanged(id);
    end
    self.selectedID = id;
end

function PullDownMenu:GetSelection()
    return self.selectedID;
end

function PullDownMenu:MouseEnter()
    if (self:IsEnabled()) then
        self.arrow:SetBackground(0x41007e1b);
        self.selection:SetOutlineColor(Turbine.UI.Color(0.85, 0.65, 0));
        self.selection:SetForeColor(Turbine.UI.Color(1, 1, 1));
        self.selection:SetFontStyle(Turbine.UI.FontStyle.Outline);
	end
end

function PullDownMenu:MouseLeave()
    if (self:IsEnabled()) then
        self.arrow:SetBackground(0x41007e18);
        self.selection:SetOutlineColor(Turbine.UI.Color(0, 0, 0));
        self.selection:SetForeColor(Turbine.UI.Color((229/255), (209/255), (136/255)));
        self.selection:SetFontStyle(Turbine.UI.FontStyle.None);
	end
end

function PullDownMenu:MouseClick()
    if (self.menu and self:IsEnabled()) then
        local left, top, parent = self:GetPosition(), self:GetParent();
        left, top = self:GetParent():PointToScreen(self:GetPosition());
        self.menu:ShowMenuAt(left, top + self:GetHeight());
    end
end

function PullDownMenu:SetWidth(width)
    Turbine.UI.Control.SetWidth(self, width);
	self.interior:SetWidth(width - 4);
	self.selection:SetWidth(width - 19);
	self.arrow:SetLeft(width - 19);
end

function PullDownMenu:SetHeight(height)
    Turbine.UI.Control.SetHeight(self, height);
	self.interior:SetHeight(height - 4);
	self.selection:SetHeight(height);
	self.arrow:SetTop(height - 19);
end

function PullDownMenu:SetSize(width, height)
    self:SetWidth(width);
    self:SetHeight(height);
end

if (not Thurallor.UI) then
    Thurallor.UI = {};
end
Thurallor.UI.PullDownMenu = PullDownMenu;
