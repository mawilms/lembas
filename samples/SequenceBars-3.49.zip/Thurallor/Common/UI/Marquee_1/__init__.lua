import "Turbine";
import "Turbine.UI";
import "Turbine.UI.Lotro";

local importPath = getfenv(1)._.Name;
local commonPath = string.gsub(importPath, "%.UI%.Marquee_[0-9]+$", "");

--import (commonPath .. ".Turbine");
--import (commonPath .. ".Utils");
import (importPath .. ".Marquee");

Thurallor = Thurallor or {};
Thurallor.UI = Thurallor.UI or {};
Thurallor.UI.Marquee = Marquee;
