Marquee = class(Turbine.UI.Control);

local importPath = getfenv(1)._.Name;
local imagePath = string.gsub(string.gsub(importPath, "%.Marquee$", ""), "%.", "/");

function Marquee:Constructor()
	self.antsOffset = 0;
	self.maxAntsOffset = 7;
	self.antsMoveDelay = 0.1; -- 0.1-second delay = 10 updates per second

    Turbine.UI.Control.Constructor(self);
    self:SetMouseVisible(false);

	self.leftBorder = Turbine.UI.Control();
	self.leftBorder:SetParent(self);
    self.leftBorder:SetMouseVisible(false);

	self.topBorder = Turbine.UI.Control();
	self.topBorder:SetParent(self);
    self.topBorder:SetMouseVisible(false);
	
	self.rightBorder = Turbine.UI.Control();
	self.rightBorder:SetParent(self);
    self.rightBorder:SetMouseVisible(false);
	
	self.bottomBorder = Turbine.UI.Control();
	self.bottomBorder:SetParent(self);
    self.bottomBorder:SetMouseVisible(false);

	self.lastAntsMoveTime = Turbine.Engine.GetGameTime();
    self:SetAntsEnabled(true);
    self:SetColor(Turbine.UI.Color.White);
end

function Marquee:SetAntsEnabled(enable)
    self.antsEnabled = enable;
    self.leftBorder:SetBackground(enable and (imagePath .. "/ants_vertical.tga"));
    self.topBorder:SetBackground(enable and (imagePath .. "/ants_horizontal.tga"));
    self.rightBorder:SetBackground(enable and (imagePath .. "/ants_vertical.tga"));
    self.bottomBorder:SetBackground(enable and (imagePath .. "/ants_horizontal.tga"));
    self.leftBorder:SetBackColorBlendMode(enable and Turbine.UI.BlendMode.Color);
    self.topBorder:SetBackColorBlendMode(enable and Turbine.UI.BlendMode.Color);
    self.rightBorder:SetBackColorBlendMode(enable and Turbine.UI.BlendMode.Color);
    self.bottomBorder:SetBackColorBlendMode(enable and Turbine.UI.BlendMode.Color);
end

function Marquee:GetAntsEnabled()
    return self.antsEnabled;
end

function Marquee:SetVisible(visible)
    local parent = visible and self or nil;
	self.leftBorder:SetParent(parent);
	self.topBorder:SetParent(parent);
	self.rightBorder:SetParent(parent);
	self.bottomBorder:SetParent(parent);
end

function Marquee:IsVisible()
    return (self.leftBorder:GetParent() == self);
end

function Marquee:Update()
	-- Make sure enough time has elapsed since the ants moved last.
	local currentTime = Turbine.Engine.GetGameTime();
	if (currentTime - self.lastAntsMoveTime < self.antsMoveDelay) then
		return;
    end
	self.lastAntsMoveTime = currentTime;

	-- Move the ants by one pixel.
	self.antsOffset = self.antsOffset + 1;
	if (self.antsOffset > self.maxAntsOffset) then
		self.antsOffset = 0;
    end

	-- Move ants to new position.
	self.leftBorder:SetTop(self.antsOffset - self.maxAntsOffset);
	self.topBorder:SetLeft(-self.antsOffset);
	self.rightBorder:SetTop(-self.antsOffset);
	self.bottomBorder:SetLeft(self.antsOffset - self.maxAntsOffset);
end

function Marquee:SetColor(color)
    self.leftBorder:SetBackColor(color);
    self.topBorder:SetBackColor(color);
    self.rightBorder:SetBackColor(color);
    self.bottomBorder:SetBackColor(color);
end

function Marquee:GetColor()
    return self.leftBorder:GetBackColor();
end

function Marquee:SetSize(width, height)
	self:SetWidth(width);
	self:SetHeight(height);
end

function Marquee:SetWidth(width)
	Turbine.UI.Control.SetWidth(self, width);
	self.topBorder:SetSize(width + self.maxAntsOffset, 1);
	self.bottomBorder:SetSize(width + self.maxAntsOffset, 1);
	self.rightBorder:SetLeft(width - 1);
end

function Marquee:SetHeight(height)
	Turbine.UI.Control.SetHeight(self, height);
	self.leftBorder:SetSize(1, height + self.maxAntsOffset);
	self.rightBorder:SetSize(1, height + self.maxAntsOffset);
	self.bottomBorder:SetTop(height - 1);
end

function Marquee:SetParent(parent)
    if (parent) then
        self:SetWantsUpdates(true);
    else
        self:SetWantsUpdates(false);
    end
    Turbine.UI.Control.SetParent(self, parent);
end

function Marquee:SetSpeed(speed)
    self.antsMoveDelay = 1 / speed;
end