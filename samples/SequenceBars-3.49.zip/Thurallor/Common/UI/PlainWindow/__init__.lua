import "Turbine";
import "Turbine.UI";
import "Turbine.UI.Lotro";

local importPath = getfenv(1)._.Name;
local commonPath = string.gsub(importPath, "%.UI%.PlainWindow$", "");

--import (commonPath .. ".Turbine");
--import (commonPath .. ".Utils");
import (commonPath .. ".UI.Resizer");
import (importPath .. ".PlainWindow");

if (not Thurallor.UI) then
    Thurallor.UI = {};
end
Thurallor.UI.PlainWindow = PlainWindow;