local imagePath = string.gsub(getfenv(1)._.Name, "%.PlainWindow$", "");
imagePath = string.gsub(imagePath, "%.", "/");

PlainWindow = class(Turbine.UI.Window);

function PlainWindow:Constructor(title)
    Turbine.UI.Window.Constructor(self);

    self.titleBarHeight = 14;
    self.titleBar = Turbine.UI.TextBox();
    self.titleBar:SetParent(self);
    self.titleBar:SetPosition(1, 1);
    self.titleBar:SetOutlineColor(Turbine.UI.Color.Black);
    self.titleBar:SetFontStyle(Turbine.UI.FontStyle.Outline);
    self.titleBar:SetTextAlignment(Turbine.UI.ContentAlignment.MiddleCenter);
    self.titleBar:SetMultiline(false);
    self.titleBar:SetText(title);
    self.titleBar:SetHeight(self.titleBarHeight);
    self.titleBar:SetMouseVisible(true);
    function self.titleBar.MouseDown(tb)
        self.mouseDown = true;
        self.prevMousePos = { Turbine.UI.Display.GetMousePosition() };
    end
    function self.titleBar.MouseMove(tb)
        if (self.mouseDown) then
            self.moved = true;
            local mousePos = { Turbine.UI.Display.GetMousePosition() };
            self:SetPosition(self:GetLeft() + mousePos[1] - self.prevMousePos[1], self:GetTop() + mousePos[2] - self.prevMousePos[2]);
            self.prevMousePos = mousePos;
        end
    end
    function self.titleBar.MouseUp(tb)
        if (self.moved) then
            -- We were just moving it, we don't want to edit the text
            self:Focus();
            self.moved = false;
        end
        self.mouseDown = false;
    end

    self.menuIcon = Turbine.UI.Control();
    self.menuIcon:SetBackground(imagePath .. "/menuIcon.tga");
    self.menuIcon:SetBlendMode(Turbine.UI.BlendMode.AlphaBlend);
    self.menuIcon:SetParent(self);
    self.menuIcon:SetPosition(1, 1);
    self.menuIcon:SetSize(self.titleBarHeight, self.titleBarHeight);
    function self.menuIcon.MouseEnter(menuIcon)
        menuIcon:SetBackground(imagePath .. "/menuIconHighlight.tga");
    end
    function self.menuIcon.MouseLeave(menuIcon)
        menuIcon:SetBackground(imagePath .. "/menuIcon.tga");
    end
    function self.menuIcon.MouseDown()
        self.pulldownMenu:Close();
        self.pulldownMenu:ShowMenuAt(self:GetLeft() + 1, self:GetTop() + 1 + self.titleBarHeight);
    end
    self:SetMenu(nil); -- icon not displayed because we don't have a menu yet

    self.closeIcon = Turbine.UI.Control();
    self.closeIcon:SetBackground(imagePath .. "/closeIcon.tga");
    self.closeIcon:SetBlendMode(Turbine.UI.BlendMode.AlphaBlend);
    self.closeIcon:SetParent(self);
    self.closeIcon:SetPosition(self:GetWidth() - 1 - self.titleBarHeight, 1);
    self.closeIcon:SetSize(self.titleBarHeight, self.titleBarHeight);
    function self.closeIcon.MouseEnter(closeIcon)
        closeIcon:SetBackground(imagePath .. "/closeIconHighlight.tga");
    end
    function self.closeIcon.MouseLeave(closeIcon)
        closeIcon:SetBackground(imagePath .. "/closeIcon.tga");
    end
    function self.closeIcon.MouseClick()
        self:Close();
    end

    self.innerControl = Turbine.UI.Control();
    self.innerControl:SetParent(self);
    self.innerControl:SetBackColor(Turbine.UI.Color.Black);
    self.innerControl:SetPosition(1, self.titleBarHeight + 2);
    
    self.resizer = Thurallor.UI.Resizer(self);
end

function PlainWindow:SetVisible(visible)
    Turbine.UI.Window.SetVisible(self, visible);
end

function PlainWindow:SetForeColor(color)
    self.titleBar:SetForeColor(color);
end

function PlainWindow:SetInnerControl(control)
    local width, height = self.innerControl:GetSize();
    self.innerControl:SetParent(nil);
    if (control == nil) then
        control = Turbine.UI.Control();
    end
    self.innerControl = control;
    control:SetPosition(1, self.titleBarHeight + 2);
    control:SetParent(self);
    control:SetSize(width, height);
    return control;
end


function PlainWindow:SetZOrder(z)
    Turbine.UI.Window.SetZOrder(self, z);
end

function PlainWindow:SetSize(width, height)
    Turbine.UI.Window.SetSize(self, width, height);
    self.titleBar:SetWidth(width - 2);
    self.closeIcon:SetLeft(width - 1 - self.titleBarHeight);
    self.innerControl:SetSize(width - 2, height - 3 - self.titleBarHeight);

    if (not self.resizer:IsResizing()) then
        self.resizer:SetParent(nil);
        self.resizer = Thurallor.UI.Resizer(self);
    end
end

function PlainWindow:SetWidth(width)
    self:SetSize(width, self:GetHeight());
end

function PlainWindow:SetHeight(height)
    self:SetSize(self:GetWidth(), height);
end

function PlainWindow:SetMenu(menu)
    if (menu == nil) then
        self.menuIcon:SetParent(nil);
    else
        self.menuIcon:SetParent(self);
    end
    self.pulldownMenu = menu;
end

function PlainWindow:AddMenuItem(item)
    local items = self.pulldownMenu:GetItems();
    items:Add(item);
end

if (not Thurallor.UI) then
    Thurallor.UI = {};
end
Thurallor.UI.PlainWindow = PlainWindow;
