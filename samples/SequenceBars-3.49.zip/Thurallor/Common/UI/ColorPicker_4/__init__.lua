import "Turbine";
import "Turbine.UI";
import "Turbine.UI.Lotro";

local importPath = getfenv(1)._.Name;
local commonPath = string.gsub(importPath, "%.UI%.ColorPicker_[0-9]+$", "");

--import (commonPath .. ".Turbine");
--import (commonPath .. ".Utils");
--import (commonPath .. ".UI.RadioButton");
import (importPath .. ".Locale");
import (importPath .. ".Slider");
import (importPath .. ".Palette");
import (importPath .. ".SwatchBar");
import (importPath .. ".ColorPicker");

Thurallor = Thurallor or {};
Thurallor.UI = Thurallor.UI or {};
Thurallor.UI.ColorPicker = ColorPicker;
