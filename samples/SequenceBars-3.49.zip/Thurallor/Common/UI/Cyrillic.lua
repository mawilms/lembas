-- Save original values for use with English / German / French
Turbine.UI.Lotro.Font._TrajanPro13 = Turbine.UI.Lotro.Font.TrajanPro13;
Turbine.UI.Lotro.Font._TrajanPro14 = Turbine.UI.Lotro.Font.TrajanPro14;
Turbine.UI.Lotro.Font._TrajanPro15 = Turbine.UI.Lotro.Font.TrajanPro15;
Turbine.UI.Lotro.Font._TrajanPro16 = Turbine.UI.Lotro.Font.TrajanPro16;
Turbine.UI.Lotro.Font._TrajanPro18 = Turbine.UI.Lotro.Font.TrajanPro18;
Turbine.UI.Lotro.Font._TrajanPro19 = Turbine.UI.Lotro.Font.TrajanPro19;
Turbine.UI.Lotro.Font._TrajanPro20 = Turbine.UI.Lotro.Font.TrajanPro20;
Turbine.UI.Lotro.Font._TrajanPro21 = Turbine.UI.Lotro.Font.TrajanPro21;
Turbine.UI.Lotro.Font._TrajanPro23 = Turbine.UI.Lotro.Font.TrajanPro23;
Turbine.UI.Lotro.Font._TrajanPro24 = Turbine.UI.Lotro.Font.TrajanPro24;
Turbine.UI.Lotro.Font._TrajanPro25 = Turbine.UI.Lotro.Font.TrajanPro25;
Turbine.UI.Lotro.Font._TrajanPro26 = Turbine.UI.Lotro.Font.TrajanPro26;
Turbine.UI.Lotro.Font._TrajanPro28 = Turbine.UI.Lotro.Font.TrajanPro28;
Turbine.UI.Lotro.Font._TrajanProBold16 = Turbine.UI.Lotro.Font.TrajanProBold16;
Turbine.UI.Lotro.Font._TrajanProBold22 = Turbine.UI.Lotro.Font.TrajanProBold22;
Turbine.UI.Lotro.Font._TrajanProBold24 = Turbine.UI.Lotro.Font.TrajanProBold24;
Turbine.UI.Lotro.Font._TrajanProBold25 = Turbine.UI.Lotro.Font.TrajanProBold25;
Turbine.UI.Lotro.Font._TrajanProBold30 = Turbine.UI.Lotro.Font.TrajanProBold30;
Turbine.UI.Lotro.Font._TrajanProBold36 = Turbine.UI.Lotro.Font.TrajanProBold36;

Turbine.UI._Button = Turbine.UI.Button;
Turbine.UI._Checkbox = Turbine.UI.Checkbox;
Turbine.UI._Label = Turbine.UI.Label;
Turbine.UI._TextBox = Turbine.UI.TextBox;
Turbine.UI.Lotro._Button = Turbine.UI.Lotro.Button;
Turbine.UI.Lotro._Checkbox = Turbine.UI.Lotro.Checkbox;
Turbine.UI.Lotro._GoldButton = Turbine.UI.Lotro.GoldButton;
Turbine.UI.Lotro._GoldWindow = Turbine.UI.Lotro.GoldWindow;
Turbine.UI.Lotro._TextBox = Turbine.UI.Lotro.TextBox;
Turbine.UI.Lotro._Window = Turbine.UI.Lotro.Window;
Turbine.UI._MenuItem = Turbine.UI.MenuItem;


function _G.SetCyrillicEnabled(enabled)
    if (enabled) then

        -- TrajanPro and TrajanProBold don't support Cyrillic characters, so we substitute Verdana.
        Turbine.UI.Lotro.Font.TrajanPro13 = Turbine.UI.Lotro.Font.Verdana12;
        Turbine.UI.Lotro.Font.TrajanPro14 = Turbine.UI.Lotro.Font.Verdana12;
        Turbine.UI.Lotro.Font.TrajanPro15 = Turbine.UI.Lotro.Font.Verdana14;
        Turbine.UI.Lotro.Font.TrajanPro16 = Turbine.UI.Lotro.Font.Verdana14;
        Turbine.UI.Lotro.Font.TrajanPro18 = Turbine.UI.Lotro.Font.Verdana16;
        Turbine.UI.Lotro.Font.TrajanPro19 = Turbine.UI.Lotro.Font.Verdana18;
        Turbine.UI.Lotro.Font.TrajanPro20 = Turbine.UI.Lotro.Font.Verdana18;
        Turbine.UI.Lotro.Font.TrajanPro21 = Turbine.UI.Lotro.Font.Verdana20;
        Turbine.UI.Lotro.Font.TrajanPro23 = Turbine.UI.Lotro.Font.Verdana23;
        Turbine.UI.Lotro.Font.TrajanPro24 = Turbine.UI.Lotro.Font.Verdana23;
        Turbine.UI.Lotro.Font.TrajanPro25 = Turbine.UI.Lotro.Font.Verdana23;
        Turbine.UI.Lotro.Font.TrajanPro26 = Turbine.UI.Lotro.Font.Verdana23;
        Turbine.UI.Lotro.Font.TrajanPro28 = Turbine.UI.Lotro.Font.Verdana23;
        Turbine.UI.Lotro.Font.TrajanProBold16 = Turbine.UI.Lotro.Font.Verdana14;
        Turbine.UI.Lotro.Font.TrajanProBold22 = Turbine.UI.Lotro.Font.Verdana20;
        Turbine.UI.Lotro.Font.TrajanProBold24 = Turbine.UI.Lotro.Font.Verdana23;
        Turbine.UI.Lotro.Font.TrajanProBold25 = Turbine.UI.Lotro.Font.Verdana23;
        Turbine.UI.Lotro.Font.TrajanProBold30 = Turbine.UI.Lotro.Font.Verdana23;
        Turbine.UI.Lotro.Font.TrajanProBold36 = Turbine.UI.Lotro.Font.Verdana23;

        -- Change default font of Button
        Turbine.UI.Button = class(Turbine.UI._Button);
        function Turbine.UI.Button.Constructor(self)
            Turbine.UI._Button.Constructor(self);
            self:SetFont(Turbine.UI.Lotro.Font.Verdana12);
        end

        -- Change default font of Checkbox
        Turbine.UI.Checkbox = class(Turbine.UI._Checkbox);
        function Turbine.UI.Checkbox.Constructor(self)
            Turbine.UI._Checkbox.Constructor(self);
            self:SetFont(Turbine.UI.Lotro.Font.Verdana12);
        end

        -- Change default font of Label
        Turbine.UI.Label = class(Turbine.UI._Label);
        function Turbine.UI.Label:Constructor()
            Turbine.UI._Label.Constructor(self);
            self:SetFont(Turbine.UI.Lotro.Font.Verdana14);
        end

        -- Change default font of TextBox
        Turbine.UI.TextBox = class(Turbine.UI._TextBox);
        function Turbine.UI.TextBox.Constructor(self)
            Turbine.UI._TextBox.Constructor(self);
            self:SetFont(Turbine.UI.Lotro.Font.Verdana12);
        end

        -- Change default font of Lotro.Button
        Turbine.UI.Lotro.Button = class(Turbine.UI.Lotro._Button);
        function Turbine.UI.Lotro.Button.Constructor(self)
            Turbine.UI.Lotro._Button.Constructor(self);
            self:SetFont(Turbine.UI.Lotro.Font.Verdana12);
        end

        -- Change default font of Lotro.Checkbox
        Turbine.UI.Lotro.Checkbox = class(Turbine.UI.Lotro._Checkbox);
        function Turbine.UI.Lotro.Checkbox.Constructor(self)
            Turbine.UI.Lotro._Checkbox.Constructor(self);
            self:SetFont(Turbine.UI.Lotro.Font.Verdana12);
        end

        -- Change default font of Lotro.GoldButton
        Turbine.UI.Lotro.GoldButton = class(Turbine.UI.Lotro._GoldButton);
        function Turbine.UI.Lotro.GoldButton.Constructor(self)
            Turbine.UI.Lotro._GoldButton.Constructor(self);
            self:SetFont(Turbine.UI.Lotro.Font.Verdana12);
        end

        -- Change font of Lotro.GoldWindow title.
        Turbine.UI.Lotro.GoldWindow = class(Turbine.UI.Lotro._GoldWindow);
        function Turbine.UI.Lotro.GoldWindow:Constructor()
            Turbine.UI.Lotro._GoldWindow.Constructor(self);

            -- Superimpose Verdana text on it.
            self._label = Turbine.UI.Label();
            self._label:SetParent(self);
            self._label:SetSize(self:GetWidth(), 32);
            self._label:SetTextAlignment(Turbine.UI.ContentAlignment.MiddleCenter);
            self._label:SetFont(Turbine.UI.Lotro.Font.Verdana14);
            self._label:SetFontStyle(Turbine.UI.FontStyle.Outline);
            self._label:SetForeColor(Turbine.UI.Color.PaleGoldenrod);
            self._label:SetOutlineColor(Turbine.UI.Color.Black);
            self._label:SetMouseVisible(false);
            
            AddCallback(self, "SizeChanged", function()
                self._label:SetWidth(self:GetWidth());
            end);
        end

        function Turbine.UI.Lotro.GoldWindow:SetText(text)
            Turbine.UI.Lotro._GoldWindow.SetText(self, string.rep(" ", string.len(text)));
            self._label:SetText(text);
        end

        function Turbine.UI.Lotro.GoldWindow.SetWidth(self, width)
            Turbine.UI.Lotro._GoldWindow.SetWidth(self, width);
            self.label:SetWidth(width);
        end

        function Turbine.UI.Lotro.GoldWindow:SetSize(width, height)
            Turbine.UI.Lotro._GoldWindow.SetSize(self, width, height);
            self.label:SetWidth(width);
        end

        -- Change default font of Lotro.TextBox
        Turbine.UI.Lotro.TextBox = class(Turbine.UI.Lotro._TextBox);
        function Turbine.UI.Lotro.TextBox.Constructor(self)
            Turbine.UI.Lotro._TextBox.Constructor(self);
            self:SetFont(Turbine.UI.Lotro.Font.Verdana12);
        end

        -- Change default dont of ContextMenu and MenuItem (if using DTox ContextMenu)
        local temp = Turbine.UI.ContextMenu();
        if (temp.SetFont) then
            temp:SetFont("Verdana14");
        end

        -- Change font of Lotro.Window title.
        Turbine.UI.Lotro.Window = class(Turbine.UI.Lotro._Window);
        function Turbine.UI.Lotro.Window:Constructor()
            Turbine.UI.Lotro._Window.Constructor(self);
            
            -- Superimpose Verdana text on it.
            self._label = Turbine.UI.Label();
            self._label:SetParent(self);
            self._label:SetSize(self:GetWidth(), 32);
            self._label:SetTextAlignment(Turbine.UI.ContentAlignment.MiddleCenter);
            self._label:SetFont(Turbine.UI.Lotro.Font.Verdana14);
            self._label:SetFontStyle(Turbine.UI.FontStyle.Outline);
            self._label:SetForeColor(Turbine.UI.Color.PaleGoldenrod);
            self._label:SetOutlineColor(Turbine.UI.Color.Black);
            self._label:SetMouseVisible(false);
            
            AddCallback(self, "SizeChanged", function()
                self._label:SetWidth(self:GetWidth());
            end);
        end

        function Turbine.UI.Lotro.Window:SetText(text)
            Turbine.UI.Lotro._Window.SetText(self, string.rep(" ", string.len(text)));
            self._label:SetText(text);
        end

        function Turbine.UI.Lotro.Window.SetWidth(self, width)
            Turbine.UI.Lotro._Window.SetWidth(self, width);
            self._label:SetWidth(width);
        end

        function Turbine.UI.Lotro.Window:SetSize(width, height)
            Turbine.UI.Lotro._Window.SetSize(self, width, height);
            self._label:SetWidth(width);
        end

    else -- disable Cyrillic
    
        -- Restore original fonts and classes
        Turbine.UI.Lotro.Font.TrajanPro13 = Turbine.UI.Lotro.Font._TrajanPro13;  
        Turbine.UI.Lotro.Font.TrajanPro14 = Turbine.UI.Lotro.Font._TrajanPro14;  
        Turbine.UI.Lotro.Font.TrajanPro15 = Turbine.UI.Lotro.Font._TrajanPro15;  
        Turbine.UI.Lotro.Font.TrajanPro16 = Turbine.UI.Lotro.Font._TrajanPro16;  
        Turbine.UI.Lotro.Font.TrajanPro18 = Turbine.UI.Lotro.Font._TrajanPro18;  
        Turbine.UI.Lotro.Font.TrajanPro19 = Turbine.UI.Lotro.Font._TrajanPro19;  
        Turbine.UI.Lotro.Font.TrajanPro20 = Turbine.UI.Lotro.Font._TrajanPro20;  
        Turbine.UI.Lotro.Font.TrajanPro21 = Turbine.UI.Lotro.Font._TrajanPro21;  
        Turbine.UI.Lotro.Font.TrajanPro23 = Turbine.UI.Lotro.Font._TrajanPro23;  
        Turbine.UI.Lotro.Font.TrajanPro24 = Turbine.UI.Lotro.Font._TrajanPro24;  
        Turbine.UI.Lotro.Font.TrajanPro25 = Turbine.UI.Lotro.Font._TrajanPro25;  
        Turbine.UI.Lotro.Font.TrajanPro26 = Turbine.UI.Lotro.Font._TrajanPro26;  
        Turbine.UI.Lotro.Font.TrajanPro28 = Turbine.UI.Lotro.Font._TrajanPro28;  
        Turbine.UI.Lotro.Font.TrajanProBold16 = Turbine.UI.Lotro.Font._TrajanProBold16;
        Turbine.UI.Lotro.Font.TrajanProBold22 = Turbine.UI.Lotro.Font._TrajanProBold22;
        Turbine.UI.Lotro.Font.TrajanProBold24 = Turbine.UI.Lotro.Font._TrajanProBold24;
        Turbine.UI.Lotro.Font.TrajanProBold25 = Turbine.UI.Lotro.Font._TrajanProBold25;
        Turbine.UI.Lotro.Font.TrajanProBold30 = Turbine.UI.Lotro.Font._TrajanProBold30;
        Turbine.UI.Lotro.Font.TrajanProBold36 = Turbine.UI.Lotro.Font._TrajanProBold36;

        Turbine.UI.Button = Turbine.UI._Button;
        Turbine.UI.Checkbox = Turbine.UI._Checkbox;
        Turbine.UI.Label = Turbine.UI._Label;
        Turbine.UI.TextBox = Turbine.UI._TextBox;
        Turbine.UI.Lotro.Button = Turbine.UI.Lotro._Button;
        Turbine.UI.Lotro.Checkbox = Turbine.UI.Lotro._Checkbox;
        Turbine.UI.Lotro.GoldButton = Turbine.UI.Lotro._GoldButton;
        Turbine.UI.Lotro.GoldWindow = Turbine.UI.Lotro._GoldWindow;
        Turbine.UI.Lotro.TextBox = Turbine.UI.Lotro._TextBox;
        local temp = Turbine.UI.ContextMenu();
        if (temp.SetFont) then
            temp:SetFont("TrajanPro14");
        end
        Turbine.UI.Lotro.Window = Turbine.UI.Lotro._Window;
    end
end
