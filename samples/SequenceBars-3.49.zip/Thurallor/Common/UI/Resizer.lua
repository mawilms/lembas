Resizer = class(Turbine.UI.Control);

function Resizer:Constructor(parent)
    Turbine.UI.Control.Constructor(self);

    self:SetSize(16, 16);
    self:SetBackground(0x4100013D);
    self:SetBlendMode(Turbine.UI.BlendMode.None);
    
    if (parent) then
        self:SetParent(parent);
    end
end

function Resizer:SetParent(parent)
    Turbine.UI.Control.SetParent(self, parent);
    self.parent = parent;
    if (parent) then
        self:SetZOrder(parent:GetZOrder() + 1);
        local width, height = parent:GetSize();
        self:SetPosition(width - 18, height - 18);
    end
end

function Resizer:MouseEnter()
    self.mouseInside = true;
    self:SetBlendMode(Turbine.UI.BlendMode.Overlay);
end

function Resizer:MouseLeave()
    self.mouseInside = false;
    if (not self.resizing) then
        self:SetBlendMode(Turbine.UI.BlendMode.None);
    end
end

function Resizer:MouseDown()
    self.resizing = true;
    self.origin = {self.parent:GetMousePosition()};
end

function Resizer:MouseUp()
    self.resizing = false;
    if (not self.mouseInside) then
        self:SetBlendMode(Turbine.UI.BlendMode.None);
    end
    if (self.resized) then
        DoCallbacks(self.parent, "Resized");
        self.resized = nil;
    end
end

function Resizer:IsResizing()
    return self.resizing;
end

function Resizer:MouseMove()
    if (self.resizing) then
        local x, y = self.parent:GetMousePosition();
        local deltaX, deltaY = x - self.origin[1], y - self.origin[2];
        local newWidth, newHeight = self.parent:GetSize();
        newWidth = newWidth + deltaX;
        newHeight = newHeight + deltaY;
        if (self.maxWidth and (newWidth > self.maxWidth)) then
            newWidth = self.maxWidth;
        elseif (self.minWidth and (newWidth < self.minWidth)) then
            newWidth = self.minWidth;
        end
        if (self.maxHeight and (newHeight > self.maxHeight)) then
            newHeight = self.maxHeight;
        elseif (self.minHeight and (newHeight < self.minHeight)) then
            newHeight = self.minHeight;
        end
        self.parent:SetSize(newWidth, newHeight);
        self:SetPosition(newWidth - 18, newHeight - 18);
        self.origin = {x, y};
        DoCallbacks(self.parent, "Resizing");
        self.resized = true;
    end
end

function Resizer:SetMinimumWidth(minWidth)
    self.minWidth = minWidth;
    if (self.parent and (self.parent:GetWidth() < minWidth)) then
        self.parent:SetWidth(minWidth);
    end
end

function Resizer:SetMinimumHeight(minHeight)
    self.minHeight = minHeight;
    if (self.parent and (self.parent:GetHeight() < minHeight)) then
        self.parent:SetHeight(minHeight);
    end
end

function Resizer:SetMinimumSize(minWidth, minHeight)
    self:SetMinimumWidth(minWidth);
    self:SetMinimumHeight(minHeight);
end

function Resizer:SetMaximumWidth(maxWidth)
    self.maxWidth = maxWidth;
    if (self.parent and (self.parent:GetWidth() > maxWidth)) then
        self.parent:SetWidth(maxWidth);
    end
end

function Resizer:SetMaximumHeight(maxHeight)
    self.maxHeight = maxHeight;
    if (self.parent and (self.parent:GetHeight() > maxHeight)) then
        self.parent:SetHeight(maxHeight);
    end
end

function Resizer:SetMaximumSize(maxWidth, maxHeight)
    self:SetMaximumWidth(maxWidth);
    self:SetMaximumHeight(maxHeight);
end

if (not Thurallor.UI) then
    Thurallor.UI = {};
end
Thurallor.UI.Resizer = Resizer;
