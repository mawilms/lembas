Line = class(Turbine.UI.Window);

function Line:Constructor(x1, y1, x2, y2, thickness, color)
    self.x1, self.y1 = x1, y1;
    self.x2, self.y2 = x2, y2;
    if (not thickness) then
        thickness = 1;
    end
    self.thickness = thickness;
    if (not color) then
        color = Turbine.UI.Color.White;
    end

    -- self is a square container window which will be rotated
    Turbine.UI.Window.Constructor(self);
    self:SetVisible(true);

    -- self.line is a child control that displays the line itself
    self.line = Turbine.UI.Control();
    self.line:SetParent(self);

    self:Reshape();
    self:SetColor(color);
end

function Line:Reshape()
    local length = self:GetLength();
    local angle = self:GetAngle();

    self:SetSize(length, length);
    self:SetThickness(self.thickness);

    self:SetRotation({x = 0; y = 0; z = angle});
    
    local h = length / 2;
    local xOffset = math.floor(0.5 + h - h * math.cos(math.rad(-angle)));
    local yOffset = math.floor(0.5 + h - h * math.sin(math.rad(-angle)));
    
    self:SetPosition(self.x1 - xOffset, self.y1 - yOffset);
end

function Line:GetLength()
    local dx, dy = self.x2 - self.x1, self.y2 - self.y1;
    local length = math.floor((dx ^ 2 + dy ^ 2) ^ 0.5);
    return length;
end

function Line:GetAngle()
    local dx, dy = self.x2 - self.x1, self.y2 - self.y1;
    local theta = math.atan(dy / dx);
    if (dx < 0) then
        theta = theta + math.pi;
    end
    return -math.deg(theta);
end

function Line:SetStartPoint(x, y)
    self.x1, self.y1 = x, y;
    self:Reshape();
end

function Line:SetEndPoint(x, y)
    self.x2, self.y2 = x, y;
    self:Reshape();
end

function Line:SetThickness(thickness)
    self.thickness = thickness;
    local length = self:GetWidth();
    self.line:SetSize(length, thickness);
    self.line:SetTop(math.floor(0.5 + (length - thickness) / 2));
end

function Line:SetColor(color)
    self.line:SetBackColor(color);
end

Thurallor = Thurallor or {};
Thurallor.UI = Thurallor.UI or {};
Thurallor.UI.Line = Line;
