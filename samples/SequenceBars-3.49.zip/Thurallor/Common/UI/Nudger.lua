Nudger = class(Turbine.UI.Control);

function Nudger:Constructor(parent, font, value, minValue, maxValue)
    Turbine.UI.Control.Constructor(self);
    self:SetParent(parent);

    local function CreateButton(normalBackground, highlightedBackground)
        local button = Turbine.UI.Control();
        button:SetParent(self);
        button:SetSize(10, 10);
        button.normalBackground = normalBackground;
        button.highlightedBackground = highlightedBackground;
        button.MouseEnter = function(btn)
            btn:SetBackground(btn.highlightedBackground);
        end
        button.MouseLeave = function(btn)
            btn:SetBackground(btn.normalBackground);
        end
        button.MouseDown = function(btn)
            btn:SetWantsUpdates(true);
            btn.lastTime = Turbine.Engine.GetGameTime() + 0.25;
        end
        button.Update = function(btn)
            local gameTime = Turbine.Engine.GetGameTime();
            if ((gameTime - btn.lastTime) >= 0.1) then
                btn:Action();
                btn.lastTime = gameTime;
            end
        end
        button.MouseUp = function(btn)
            btn:SetWantsUpdates(false);
            btn:Action();
        end
        button:SetBlendMode(Turbine.UI.BlendMode.Overlay);
        button:MouseLeave();
        return button;
    end

    local upButton = CreateButton(0x4100028C, 0x4100028D);
    upButton.Action = function()
        self.textBox:SetText(self.textBox:GetText() + 1);
        self.textBox:Constrain();
        self.textBox:Focus();
        DoCallbacks(self, "ValueChanged");
    end
    self.upButton = upButton;
    
    local textBox = Turbine.UI.Lotro.TextBox();
    textBox:SetParent(self);
    textBox:SetPosition(0, 12);
    textBox:SetForeColor(Turbine.UI.Color.PaleGoldenrod);
    textBox:SetFont(font);
    textBox:SetTextAlignment(Turbine.UI.ContentAlignment.MiddleCenter);
    textBox:SetMultiline(false);
    textBox:SetText(value);
    textBox:SetHeight(22);
    textBox.GetText = function(tb)
        local value = Turbine.UI.Lotro.TextBox.GetText(tb);
        return tonumber(value) or 0;
    end
    textBox.minValue = minValue;
    textBox.maxValue = maxValue;
    textBox.Constrain = function(tb)
        local value = tb:GetText();
        if (tb.minValue) then
            value = math.max(tb.minValue, value);
        end
        if (tb.maxValue) then
            value = math.min(tb.maxValue, value);
        end
        tb:SetText(value);
    end
    textBox.FocusGained = function()
        DoCallbacks(self, "FocusGained");
    end
    textBox.FocusLost = function(tb)
        tb:Constrain();
        DoCallbacks(self, "FocusLost");
        DoCallbacks(self, "ValueChanged");
    end
    self.textBox = textBox;

    local downButton = CreateButton(0x4100028E, 0x4100028F);
    downButton:SetTop(36);
    downButton.Action = function()
        self.textBox:SetText(self.textBox:GetText() - 1);
        self.textBox:Constrain();
        self.textBox:Focus();
        DoCallbacks(self, "ValueChanged");
    end
    self.downButton = downButton;
    
    Turbine.UI.Control.SetHeight(self, 12 + 22 + 12);
end

function Nudger:SetText(text)
    self.textBox:SetText(text);
end

function Nudger:GetText()
    return self.textBox:GetText();
end

function Nudger:SetValue(value)
    self.textBox:SetText(value);
    self.textBox:Constrain();
end

function Nudger:GetValue()
    return tonumber(self.textBox:GetText());
end

function Nudger:SetSize(width, height)
    self:SetWidth(width);
end

function Nudger:SetHeight(height)
    -- Do nothing.  Height is not adjustable.
end

function Nudger:SetWidth(width)
    self.textBox:SetWidth(width);
    local btnLeft = math.floor(0.5 + (width - 10) / 2);
    self.upButton:SetLeft(btnLeft);
    self.downButton:SetLeft(btnLeft);
end

function Nudger:SetMaxValue(maxValue)
    self.textBox.maxValue = maxValue;
    self.textBox:Constrain();
end

function Nudger:SetMinValue(minValue)
    self.textBox.minValue = minValue;
    self.textBox:Constrain();
end

Thurallor = Thurallor or {};
Thurallor.UI = Thurallor.UI or {};
Thurallor.UI.Nudger = Nudger;
