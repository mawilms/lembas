EyeButton = class(Turbine.UI.Control);

function EyeButton:Constructor(parent, checked, enabled)
    Turbine.UI.Control.Constructor(self);

    self:SetParent(parent);
    self:SetSize(14, 14);

    self:SetChecked(checked);
    self:SetEnabled(enabled);
end

function EyeButton:SetChecked(checked)
    self.checked = checked;
    self:UpdateIcon();
end

function EyeButton:IsChecked()
    return self.checked;
end

function EyeButton:SetEnabled(enabled)
    self.enabled = enabled;
    self:UpdateIcon();
end

function EyeButton:IsEnabled()
    return self.enabled;
end

function EyeButton:UpdateIcon()
    local icon;
    if (self.enabled) then
        if (self.checked) then
            icon = 0x410DD517;
        else
            icon = 0x410DD516;
        end
    else
        if (self.checked) then
            icon = 0x410DD515;
        else
            icon = 0x410DD518;
        end
    end
    self:SetBackground(icon);
end

function EyeButton:MouseClick()
    if (self.enabled) then
        self:SetChecked(not self.checked)
        DoCallbacks(self, "CheckedChanged", { checked = false });
    end
end

Thurallor = Thurallor or {};
Thurallor.UI = Thurallor.UI or {};
Thurallor.UI.EyeButton = EyeButton;
