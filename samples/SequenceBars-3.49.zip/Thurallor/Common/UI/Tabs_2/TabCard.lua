TabCard = class(Turbine.UI.Window);

local importPath = getfenv(1)._.Name;
local imagePath = string.gsub(string.gsub(importPath, "%.TabCard$", ""), "%.", "/");

function TabCard:Constructor(hScroll, vScroll, draggable, isWindow)
    if (isWindow) then
        -- Make this control a window if we want to support different tab colors
        self.isWindow = true;
        Turbine.UI.Window.Constructor(self);
    else
        Turbine.UI.Control.Constructor(self);
    end
    
    self:SetVisible(true);
    self:SetMouseVisible(false);
--Turbine.UI.Control.SetBackColor(self, Turbine.UI.Color(0.1, 0, 0, 0));
--Turbine.UI.Control.SetBackColorBlendMode(self, Turbine.UI.BlendMode.Overlay);

    self.tabHeight = 20;
    self.scrollBarSize = 10;
    self.interiorAlignment = Turbine.UI.ContentAlignment.TopCenter;
    
    self.tabLeft = Turbine.UI.Control();
	self.tabLeft:SetBlendMode(Turbine.UI.BlendMode.AlphaBlend);
    self.tabLeft:SetParent(self);
    self.tabLeft:SetHeight(self.tabHeight);
    
    self.tabRight = Turbine.UI.Control();
	self.tabRight:SetBlendMode(Turbine.UI.BlendMode.AlphaBlend);
    self.tabRight:SetParent(self);
    self.tabRight:SetSize(18, self.tabHeight);

    self.tabText = Turbine.UI.Label();
    self.tabText:SetMultiline(false);
    self.tabText:SetParent(self.tabLeft);
    self.tabText:SetLeft(18);
    self.tabText:SetHeight(self.tabHeight);
	self.tabText:SetFont(Turbine.UI.Lotro.Font.TrajanPro15);
	self.tabText:SetFontStyle(Turbine.UI.FontStyle.Outline);
	self.tabText:SetOutlineColor(Turbine.UI.Color.Black);
	self.tabText:SetTextAlignment(Turbine.UI.ContentAlignment.MiddleCenter);
    
    self.tabText.MouseClick = function(_, args)
        DoCallbacks(self, "Click", args);
    end
    self.tabLeft.MouseClick = self.tabText.MouseClick;
    self.tabRight.MouseClick = self.tabText.MouseClick;
   
    if (draggable) then
        self.tabText.MouseDown = function(_, args)
            if (args.Button == Turbine.UI.MouseButton.Left) then
                self:SetZOrder(1);
                self:SetZOrder(0);
                self.mouseDown = true;
                self.mouseStartX = Turbine.UI.Display.GetMouseX();
                self.startLeft = self:GetTabLeft();
            end
        end
        self.tabText.MouseMove = function(_, args)
            if (self.mouseDown) then
                self.mouseMoved = true;
                local deltaX = Turbine.UI.Display.GetMouseX() - self.mouseStartX;
                local left = math.min(math.max(0, self.startLeft + deltaX), self:GetWidth() - self:GetTabWidth());
                self:SetTabLeft(left);
                deltaX = left - self.startLeft;
            end
        end
        self.tabText.MouseUp = function(_, args)
            if (args.Button == Turbine.UI.MouseButton.Left) then
                self.mouseDown = false;
                if (self.mouseMoved) then
                    DoCallbacks(self, "TabLeftChanged", self:GetTabLeft());
                end
            end
        end
        self.tabLeft.MouseDown = self.tabText.MouseDown;
        self.tabRight.MouseDown = self.tabText.MouseDown;
        self.tabLeft.MouseMove = self.tabText.MouseMove;
        self.tabRight.MouseMove = self.tabText.MouseMove;
        self.tabLeft.MouseUp = self.tabText.MouseUp;
        self.tabRight.MouseUp = self.tabText.MouseUp;
    end
    
    self.border = Turbine.UI.Lotro.TextBox();
    self.border:SetMouseVisible(false);
    self.border:SetParent(self);
    self.border:SetReadOnly(true);
    self.border:SetPosition(0, self.tabHeight);
    self.padding = 5;

    self.interior = Turbine.UI.ListBox();
    self.interior:SetParent(self);
    self.interior:SetMouseVisible(false);
    self.interior:SetPosition(self.padding, self.tabHeight + self.padding);
    self.interior.wrapper = Turbine.UI.Control();
    self.interior.wrapper:SetParent(self.interior);
    self.interior.wrapper:SetMouseVisible(false);
    self.interior:AddItem(self.interior.wrapper);

    if (hScroll) then
        self.hScrollBar = Turbine.UI.Lotro.ScrollBar();
        self.hScrollBar:SetOrientation(Turbine.UI.Orientation.Horizontal);
        self.hScrollBar:SetParent(self);
        self.hScrollBar:SetHeight(self.scrollBarSize);
        self.hScrollBar:SetLeft(2);
    end
    
    if (vScroll) then
        self.vScrollBar = Turbine.UI.Lotro.ScrollBar();
        self.vScrollBar:SetOrientation(Turbine.UI.Orientation.Vertical);
        self.vScrollBar:SetParent(self);
        self.vScrollBar:SetWidth(self.scrollBarSize);
        self.vScrollBar:SetTop(self.tabHeight + 2);
    end

    if ((not hScroll) and (not vScroll)) then
        self.scrollBarSize = 0;
    end
    
    self:BringToFront(true);
    self:DoLayout();
end

function TabCard:SetTabColor(color)
    self.tabLeft:SetBackColor(color);
    self.tabRight:SetBackColor(color);
    self.tabLeft:SetBackColorBlendMode(Turbine.UI.BlendMode.Color);
    self.tabRight:SetBackColorBlendMode(Turbine.UI.BlendMode.Color);
end

function TabCard:GetTabColor()
    return self.tabLeft:GetBackColor();
end

function TabCard:SetBackColor(color)
    self.border:SetBackColor(color);
end

function TabCard:GetBackColor()
    return self.border:GetBackColor();
end

function TabCard:SetInteriorControl(control)
    if (self.interior.control) then
        self.interior.control:SetParent(nil);
    end
    self.interior.control = control;
    if (control) then
        control:SetParent(self.interior.wrapper);
        control.SizeChanged = function()
            self:DoLayout();
        end
    end
    self:DoLayout();
end

function TabCard:SetInteriorAlignment(alignment)
    self.interiorAlignment = alignment;
    self:DoLayout();
end

function TabCard:BringToFront(calledFromStack)
    if (calledFromStack) then
        self.tabLeft:SetBackground(imagePath .. "/tab_front_left.tga");
        self.tabRight:SetBackground(imagePath .. "/tab_front_right.tga");
        self.tabText:SetForeColor(Turbine.UI.Color.White);
        self.border:SetVisible(true);
        self.interior:SetVisible(true);
        if (self.hScrollBar) then
            self.hScrollBar:SetParent(self);
            self.interior:SetHorizontalScrollBar(self.hScrollBar);
        end
        if (self.vScrollBar) then
            self.vScrollBar:SetParent(self);
            self.interior:SetVerticalScrollBar(self.vScrollBar);
        end
        self:DoLayout();
    else
        -- Need to push all other tabs to the back as well
        self:GetParent():BringToFront(self);
    end
end    

function TabCard:SendToBack(calledFromStack)
    self.tabLeft:SetBackground(imagePath .. "/tab_back_left.tga");
    self.tabRight:SetBackground(imagePath .. "/tab_back_right.tga");
    --self.tabText:SetForeColor(Turbine.UI.Color(1, 0.42, 0.42, 0.42));
    self.tabText:SetForeColor(Turbine.UI.Color.Goldenrod);
    if (self.hScrollBar) then
        self.interior:SetHorizontalScrollBar(nil);
        self.hScrollBar:SetParent(nil);
    end
    if (self.vScrollBar) then
        self.interior:SetVerticalScrollBar(nil);
        self.vScrollBar:SetParent(nil);
    end
    self.border:SetVisible(false);
    self.interior:SetVisible(false);
end

function TabCard:IsInFront()
    return (self.interior:IsVisible());
end

-- This function is deprecated.  No longer needed if Turbine.UI.Label:AutoSize() is defined.
function TabCard:SetTabWidth(width)
    width = width - 18;
    self.tabLeft:SetWidth(width);
    self.tabText:SetWidth(width - 18);
    self.tabRight:SetLeft(self.tabLeft:GetLeft() + width);
end

function TabCard:GetTabWidth()
    return self.tabLeft:GetWidth() + 18;
end

function TabCard:SetTabLeft(left)
    self.tabLeft:SetLeft(left);
    self.tabRight:SetLeft(left + self.tabLeft:GetWidth());
end

function TabCard:GetTabLeft()
    return self.tabLeft:GetLeft();
end

function TabCard:SetTabText(text)
    self.tabText:SetText(text);
    if (Turbine.UI.Label.AutoSize) then
        self.tabText:AutoSize();
        self.tabText:SetHeight(self.tabHeight);
        self:SetTabWidth(self.tabText:GetWidth() + 36);
    end
end

function TabCard:GetTabText()
    return self.tabText:GetText();
end

function TabCard:DoLayout()
    local width, height = self:GetSize();
    self.border:SetSize(width, height - self.tabHeight);
    if (self.hScrollBar) then
        self.hScrollBar:SetTop(height - self.scrollBarSize - 2);
        self.hScrollBar:SetWidth(width - self.scrollBarSize - 4);
    end
    if (self.vScrollBar) then
        self.vScrollBar:SetLeft(width - self.scrollBarSize - 2);
        self.vScrollBar:SetHeight(height - self.tabHeight - self.scrollBarSize - 4);
    end
    self.interior:SetSize(width - (self.padding + self.scrollBarSize + 2), height - (self.tabHeight + self.padding + self.scrollBarSize + 2));
    
    -- Do placement of the interior control as per SetInteriorAlignment()
    if (self.interior.control) then
        width, height = self.interior:GetSize();
        controlWidth, controlHeight = self.interior.control:GetSize();
        if (
            (controlWidth >= width) or
            (self.interiorAlignment == Turbine.UI.ContentAlignment.TopLeft) or
            (self.interiorAlignment == Turbine.UI.ContentAlignment.MiddleLeft) or
            (self.interiorAlignment == Turbine.UI.ContentAlignment.BottomLeft)
        ) then
            self.interior.control:SetLeft(0);
            self.interior.wrapper:SetWidth(controlWidth);
        elseif (
            (self.interiorAlignment == Turbine.UI.ContentAlignment.TopCenter) or
            (self.interiorAlignment == Turbine.UI.ContentAlignment.MiddleCenter) or
            (self.interiorAlignment == Turbine.UI.ContentAlignment.BottomCenter)
        ) then
            self.interior.control:SetLeft(math.floor(0.5 + (width - controlWidth) / 2));
            self.interior.wrapper:SetWidth(width);
        else -- Turbine.UI.ContentAlignment.[...]Right
            self.interior.control:SetLeft(width - controlWidth);
            self.interior.wrapper:SetWidth(width);
        end
        if (
            (controlHeight >= height) or
            (self.interiorAlignment == Turbine.UI.ContentAlignment.TopLeft) or
            (self.interiorAlignment == Turbine.UI.ContentAlignment.TopCenter) or
            (self.interiorAlignment == Turbine.UI.ContentAlignment.TopRight)
        ) then
            self.interior.control:SetTop(0);
            self.interior.wrapper:SetHeight(controlHeight);
        elseif (
            (self.interiorAlignment == Turbine.UI.ContentAlignment.MiddleLeft) or
            (self.interiorAlignment == Turbine.UI.ContentAlignment.MiddleCenter) or
            (self.interiorAlignment == Turbine.UI.ContentAlignment.MiddleRight)
        ) then
            self.interior.control:SetTop(math.floor(0.5 + (height - controlHeight) / 2));
            self.interior.wrapper:SetHeight(height);
        else -- Turbine.UI.ContentAlignment.Bottom[...]
            self.interior.control:SetTop(height - controlHeight);
            self.interior.wrapper:SetHeight(height);
        end
    end

    self.interior:ClearItems();
    self.interior:AddItem(self.interior.wrapper);
end

function TabCard:SetSize(width, height)
    if (self.isWindow) then
        Turbine.UI.Window.SetSize(self, width, height);
    else
        Turbine.UI.Control.SetSize(self, width, height);
    end
    if (self:IsInFront()) then
        self:DoLayout();
    end
end

function TabCard:SetWidth(width)
    self:SetSize(width, self:GetHeight());
end

function TabCard:SetHeight(height)
    self:SetSize(self:GetWidth(), height);
end
