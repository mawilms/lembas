TabCardStack = class(Turbine.UI.Control);

function TabCardStack:Constructor()
    Turbine.UI.Control.Constructor(self);
    self:SetMouseVisible(false);
    self.tabCards = {};
end

function TabCardStack:AddTabCard(tabCard)
    table.insert(self.tabCards, tabCard);
    tabCard:SetParent(self);
    self:BringToFront(tabCard);

    -- Default behavior when the tab is clicked is to bring the card to the front.
    AddCallback(tabCard, "Click", function(ctl, args)
        if (args.Button == Turbine.UI.MouseButton.Left) then
            self:BringToFront(ctl);
        end
    end);
end

function TabCardStack:BringToFront(tabCard)
    for t = 1, #self.tabCards do
        local otherTabCard = self.tabCards[t];
        if (otherTabCard == tabCard) then
            tabCard:BringToFront(true);
            tabCard:SetSize(self:GetSize());
            self.frontTabCard = tabCard;
        else
            otherTabCard:SendToBack(true);
        end
    end
end

function TabCardStack:RedistributeTabs()
    local width = self:GetWidth();

    -- Sort the tabCards by left edge
    local function compare(a, b)
        return (a:GetTabLeft() < b:GetTabLeft());
    end
    table.sort(self.tabCards, compare);
    
    -- Spread out the tabCards to eliminate overlap
    local left = 0;
    for t = 1, #self.tabCards do
        local tabCard = self.tabCards[t];
        tabCard:SetTabLeft(left);
        left = left + tabCard:GetTabWidth();
    end
    if (left <= width) then
        -- All the tabs fit without overlapping.  Done.
        return;
    end
    
    -- Some overlap is unavoidable.  Distribute the left edges evenly.
    local rightTab = self.tabCards[#self.tabCards];
    local rightTabWidth = rightTab:GetTabWidth();
    local newRightTabLeft = math.max(#self.tabCards, (width - rightTabWidth)); -- need at least as many pixels as tabs
    local squeezeRatio = newRightTabLeft / rightTab:GetTabLeft();
    for t = 1, #self.tabCards do
        local tabCard = self.tabCards[t];
        local left = math.floor(0.5 + tabCard:GetTabLeft() * squeezeRatio);
        tabCard:SetTabLeft(left);
    end
end

function TabCardStack:SetSize(width, height)
    Turbine.UI.Control.SetSize(self, width, height);
    for t = 1, #self.tabCards do
        local tabCard = self.tabCards[t];
        tabCard:SetSize(width, height);
    end
end

function TabCardStack:SetWidth(width)
    self:SetSize(width, self:GetHeight());
end

function TabCardStack:SetHeight(height)
    self:SetSize(self:GetWidth(), height);
end
