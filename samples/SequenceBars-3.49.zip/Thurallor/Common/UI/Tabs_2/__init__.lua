import "Turbine";
import "Turbine.UI";
import "Turbine.UI.Lotro";

local importPath = getfenv(1)._.Name;
local commonPath = string.gsub(importPath, "%.UI%.Tabs_[0-9]+$", "");

--import (commonPath .. ".Turbine");
--import (commonPath .. ".Utils");
--import (commonPath .. ".Utils.AutoSizing_1");
import (importPath .. ".TabCard");
import (importPath .. ".TabCardStack");

Thurallor = Thurallor or {};
Thurallor.UI = Thurallor.UI or {};
Thurallor.UI.TabCard = TabCard;
Thurallor.UI.TabCardStack = TabCardStack;
