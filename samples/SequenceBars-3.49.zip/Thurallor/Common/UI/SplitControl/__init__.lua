import "Turbine";
import "Turbine.UI";
import "Turbine.UI.Lotro";

local importPath = getfenv(1)._.Name;
local commonPath = string.gsub(importPath, "%.UI%.SplitControl$", "");

--import (commonPath .. ".Turbine");
--import (commonPath .. ".Utils");
import (importPath .. ".SplitControl");

Thurallor = Thurallor or {};
Thurallor.UI = Thurallor.UI or {};
Thurallor.UI.SplitControl = SplitControl;
