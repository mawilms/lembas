SplitControl = class(Turbine.UI.Control);

local importPath = getfenv(1)._.Name;
local imagePath = string.gsub(string.gsub(importPath, "%.SplitControl$", ""), "%.", "/");

function SplitControl:Constructor(orientation, control1, control2)
    Turbine.UI.Control.Constructor(self);
    
    self.orientation = orientation;
    self.control1 = control1;
    self.control1:SetParent(self);

    self.control2 = control2;
    self.control2:SetParent(self);

    local sash = Turbine.UI.Control(); 
    sash:SetParent(self);
    sash:SetBlendMode(Turbine.UI.BlendMode.Overlay);
    self.sash = sash;
    function sash.MouseEnter(s)
        s.mouseInside = true;
        s:SetBackground(imagePath .. "/grip.tga");
    end
    function sash.MouseLeave(s)
        s.mouseInside = false;
        if (not s.resizing) then
            s:SetBackground(nil);
        end
    end
    function sash.MouseDown(s)
        s.resizing = true;
        s.origin = {self:GetMousePosition()};
    end
    function sash.MouseUp(s)
        s.resizing = false;
        if (not s.mouseInside) then
            s:SetBackground(nil);
        end
    end
    function sash.MouseMove(s)
        if (s.resizing) then
            local x, y = self:GetMousePosition();
            if (self.orientation == Turbine.UI.Orientation.Vertical) then
                local deltaY = y - s.origin[2];
                self:SetSashPosition(self.sashPosition + (deltaY / self:GetHeight()));
            else -- Turbine.UI.Orientation.Horizontal
                local deltaX = x - s.origin[1];
                self:SetSashPosition(self.sashPosition + (deltaX / self:GetWidth()));
            end
            self.skipUpdates = 2;
            self:SetWantsUpdates(true);
            s.origin = {x, y};
        end
    end
    
    self.sashSize = 5;
    self.spacing = 2;
    self.sashPosition = 0.5;
end

function SplitControl:Update()
    if (self.skipUpdates > 0) then
        self.skipUpdates = self.skipUpdates - 1;
    else
        self:Layout(true);
        self:SetWantsUpdates(false);
        DoCallbacks(self, "SashPositionChanged");
    end
end

function SplitControl:SetWidth(width)
    Turbine.UI.Control.SetWidth(self, width);
    self:Layout(true);
end

function SplitControl:SetHeight(height)
    Turbine.UI.Control.SetHeight(self, height);
    self:Layout(true);
end

function SplitControl:SetSize(width, height)
    Turbine.UI.Control.SetSize(self, width, height);
    self:Layout(true);
end

function SplitControl:SetSashSize(sashSize)
    self.sashSize = sashSize;
    self:Layout(true);
end

function SplitControl:SetSpacing(spacing)
    self.spacing = spacing;
    self:Layout(true);
end

function SplitControl:SetSashPosition(pos)
    if (self.minSashPosition and (pos < self.minSashPosition)) then
        pos = self.minSashPosition;
    elseif (self.maxSashPosition and (pos > self.maxSashPosition)) then
        pos = self.maxSashPosition;
    end
    self.sashPosition = pos;
    self:Layout(false);
end

function SplitControl:GetSashPosition()
    return self.sashPosition;
end

function SplitControl:SetMaximumSashPosition(maxPos)
    self.maxSashPosition = maxPos;
    if (self.sashPosition > maxPos) then
        self.sashPosition = maxPos;
        self:Layout(true);
    end
end

function SplitControl:SetMinimumSashPosition(minPos)
    self.minSashPosition = minPos;
    if (self.sashPosition < minPos) then
        self.sashPosition = minPos;
        self:Layout(true);
    end
end

function SplitControl:Layout(resizeControls)
    local width, height = self:GetSize();
    if (self.orientation == Turbine.UI.Orientation.Vertical) then
        self.sash:SetSize(width, self.sashSize);
        local h = self.sashSize + 2 * self.spacing;
        local sashTop = height * self.sashPosition - math.floor((h + 1) / 2);
        self.sash:SetPosition(0, sashTop + self.spacing);
        if (resizeControls) then
            self.control1:SetSize(width, sashTop);
            self.control2:SetPosition(0, sashTop + h);
            self.control2:SetSize(width, height - (sashTop + h));
        end
    else -- Turbine.UI.Orientation.Horizontal
        self.sash:SetSize(self.sashSize, height);
        local w = self.sashSize + 2 * self.spacing;
        local sashLeft = width * self.sashPosition - math.floor((w + 1) / 2);
        self.sash:SetPosition(sashLeft + self.spacing, 0);
        if (resizeControls) then
            self.control1:SetSize(sashLeft, height);
            self.control2:SetPosition(sashLeft + w, 0);
            self.control2:SetSize(width - (sashLeft + w), height);
        end
    end
end
