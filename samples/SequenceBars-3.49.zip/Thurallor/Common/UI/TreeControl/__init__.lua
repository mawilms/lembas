import "Turbine";
import "Turbine.UI";
import "Turbine.UI.Lotro";

local importPath = getfenv(1)._.Name;
local commonPath = string.gsub(importPath, "%.UI%.TreeControl$", "");

--import (commonPath .. ".Turbine");
--import (commonPath .. ".Utils");
import (importPath .. ".TreeIcon");
import (importPath .. ".TreeControl");

Thurallor = Thurallor or {};
Thurallor.UI = Thurallor.UI or {};
Thurallor.UI.TreeControl = TreeControl;
