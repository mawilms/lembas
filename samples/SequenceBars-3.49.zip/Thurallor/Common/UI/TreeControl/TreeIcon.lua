TreeIcon = class(Turbine.UI.Control);

local importPath = getfenv(1)._.Name;
local imagePath = string.gsub(string.gsub(importPath, "%.TreeIcon$", ""), "%.", "/");

-- Modes:
local expand, collapse, leaf, branch, final = 1, 2, 3, 4, 5;

local expandIcon = Turbine.UI.Graphic(0x41007E27);
local collapseIcon = Turbine.UI.Graphic(0x41007E26);
local leafIcon = Turbine.UI.Graphic(imagePath .. "/leaf.tga");
local branchIcon = Turbine.UI.Graphic(imagePath .. "/branch.tga");
local finalIcon = Turbine.UI.Graphic(imagePath .. "/final.tga");

local stemDownIcon = Turbine.UI.Graphic(imagePath .. "/stem_down.tga");
local stemLeftIcon = Turbine.UI.Graphic(imagePath .. "/stem_left.tga");

function TreeIcon:Constructor(mode)
    Turbine.UI.Control.Constructor(self);
    self:SetSize(20, 16);
--self:SetBackColor(Turbine.UI.Color.Red);    
    
    self.icon = Turbine.UI.Control();
    self.icon:SetParent(self);
    self.icon:SetBlendMode(Turbine.UI.BlendMode.AlphaBlend);
    self.icon:SetWidth(20);
    self.icon.MouseClick = function()
        if (self.Click) then
            self.Click();
        end
    end   

    self.stemDown = Turbine.UI.Control();
    self.stemDown:SetParent(self);
    self.stemDown:SetBackground(stemDownIcon);
    self.stemDown:SetBlendMode(Turbine.UI.BlendMode.AlphaBlend);
    self.stemDown:SetWidth(20);

    self.stemLeft = Turbine.UI.Control();
    self.stemLeft:SetParent(self);
    self.stemLeft:SetBackground(stemLeftIcon);
    self.stemLeft:SetBlendMode(Turbine.UI.BlendMode.AlphaBlend);
    self.stemLeft:SetSize(2, 16);
    self.stemLeft:SetTop(2);
    
    self:SetMode(mode);
end

function TreeIcon:SetMode(mode, isChild)
    self.mode = mode;
    self.stemLeft:SetVisible(isChild);
    if (mode == expand) then
        self.icon:SetBackground(expandIcon);
        self.icon:SetPosition(2, 2);
        self.icon:SetSize(16, 16);
    elseif (mode == collapse) then
        self.icon:SetBackground(collapseIcon);
        self.icon:SetPosition(2, 2);
        self.icon:SetSize(16, 16);
    elseif (mode == leaf) then
        self.icon:SetBackground(leafIcon);
        self.icon:SetPosition(0, 2);
        self.icon:SetSize(20, 16);
    elseif (mode == branch) then
        self.icon:SetBackground(branchIcon);
        self.icon:SetPosition(0, -2);
        self.icon:SetSize(20, 24);
    elseif (mode == final) then
        self.icon:SetBackground(finalIcon);
        self.icon:SetPosition(0, -4);
        self.icon:SetSize(20, 28);
    end
    self:SizeChanged();
end

function TreeIcon:SizeChanged()
    -- Draw stems, if necessary
    if (self.icon) then
        local bottom = self.icon:GetTop() + self.icon:GetHeight();
        self.stemDown:SetTop(bottom);
        self.stemDown:SetHeight(math.max(0, self:GetHeight() - bottom));
        self.stemDown:SetVisible((self.mode == collapse) or (self.mode == branch));
    end
end
