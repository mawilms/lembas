import "Thurallor.SequenceBars"; 

--Puts("--------------------------------------");

math.randomseed(Turbine.Engine.GetGameTime());

theManager = Manager();
AddCallback(Turbine.Plugin, "Unload", function()
    theManager:Unload();
    Puts(L:GetText("/GoodbyeMessage"));
end);

local hello = L:GetText("/HelloMessage");
hello = string.gsub(hello, "<version>", plugin:GetVersion());
Turbine.Shell.WriteLine(hello);
_G.PutsPrefix = L:GetText("/PutsPrefix");

if (L:GetLanguage() == Turbine.Language.French) then
    Puts(L:GetText("/TranslationHelpWanted"));
end

sbCmd = Turbine.ShellCommand();
function sbCmd:Execute(cmd, args)
    if ((args == "help") or (not theManager:ShellCommand(cmd, args))) then
        Turbine.Shell.WriteLine(sbCmd.GetHelp());
    end
end
sbCmd.GetHelp = function()
    return L:GetText("/ShellCommand/LongHelp");
end
sbCmd.GetShortHelp = function()
    return L:GetText("/ShellCommand/ShortHelp");
end
Turbine.Shell.AddCommand(L:GetText("/ShellCommand/Command"), sbCmd);

--[[
    Turbine.Plugin.Load = function()
        import "Equendil.Utils";
        import "Equendil.LuaExplorer.Browser";
        function BrowseTable(name, t)
            local b = Equendil.LuaExplorer.Browser("Browsing: " .. name);
            b:Add(name, t, true, false);
            b:SetVisible( true );
            b:SetPosition(0, 0);
            b:Activate();
        end
        BrowseTable("_G", _G);
    end
]]

--[[
    -- Display a nice matte for screencaps of windows
    win = Turbine.UI.Lotro.Window();
    win:SetVisible(true);
    win:SetResizable(true);
    win:SetZOrder(-1);
    win.border = Turbine.UI.Control();
    win.border:SetParent(win);
    win.border:SetBackColor(Turbine.UI.Color(74/255, 79/255, 87/255))
    win.border:SetMouseVisible(false);
    win.bg = Turbine.UI.Control();
    win.bg:SetParent(win.border);
    win.bg:SetBackColor(Turbine.UI.Color.Black);
    win.bg:SetPosition(50, 50);
    win.bg:SetMouseVisible(false);
    function win:SizeChanged()
        local w, h = self:GetSize();
        win.border:SetSize(w, h);
        win.bg:SetSize(w - 100, h - 100);
    end
    win:SetSize(300, 300);
    CenterWindow(win);
]]

--[[
indent = ""; count = 0;
makeCmd = Turbine.ShellCommand();

function insertBuilder(bar, builder, list)
    local builders = {
        ["spear"] =         "0x7000E867",
        ["shield"] =        "0x7000ED0E",
        ["fist"] =          "0x7000EECF",
        ["spear-spear"] =   "0x7002850A",
        ["fist-fist"] =     "0x7002850C",
        ["fist-shield"] =   "0x7001509C",
        ["fist-spear"] =    "0x7001509A",
        ["shield-fist"] =   "0x7001509B",
        ["shield-shield"] = "0x7002850B",
        ["shield-spear"] =  "0x7001509D",
        ["spear-fist"] =    "0x70015098",
        ["spear-shield"] =  "0x70015099" 
    };
    table.insert(list, {
        class = "Turbine.UI.Lotro.Quickslot";
        type = Turbine.UI.Lotro.ShortcutType.Skill;
        Data = builders[builder]
    });
count = count + 1;
Puts(count .. ". " .. indent .. builder);
end
    
function insertIf(bar, mastery, list)
    local skillIcons = {
        ["spear-spear"] =   1091659088,
        ["fist-fist"] =     1091659089,
        ["fist-shield"] =   1091471243,
        ["fist-spear"] =    1091471240,
        ["shield-fist"] =   1091471231,
        ["shield-shield"] = 1091659090,
        ["shield-spear"] =  1091471250,
        ["spear-fist"] =    1091471238,
        ["spear-shield"] =  1091471246
    }
    table.insert(list, {
        class = "Turbine.UI.Control";
        type = "If";
        toolTip = "IF";
        automatic = true;
        background = "Thurallor/SequenceBars/Images/if.tga";
        condName = "SkillReady";
        condArgs = { skill = skillIcons[mastery] };
        condExpr = "local item = ...; return (item.bar.manager:SkillReady(<skill>));";
    });
count = count + 1;
Puts(count .. ". " .. indent .. "If skill ready: " .. mastery);
end

function insertElse(bar, list)
    table.insert(list, {
        class = "Turbine.UI.Control";
        type = "Else";
        toolTip = "ELSE";
        automatic = true;
        background = "Thurallor/SequenceBars/Images/else.tga";
    });
count = count + 1;
Puts(count .. ". " .. indent .. "Else");
end

function insertEnd(bar, list)
    table.insert(list, {
        class = "Turbine.UI.Control";
        type = "EndIf";
        toolTip = "END-IF";
        automatic = true;
        background = "Thurallor/SequenceBars/Images/end-if.tga";
    });
count = count + 1;
Puts(count .. ". " .. indent .. "End-If");
end

function insertDoGambit(bar, list)
    table.insert(list, {
        class = "Turbine.UI.Lotro.Quickslot";
        type = Turbine.UI.Lotro.ShortcutType.Skill;
        Data ="0x70015F56"
    });
count = count + 1;
Puts(count .. ". " .. indent .. "Do gambit");
end

function insertMastery(bar, builders, list)
    if (#builders == 1) then
        insertBuilder(bar, builders[1], list);
        return;
    end
    
    local mastery = builders[1] .. "-" .. builders[2];
    insertIf(bar, mastery, list);
    local prevIndent = indent;
    indent = indent .. "   ";
    insertBuilder(bar, mastery, list);
    if (#builders > 2) then
        local remainingBuilders = { builders[3]; builders[4]; builders[5] };
        insertMastery(bar, remainingBuilders, list);
    end
    indent = prevIndent;
    insertElse(bar, list);
    prevIndent = indent;
    indent = indent .. "   ";
    insertBuilder(bar, builders[1], list);
    if (#builders == 2) then
        insertBuilder(bar, builders[2], list);
    else
        local remainingBuilders = { builders[2]; builders[3]; builders[4]; builders[5] };
        insertMastery(bar, remainingBuilders, list);
    end
    indent = prevIndent;
    insertEnd(bar, list);
end

function makeCmd:Execute(cmd, args)
    local newBar = theManager:CreateBar();
    newBar:SetName(args);
    
    local builders = {};
    for arg in string.gmatch(args, "%S+") do
       table.insert(builders, arg);
    end

    local sequenceItemInfo = {};
    insertMastery(bar, builders, sequenceItemInfo);
    insertDoGambit(bar, sequenceItemInfo);
    
    newBar.settings.sequenceItemInfo = sequenceItemInfo;
    newBar:GetQuickSlots();
    newBar:FindHiddenSlots();
    newBar:Redraw();
    newBar:EditSequence();
end

Turbine.Shell.AddCommand("make", makeCmd);
Puts("Remember, you will need to manually tweak gambits with repeated masteries.");
]]

--[[
    local newBar = theManager:CreateBar();
    newBar:SetName("Emotes");
    
    local sequenceItemInfo = {};
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/agree" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/ahem" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/angry" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/assist" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/attack" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/away" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/beckon" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/beg" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/bio" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/blush" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/boo" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/bored" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/bother" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/bow" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/brb" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/bringiton" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/burp" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/bye" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/calm" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/challenge" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/charge" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/cheer" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/chickenchip" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/chickendrive" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/chickenfeather" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/chickenputt" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/chip" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/chuckle" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/clap" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/coinflip" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/confused" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/congratulate" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/cough" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/counterfeit" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/cower" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/crazy" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/cry" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/curtsey" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance1" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance2" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance3" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance_dwarf" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance_dwarf2" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance_elf" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance_elf2" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance_hobbit" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance_hobbit2" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance_jig" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance_man" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance_man2" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dance_man3" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dowse" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dream" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/drink" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/drinkboot" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/drive" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/drool" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/drunk" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/dustoff" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/eat" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/faint" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/feather" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/fidget" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/fight" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/firebreath" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/fishslap" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/flex" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/flip" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/flirt" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/followme" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/giggle" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/groundroll" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/grumble" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/hail" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/handstand" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/heave" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/heropose" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/howl" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/hug" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/impatient" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/innocent" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/inspectgem" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/jazzhands" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/jjacks" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/juggle" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/jump" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/kiss" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/kneel" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/laugh" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/liedown" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/lol" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/look" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/lookaround" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/meditate" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mock" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mood_angry" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mood_apprehensive" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mood_calm" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mood_confused" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mood_fearful" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mood_happy" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mood_mischievous" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mood_sad" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mood_sleepy" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mood_solemn" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mood_surprised" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mountbow" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mountkick" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mountrearup" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mourn" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/mumble" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/munch" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/no" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/nothing" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/oop" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/pan" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/paper" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/pat" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/pick" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/point" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/poke" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/pose" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/pushups" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/putt" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/ready" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/resist" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/rest" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/rich" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/roar" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/rude" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/sad" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/salute" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/scissor" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/scold" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/scratch" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/shakefist" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/shiver" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/shrug" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/sigh" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/sing" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/sit" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/slap" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/smackhead" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/smoke" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/smoke1" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/sneeze" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/snowwizard" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/sorry" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/spin" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/stare" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/stone" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/story" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/stretch" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/succumb" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/surrender" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/sweat" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/swordsalute" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/talk" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/tantrum" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/tear" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/thank" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/think" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/tickle" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/toast" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/wait" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/warmhands" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/wave" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/whippitydo" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/whistle" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/wince" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/wink" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/wipesweat" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/yawn" });
    table.insert(sequenceItemInfo, { class = "Turbine.UI.Lotro.Quickslot"; type = Turbine.UI.Lotro.ShortcutType.Alias; Data = "/yes" });
    
    newBar.settings.sequenceItemInfo = sequenceItemInfo;
    newBar:GetQuickSlots();
    newBar:FindHiddenSlots();
    newBar:Redraw();
    newBar:EditSequence();
]]


