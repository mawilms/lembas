resources = {
	Cursor = {
        ["Disabled"]        = { },
        ["LargeSquareGlow"] = { Background = "Thurallor/SequenceBars/Images/cursor_big.tga"; BackColorBlendMode = Turbine.UI.BlendMode.Color; ApplyColor = true; xOffset = 1, yOffset = 1; ZOrder = -1 },
        ["SmallRoundGlow"]  = { Background = 0x4110C3CE; BackColorBlendMode = Turbine.UI.BlendMode.Color; ApplyColor = true; xOffset = 1, yOffset = 1; ZOrder = -1 },
        ["SmallSquareGlow"] = { Background = "Thurallor/SequenceBars/Images/cursor_small.tga"; BackColorBlendMode = Turbine.UI.BlendMode.Color; ApplyColor = true; xOffset = 1, yOffset = 1; ZOrder = -1 },
        ["LargeRoundGlow"]  = { Background = 0x4110C3CA; BackColorBlendMode = Turbine.UI.BlendMode.Color; ApplyColor = true; xOffset = 1, yOffset = 1; ZOrder = -1 },
        ["HugeOrb"]         = { Background = 0x41000066; BackColorBlendMode = Turbine.UI.BlendMode.Color; ApplyColor = true; ZOrder = -1  },
        ["Orb"]             = { Background = 0x41000067; BackColorBlendMode = Turbine.UI.BlendMode.Color; ApplyColor = true; xOffset = 0, yOffset = 1; ZOrder = -1  },
        ["GlowingFrame"]    = { Background = 0x41102B6B; xOffset = 1, yOffset = 2; BackColorBlendMode = Turbine.UI.BlendMode.Color; ApplyColor = true; ZOrder = -1 },
        ["OrnateFrame"]     = { Background = 0x4112E6CF; ZOrder = -1 , xOffset = 1, yOffset = 1 },
        ["OrnateFrame2"]    = { Background = 0x410D7BC2; ZOrder = -1 , xOffset = 1, yOffset = 1 },
        ["OrnateFrame3"]    = { Background = 0x410DE20C; ZOrder = -1 , xOffset = 1, yOffset = 1 },
        ["GoldFrame"]       = { Background = 0x4112E6CE; xOffset = 2, yOffset = 2; ZOrder = -1 },
        ["MetalFrame1" ]    = { Background = 0x410E8AA1; xOffset = 1, yOffset = 1; ZOrder = -1 },
        ["MetalFrame2" ]    = { Background = 0x4112AC40; xOffset = 1, yOffset = 1; ZOrder = -1 },
        ["MetalFrame3" ]    = { Background = 0x410EA715; ZOrder = -1; xOffset = 0; yOffset = 0 },
        ["MetalFrame4" ]    = { Background = 0x410EA716; ZOrder = -1; xOffset = 1; yOffset = 0 },
        ["MediumRoundGlow"] = { Background = 0x4100156F; BackColorBlendMode = Turbine.UI.BlendMode.Color; ApplyColor = true; xOffset = 1, yOffset = 1; ZOrder = -1 },
        ["WireFrame"]       = { Background = 0x411386AF; BlendMode = Turbine.UI.BlendMode.AlphaBlend; xOffset = 1, yOffset = 1; ZOrder = 1; }
    };
    Icon = {
        ["Expand"] = 0x41007E27;
        ["Collapse"] = 0x41007E26;
        ["DisabledVisible"] = 0x410DD515;
        ["EnabledInvisible"] = 0x410DD516;
        ["EnabledVisible"] = 0x410DD517;
        ["DisabledInvisible"] = 0x410DD518;
        ["UnequipBack"] = "Thurallor/SequenceBars/Images/remove_back.tga";
        ["UnequipBoots"] = "Thurallor/SequenceBars/Images/remove_boots.tga";
        ["UnequipBracelet1"] = "Thurallor/SequenceBars/Images/remove_bracelet1.tga";
        ["UnequipBracelet2"] = "Thurallor/SequenceBars/Images/remove_bracelet2.tga";
        ["UnequipBridle"] = "Thurallor/SequenceBars/Images/remove_bridle.tga";
        ["UnequipChest"] = "Thurallor/SequenceBars/Images/remove_chest.tga";
        ["UnequipClass"] = "Thurallor/SequenceBars/Images/remove_class.tga";
        ["UnequipCraftTool"] = "Thurallor/SequenceBars/Images/remove_craft_tool.tga";
        ["UnequipEarring1"] = "Thurallor/SequenceBars/Images/remove_earring1.tga";
        ["UnequipEarring2"] = "Thurallor/SequenceBars/Images/remove_earring2.tga";
        ["UnequipGloves"] = "Thurallor/SequenceBars/Images/remove_gloves.tga";
        ["UnequipHead"] = "Thurallor/SequenceBars/Images/remove_head.tga";
        ["UnequipInstrument"] = "Thurallor/SequenceBars/Images/remove_ranged_weapon.tga";
        ["UnequipLegs"] = "Thurallor/SequenceBars/Images/remove_legs.tga";
        ["UnequipNecklace"] = "Thurallor/SequenceBars/Images/remove_necklace.tga";
        ["UnequipPocket"] = "Thurallor/SequenceBars/Images/remove_pocket.tga";
        ["UnequipPrimaryWeapon"] = "Thurallor/SequenceBars/Images/remove_primary_weapon.tga";
        ["UnequipRangedWeapon"] = "Thurallor/SequenceBars/Images/remove_ranged_weapon.tga";
        ["UnequipRing1"] = "Thurallor/SequenceBars/Images/remove_ring1.tga";
        ["UnequipRing2"] = "Thurallor/SequenceBars/Images/remove_ring2.tga";
        ["UnequipSecondaryWeapon"] = "Thurallor/SequenceBars/Images/remove_shield.tga";
        ["UnequipShield"] = "Thurallor/SequenceBars/Images/remove_shield.tga";
        ["UnequipShoulder"] = "Thurallor/SequenceBars/Images/remove_shoulder.tga";
        ["StopAnimating"] = "Thurallor/SequenceBars/Images/stopsign.tga";
        ["GenerateEvent"] = "Thurallor/SequenceBars/Images/event_icon.tga";
        ["SetUnequipDestination"] = "Thurallor/SequenceBars/Images/bag_slot.tga";
        ["Highlight"] = 0x41000221;
        ["Caret"] = "Thurallor/SequenceBars/Images/caret.tga";
        ["DragFail"] = "Thurallor/SequenceBars/Images/dragfail.tga";
        ["BlackIcon"] = "Thurallor/SequenceBars/Images/black_icon.tga";
        ["If"] = "Thurallor/SequenceBars/Images/if.tga";
        ["Else"] = "Thurallor/SequenceBars/Images/else.tga";
        ["EndIf"] = "Thurallor/SequenceBars/Images/end-if.tga";
        ["Include"] = "Thurallor/SequenceBars/Images/include.tga";
        ["LuaScript"] = "Thurallor/SequenceBars/Images/lua.tga";
        ["Delay"] = "Thurallor/SequenceBars/Images/hourglass.tga";
        ["Clock"] = "Thurallor/SequenceBars/Images/clock.tga";
        ["Grid"] = "Thurallor/SequenceBars/Images/grid.tga";
        ["Hourglass"] = 0x41007E2F;
        ["CoolDownStart"] = 0x41007E70;
        ["CoolDownEnd"] = 0x41007E35;
        ["Reset"] = "Thurallor/SequenceBars/Images/reset.tga";
        ["Play"] = "Thurallor/SequenceBars/Images/play.tga";
        ["Pause"] = "Thurallor/SequenceBars/Images/pause.tga";
        ["SelectTarget"] = "Thurallor/SequenceBars/Images/select_target.tga";
        ["SelectTargetUnknown"] = "Thurallor/SequenceBars/Images/select_target_unknown.tga";
        ["SelectTargetKnown"] = "Thurallor/SequenceBars/Images/select_target_known.tga";
        ["SaveTarget"] = "Thurallor/SequenceBars/Images/save_target.tga";
    };
    BlankIcons = {
        0x41000001, 0x41000002, 0x41000003, 0x41000004, 0x41000005, 0x41000E44,
        0x41001430, 0x41019972, 0x4101DBB0, 0x410D6D3D, 0x410D6D3E, 0x410D6D3F,
        0x410D6D40, 0x410D6D41, 0x410D6D42, 0x410D709A, 0x410D70A1, 0x410DCF2F,
        0x410DD1B3, 0x410E8E4A, 0x410E8E58, 0x410E8E59, 0x410E9B96, 0x410E9B98,
        0x410E9B99, 0x41105CB5, 0x4111CE23, 0x4111CE24, 0x4111CE25, 0x4111CE26,
        0x4111CE27, 0x411232B0
    };
    Gears = "Thurallor/SequenceBars/Images/gears.tga";
};

-- We want to create a graphic object only once for each resource ID:
local cache = {};
local function GetCachedGraphic(id)
    if (type(id) == "string") then
        if (not cache[id]) then
            cache[id] = Turbine.UI.Graphic(id);
        end
        return cache[id];
    else
        return id;
    end
end

-- Add a cache-check to each SetBackground call for the types of controls that SequenceBars uses:
local Control_SetBackground = Turbine.UI.Control.SetBackground;
function Turbine.UI.Control:SetBackground(id)
    Control_SetBackground(self, GetCachedGraphic(id));
end

local Window_SetBackground = Turbine.UI.Window.SetBackground;
function Turbine.UI.Window:SetBackground(id)
    Window_SetBackground(self, GetCachedGraphic(id));
end

local Label_SetBackground = Turbine.UI.Label.SetBackground;
function Turbine.UI.Label:SetBackground(id)
    Label_SetBackground(self, GetCachedGraphic(id));
end

local EntityControl_SetBackground = Turbine.UI.Lotro.EntityControl.SetBackground;
function Turbine.UI.Lotro.EntityControl:SetBackground(id)
    EntityControl_SetBackground(self, GetCachedGraphic(id));
end
