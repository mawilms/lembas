CaptionEditor = class(Turbine.UI.Lotro.Window);

function CaptionEditor:Constructor(title, target, startingWidth, startingHeight, startingText)
    Turbine.UI.Lotro.Window.Constructor(self);
    
    self.target = target;
    self:SetText(L:GetText("/CaptionEditor/Title/" .. title));
    self:SetZOrder(2147483647 - 5);
    self:SetVisible(true);

    local minimumWidth, minimumHeight = 250, 130;
    local minCaptionWidth, minCaptionHeight = 32, 32;
    self.xMargin = minimumWidth - minCaptionWidth;
    self.yMargin = minimumHeight - minCaptionHeight;
    self:SetMinimumWidth(minimumWidth);
    self:SetMinimumHeight(minimumHeight);
    self:SetWidth(startingWidth + self.xMargin);
    self:SetHeight(startingHeight + self.yMargin);
    self:SetLeft(Turbine.UI.Display.GetMouseX() - math.floor(self:GetWidth() / 2));
    self:SetTop(Turbine.UI.Display.GetMouseY() - math.floor(self:GetHeight() / 2));
    self:SetResizable(true);

    self.textBoxBorder = Turbine.UI.Lotro.TextBox();
    self.textBoxBorder:SetPosition(math.floor(self.xMargin / 2) - 3, math.floor(self.yMargin / 2) - 3);
    self.textBoxBorder:SetParent(self);
    self.textBoxBorder:SetEnabled(false);
    
    self.textBox = Turbine.UI.TextBox();
    self.textBox:SetPosition(math.floor(self.xMargin / 2), math.floor(self.yMargin / 2));
    self.textBox:SetParent(self);
    self.textBox:SetSelectable(true);
    self.textBox:SetText(startingText);
    self.textBox.TextChanged = function(sender, args)
        local text = sender:GetText();
        -- Remove carriage returns
        local stripped = string.gsub(text, "\n", "");
        if (stripped ~= text) then
            sender:SetText(stripped);
            text = stripped;
        else
            stripped = nil;
        end
        self.avoidRecursion = true;
        target:SetName(text);
        self.avoidRecursion = false;
        if (stripped) then
            self:Close();
        end
    end

    local prevContext = L:SetContext("/CaptionEditor");
    
    self.buttonWidth = 90;
    self.buttonSpacingX, self.buttonSpacingY = 10, 20
    self.fontButton = Turbine.UI.Lotro.Button();
    self.fontButton:SetParent(self);
    self.fontButton:SetFont(Turbine.UI.Lotro.Font.TrajanPro13);
    self.fontButton:SetText(L:GetText("Font"));
    self.fontButton:SetWidth(self.buttonWidth);
    self.fontButton:SetEnabled(target.SetCaptionFont ~= nil);
    self.fontButton.Click = function()
        self:ShowFontMenu();
    end

    self.colorButton = Turbine.UI.Lotro.Button();
    self.colorButton:SetParent(self);
    self.colorButton:SetFont(Turbine.UI.Lotro.Font.TrajanPro13);
    self.colorButton:SetText(L:GetText("Color"));
    self.colorButton:SetWidth(self.buttonWidth);
    self.colorButton.Click = function()
        self.target:EditColor();
    end
    
    AddCallback(self, "SizeChanged", function()
        local width = self:GetWidth();
        local height = self:GetHeight();
        self.target:SetCaptionSize(width - self.xMargin, height - self.yMargin);
        self.fontButton:SetLeft(math.floor(width / 2 + self.buttonSpacingX / 2));
        self.colorButton:SetLeft(math.floor(width / 2 - self.buttonSpacingX / 2 - self.buttonWidth));
        local top = height - self.buttonSpacingY - self.fontButton:GetHeight();
        self.fontButton:SetTop(top);
        self.colorButton:SetTop(top);
    end);
    DoCallbacks(self, "SizeChanged");
    self.textBox:SelectAll();
end

function CaptionEditor:WantsCaptionUpdates()
    return (not self.avoidRecursion);
end

function CaptionEditor:GetTextBox()
    return self.textBox;
end

function CaptionEditor:Redraw()
    self.textBoxBorder:SetWidth(self.textBox:GetWidth() + 6);
    self.textBoxBorder:SetHeight(self.textBox:GetHeight() + 6);
end

function CaptionEditor:ShowFontMenu()
    self.fontMenu = Turbine.UI.ContextMenu();
    
    local selectedFont = self.textBox:GetFont();
    local fontNames = { };
    local fontSizes = { };
    for fontName, font in pairs(Turbine.UI.Lotro.Font) do
        if ((type(font) == "number") and (fontName ~= "Undefined") and (string.sub(fontName, 1, 1) ~= "_")) then
            local typeFace, size = string.match(fontName, "^([^0-9]+)([0-9]+)$");
            if (fontSizes[typeFace] == nil) then
                fontSizes[typeFace] = { };
                table.insert(fontNames, typeFace);
            end
            table.insert(fontSizes[typeFace], size);
        end
    end
    table.sort(fontNames);
    for f = 1, #fontNames, 1 do
        local fontName = fontNames[f];
        local item = Turbine.UI.MenuItem(fontName, true, false);
        self.fontMenu:GetItems():Add(item);
        local sizes = fontSizes[fontName];
        table.sort(sizes);
        for s = 1, #sizes, 1 do
            local fontSize = sizes[s];
            local font = Turbine.UI.Lotro.Font[fontName .. fontSize];
            local subItem = Turbine.UI.MenuItem(fontSize, true, font == selectedFont);
            item:GetItems():Add(subItem);
            subItem.Click = function()
                self.target:SetCaptionFont(font);
            end
        end
    end
    
    self.fontMenu:ShowMenu();
end
