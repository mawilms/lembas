-- Shorthand for languages
local en = Turbine.Language.English;
local fr = Turbine.Language.French;
local de = Turbine.Language.German;
local ru = Turbine.Language.Russian;
local pt = Turbine.Language.Portuguese;

local text = {};

-- Hello message that appears when plugin is loaded
text.HelloMessage = {
    [en] = "<u><rgb=#DAA520>SequenceBars v<version>, by Thurallor</rgb></u>";
    [de] = "<u><rgb=#DAA520>Sequenzleisten v<version> von Thurallor</rgb></u>";
    [fr] = "<u><rgb=#DAA520>SequenceBars v<version>, par Thurallor</rgb></u>";
    [pt] = "<u><rgb=#DAA520>SequenceBars v<version>, por Thurallor</rgb></u>";
    [ru] = "<u><rgb=#DAA520>SequenceBars v<version> от Thurallor</rgb></u>"
};
text.PutsPrefix = {
    [en] = "<rgb=#DAA520>SequenceBars:</rgb> ";
    [de] = "<rgb=#DAA520>Sequenzleisten:</rgb> ";
    [fr] = "<rgb=#DAA520>SequenceBars :</rgb> ";
    [pt] = "<rgb=#DAA520>SequenceBars:</rgb> ";
    [ru] = "<rgb=#DAA520>SequenceBars:</rgb> ";
};

text.TranslationHelpWanted = {
    [en] = "Some items (denoted by †) have been machine-translated.  If you can help with translations, please contact Thurallor.";
    [de] = "Einige Elemente (gekennzeichnet durch †) wurden maschinell übersetzt.  Wenn Sie uns bei Übersetzungen helfen können, wenden Sie sich bitte an Thurallor.";
    [fr] = "Certains éléments (marqués par †) ont été traduits par machine.  Si vous pouvez nous aider avec les traductions, veuillez contacter Thurallor.";
    [pt] = "Alguns itens (indicados por †) foram traduzidos à máquina.  Para ajudar na tradução, entre em contato com Thurallor.";
    [ru] = "Russian translation help needed.  Please contact Thurallor."
};
text.GoodbyeMessage = {
    [en] = "unloaded";
    [de] = "entladen";
    [fr] = "déchargé";
    [pt] = "descarregado";
    [ru] = "?"
};


-- Verbose help windows
text.Help = {};


-- Chat command for controlling SequenceBars plugin
text.ShellCommand = {};
text.ShellCommand.Command = {
    [en] = "sb";
    [de] = "sb";
    [fr] = "sb";
    [pt] = "sb";
    [ru] = "sb"
};
text.ShellCommand.Options = {
    [en] = "options";
    [de] = "optionen";
    [fr] = "options";
    [pt] = "opções";
    [ru] = "options"
};
text.ShellCommand.Event = {
    [en] = "event";
    [de] = "ereignis";
    [fr] = "évènement";
    [pt] = "evento";
    [ru] = "event"
};
text.ShellCommand.Events = {
    [en] = "events";
    [de] = "ereignisse";
    [fr] = "évènements";
    [pt] = "eventos";
    [ru] = "events"
};
text.ShellCommand.Sort = {
    [en] = "sort";
    [de] = "sortieren";
    [fr] = "trier";
    [pt] = "ordenar";
    [ru] = "sort"
};
text.ShellCommand.ShortHelp = {
    [en] = "Command for controlling the SequenceBars plugin.";
    [de] = "Befehl zum Kontrollieren des Sequenzleisten Plugins.";
    [fr] = "Commande pour controler le plugin SequenceBars.";
    [pt] = "Comando para controlar o plugin SequenceBars.";
    [ru] = "Команда для управления плагином SequenceBars."
};
text.ShellCommand.LongHelp = {
    [en] = "SequenceBars commands:\n" ..
           "    /sb options : Opens the main options panel.\n" ..
           "    /sb event <event> : Triggers the specified user-defined <event>.\n" ..
           "    /sb events : Lists the currently-defined events (if any).\n" ..
           "    /sb sort <slots> : Sorts the items in the specified inventory bag slots.";
    [de] = "Sequenzleisten Chatbefehle:\n" ..
           "    /sb optionen : Öffnet das Hauptmenü.\n" ..
           "    /sb ereignis <ereignisname> : Löst das benutzerdefinierte Ereignis <ereignisname> aus.\n" ..
           "    /sb ereignisse : Listet alle aktuell definierten Ereignisse auf (wenn vorhanden).\n" ..
           "    /sb sortieren <slots> : Sortiert die Gegenstände in die spezifierten Inventarfelder ein.";
    [fr] = "Commandes pour SequenceBars:\n" ..
           "    /sb options : Ouvre le panneau principal d'options.\n" ..
           "    /sb évènement <évènement> : Déclenche l' <évènement> indiqué par l'utilisateur.\n" ..
           "    /sb évènements : Liste les évènements courramment définis (le cas échéant).\n" ..
		   "    /sb trier <emplacement> : Trie les objets pour les déplacer dans le bon emplacement d'inventaire.";
    [pt] = "Opções do SequenceBars:\n" ..
           "    /sb opcoes : Abre o painel principal de opções.\n" ..
           "    /sb evento <event> : Dispara o <event> definido pelo usuário especificado.\n" ..
           "    /sb eventos : Lista os eventos atualmente definidos (se houver).\n" ..
           "    /sb ordenar <slots> : Ordena os itens nos slots das bolsas do inventário.";
    [ru] = "Команды плагина SequenceBars:\n" ..
           "    /sb options : Открыть настройки плагина.\n" ..
           "    /sb event <event> : Вызвать пользовательское событие <event>.\n" ..
           "    /sb events : Показать список пользовательских событий (если есть).\n" ..
           "    /sb sort <slots> : Sorts the items in the specified inventory bag slots.†";
};
text.ItemMoved = {
	[en] = "Item moved from bag slot <source> to bag slot <destination>.";
	[de] = "Gegenstand von Inventarfeld <source> zu Inventarfeld <destination> bewegt.";
	[fr] = "Objet déplacé de l'emplacement du sac <source> à l'emplacement du sac <destination>.";
    [pt] = "Item movido do slot da bolsa <source> para o slot da bolsa <destination>";
	[ru] = "Ячейка сумки предмета изменилась с <source> на <destination>.";
};
text.BagsFull = {
	[en] = "Your bags are full!";
	[de] = "Deine Taschen sind voll!";
	[fr] = "Vos sacs sont pleins!";
    [pt] = "Suas bolsas estão cheias!";
	[ru] = "Ваши сумки полны!";
};
text.BagSlotsFull = {
	[en] = "Your bags (slots <slots>) are full!";
	[de] = "Deine Taschen (Felder <slots>) sind voll!";
	[fr] = "Vos sacs (emplacements <slots>) sont pleins!";
    [pt] = "Suas bolsas (slots <slots>) estão cheios!";
	[ru] = "Ваши сумки (Ячеек <slots>) полны!";
};


-- Short instructions appearing in the Options menu in the Plugin Manager
text.PluginManager = {};
text.PluginManager.OptionsTab = {};
text.PluginManager.OptionsTab.Instructions = {
    [en] = "Bars and groups are listed below. Right-click for options.";
    [de] = "Leisten und Gruppen sind unten aufgeführt. Rechts-Klick für Optionen.";
    [fr] = "Les barres et les groupes sont répertoriées ci dessous. Clic-droit pour les options.";
    [pt] = "Barras e grupos estão listados abaixo. Clique com botão direito para ver as opções.";
    [ru] = "Панели и группы. Щелкните правой кнопкой, чтобы показать меню."
};
text.PluginManager.OptionsTab.GlobalSettings = {
    [en] = "Global settings";
    [de] = "Globale Einstellungen";
    [fr] = "Paramètres globaux";
    [pt] = "Configurações globais";
    [ru] = "Общие настройки"
};
text.PluginManager.OptionsTab.GlobalSettingsTabWidth = {
    [en] = 150;
    [de] = 200;
    [fr] = 180;
    [pt] = 190;
    [ru] = 160
};
text.PluginManager.OptionsTab.GlobalSettingsTab = {};
text.PluginManager.OptionsTab.GlobalSettingsTab.Language = {
    [en] = "Language:";
    [de] = "Sprache:";
    [fr] = "Langue :";
    [pt] = "Língua:";
    [ru] = "Язык:"
};
text.PluginManager.OptionsTab.GlobalSettingsTab.LanguageMenu = {};
text.PluginManager.OptionsTab.GlobalSettingsTab.LanguageMenu.English = {
    [en] = "English";
    [de] = "English (Englisch)";
    [fr] = "English (Anglais)";
    [pt] = "English (Inglês)";
    [ru] = "English (Английский)"
};
text.PluginManager.OptionsTab.GlobalSettingsTab.LanguageMenu.German = {
    [en] = "Deutsch (German)";
    [de] = "Deutsch";
    [fr] = "Deutsch (Allemand)";
    [pt] = "Deutsch (Alemão)";
    [ru] = "Deutsch (Немецкий)"
};
text.PluginManager.OptionsTab.GlobalSettingsTab.LanguageMenu.French = {
    [en] = "Français (French)";
    [de] = "Français (Französisch)";
    [fr] = "Français";
    [pt] = "Français (Francês)";
    [ru] = "Français (Французский)"
};
text.PluginManager.OptionsTab.GlobalSettingsTab.LanguageMenu.Portuguese = {
    [en] = "Português (Portuguese)";
    [de] = "Português (Portugiesisch)";
    [fr] = "Português (Portugais)";
    [pt] = "Português";
    [ru] = "Português (Португальский)"
};
text.PluginManager.OptionsTab.GlobalSettingsTab.LanguageMenu.Russian = {
    [en] = "Русский (Russian)";
    [de] = "Русский (Russisch)";
    [fr] = "Русский (Russie)";
    [pt] = "Русский (Russo)";
    [ru] = "Русский"
};
text.PluginManager.OptionsTab.GlobalSettingsTab.SnapToGrid = {
    [en] = "Snap to Grid";
    [de] = "Am Raster ausrichten";
    [fr] = "Coller à la grille";
    [pt] = "Ajustar a grade";
    [ru] = "Привязать к сетке"
};
text.PluginManager.OptionsTab.GlobalSettingsTab.UiScale = {
    [en] = "Scale";
    [de] = "Maßstab";
    [fr] = "Echelle";
    [pt] = "Tamanho";
    [ru] = "Масштаб"
};
text.PluginManager.OptionsTab.GlobalSettingsTab.UiOpacity = {
    [en] = "Opacity";
    [de] = "Deckkraft";
    [fr] = "Opacité";
    [pt] = "Opacidade";
    [ru] = "Непрозрачность"
};
text.PluginManager.OptionsTab.Directory = {
    [en] = "Directory";
    [de] = "Verzeichnis";
    [fr] = "Répertoire";
    [pt] = "Diretório";
    [ru] = "Список панелей"
};
text.PluginManager.OptionsTab.DirectoryTabWidth = {
    [en] = 115;
    [de] = 130;
    [fr] = 115;
    [pt] = 115;
    [ru] = 145
};
text.PluginManager.OptionsTab.Show = {
    [en] = "Show";
    [de] = "Zeigen";
    [fr] = "Montrer";
    [pt] = "Mostrar";
    [ru] = "Показать"
};
text.PluginManager.OptionsTab.Hide = {
    [en] = "Hide";
    [de] = "Ausblenden";
    [fr] = "Cacher";
    [pt] = "Esconder";
    [ru] = "Скрыть"
};
text.PluginManager.OptionsTab.ShowHideButtonWidth = {
    [en] = 50;
    [de] = 80;
    [fr] = 75;
    [pt] = 75;
    [ru] = 75
};

-- Names that are assigned when something is created
text.Default = {};
text.Default.BarName = {
    [en] = "New bar";
    [de] = "Neue Leiste";
    [fr] = "Nouvelle barre";
    [pt] = "Nova Barra";
    [ru] = "Новая панель"
};
text.Default.GroupName =  {
    [en] = "New group";
    [de] = "Neue Gruppe";
    [fr] = "Nouveau groupe";
    [pt] = "Nome do Grupo";
    [ru] = "Новая группа"
};
text.Default.GlobalName = {
    [en] = "<name>'s Sequence Bars";
    [de] = "<name>s Sequenzleisten";
    [fr] = "Sequence Bars de <name>";
    [pt] = "Sequence Bars de <name>";
    [ru] = "Панели персонажа <name>"
};

-- Global context menu items
text.GlobalMenu = {};
text.GlobalMenu.HideAll = {
    [en] = "Hide all";
    [de] = "Alle ausblenden";
    [fr] = "Cacher tout";
    [pt] = "Esconder tudo";
    [ru] = "Скрыть все"
};
text.GlobalMenu.CreateNewGroup = {
    [en] = "Create new group";
    [de] = "Neue Gruppe erstellen";
    [fr] = "Créer un nouveau groupe";
    [pt] = "Criar novo grupo";
    [ru] = "Создать новую группу"
};
text.GlobalMenu.GlobalSettings = {
    [en] = "Global settings...";
    [de] = "Globale Einstellungen...";
    [fr] = "Paramètres globaux...";
    [pt] = "Confiurações Globais";
    [ru] = "Общие настройки..."
};
text.GlobalMenu.Undelete = {
    [en] = "Undelete";
    [de] = "Wiederherstellen";
    [fr] = "Annuler effacer";
    [pt] = "Desfazer Exclusão";
    [ru] = "Отменить удаление"
};
text.GlobalMenu.UndeleteMenu = {};
text.GlobalMenu.UndeleteMenu.GroupName = {
    [en] = "''<name>''";
    [de] = "«<name>»";
    [fr] = "''<name>''";
    [pt] = "«<name>»";
    [ru] = "''<name>''"
};
text.GlobalMenu.EmptyTrash = {
    [en] = "Empty trash";
    [de] = "Papierkorb leeren";
    [fr] = "Vider la corbeille";
    [pt] = "Esvaziar lixeira";
    [ru] = "Очистить удаленное"
};

-- Group context menu items
text.GroupMenu = {};
text.GroupMenu.Hide = {
    [en] = "Hide group";
    [de] = "Gruppe ausblenden";
    [fr] = "Cacher le groupe";
    [pt] = "Esconder grupo";
    [ru] = "Скрыть группу"
};
text.GroupMenu.CloneGroup = {
    [en] = "Clone group";
    [de] = "Gruppe klonen";
    [fr] = "Cloner le groupe";
    [pt] = "Clonar grupo";
    [ru] = "Скопировать группу"
};
text.GroupMenu.DeleteGroup = {
    [en] = "Delete group";
    [de] = "Gruppe löschen";
    [fr] = "Effacer le groupe";
    [pt] = "Excluir grupo";
    [ru] = "Удалить группу"
};
text.GroupMenu.ExportGroup = {
    [en] = "Export group...";
    [de] = "Gruppe exportieren...";
    [fr] = "Exporter le groupe...";
    [pt] = "Exportar grupo...";
    [ru] = "Экспортировать группу..."
};
text.GroupMenu.Import = {
    [en] = "Import...";
    [de] = "Importieren...";
    [fr] = "Importer...";
    [pt] = "Importar...";
    [ru] = "Импортировать..."
};
text.GroupMenu.Undelete = {
    [en] = "Undelete";
    [de] = "Wiederherstellen";
    [fr] = "Annuler effacer";
    [pt] = "Desfazer Exclusão";
    [ru] = "Отменить удаление"
};
text.GroupMenu.UndeleteMenu = {};
text.GroupMenu.UndeleteMenu.BarName = {
    [en] = "‘‘<name>’’ (Bar)";
    [de] = "‚‚<name>‘‘ (Leiste)";
    [fr] = "« <nom> » (Barre)";
    [pt] = "«<name>» (Barra)";
    [ru] = "«<name>» (панель)"
};
text.GroupMenu.UndeleteMenu.GroupName = {
    [en] = "‘‘<name>’’ (Group)";
    [de] = "‚‚<name>‘‘ (Gruppe)";
    [fr] = "« <nom> » (Groupe)";
    [pt] = "«<name>» (Grupo)";
    [ru] = "«<name>» (группа)"
};
text.GroupMenu.CreateNewBar = {
    [en] = "Create new bar";
    [de] = "Neue Leiste erstellen";
    [fr] = "Créer une nouvelle barre";
    [pt] = "Criar nova barra";
    [ru] = "Создать новую панель"
};
text.GroupMenu.CreateNewSubgroup = {
    [en] = "Create new group";
    [de] = "Neue Gruppe erstellen";
    [fr] = "Créer un nouveau groupe";
    [pt] = "Criar novo grupo";
    [ru] = "Создать новую группу";
};
text.GroupMenu.ArrangeBars = {
    [en] = "Arrange bars";
    [de] = "Leisten anordnen";
    [fr] = "Arranger les barres";
    [pt] = "Organizar barras";
    [ru] = "Расположить панели"
};
text.GroupMenu.GroupEventBehaviors = {
    [en] = "Group event behaviours";
    [de] = "Verhalten bei Gruppenereignissen";
    [fr] = "Comportement lors des évènements";
    [pt] = "Comportamento de eventos de grupo";
    [ru] = "Реакция на события (группа)"
};
text.GroupMenu.GlobalEventBehaviors = {
    [en] = "Global event behaviours";
    [de] = "Verhalten bei globalen Ereignissen";
    [fr] = "Comportement lors des évènements";
    [pt] = "Comportamento de eventos globais";
    [ru] = "Реакция на события (группа)"
};
text.GroupMenu.ArrangeBarsMenu = {};
text.GroupMenu.ArrangeBarsMenu.AlignVertically = {
    [en] = "Align vertically";
    [de] = "Vertikal ausrichten";
    [fr] = "Aligner verticalement";
    [pt] = "Alinhar verticalmente";
    [ru] = "Выровнять по вертикали"
};
text.GroupMenu.ArrangeBarsMenu.AlignVerticallyMenu = {};
text.GroupMenu.ArrangeBarsMenu.AlignVerticallyMenu.Tops = {
    [en] = "Tops";
    [de] = "Oberseiten";
    [fr] = "Hauts";
    [pt] = "Superior";
    [ru] = "По верхнему краю"
};
text.GroupMenu.ArrangeBarsMenu.AlignVerticallyMenu.Bottoms = {
    [en] = "Bottoms";
    [de] = "Unterseiten";
    [fr] = "Bas";
    [pt] = "Inferior";
    [ru] = "По нижнему краю"
};
text.GroupMenu.ArrangeBarsMenu.AlignVerticallyMenu.Middles = {
    [en] = "Middles";
    [de] = "Mitten";
    [fr] = "Milieux";
    [pt] = "Meio";
    [ru] = "По середине"
};
text.GroupMenu.ArrangeBarsMenu.AlignHorizontally = {
    [en] = "Align horizontally";
    [de] = "Waagerecht ausrichten";
    [fr] = "Aligner horizontallement";
    [pt] = "Alinhar horizontalmente";
    [ru] = "Выровнять по горизонтали"
};
text.GroupMenu.ArrangeBarsMenu.AlignHorizontallyMenu = {};
text.GroupMenu.ArrangeBarsMenu.AlignHorizontallyMenu.LeftSides = {
    [en] = "Left sides";
    [de] = "Linke Seiten";
    [fr] = "Cotés gauches";
    [pt] = "Lado esquerdo";
    [ru] = "По левому краю"
};
text.GroupMenu.ArrangeBarsMenu.AlignHorizontallyMenu.RightSides = {
    [en] = "Right sides";
    [de] = "Rechte Seiten";
    [fr] = "Cotés droits";
    [pt] = "Lado direito";
    [ru] = "По правому краю"
};
text.GroupMenu.ArrangeBarsMenu.AlignHorizontallyMenu.Centers = {
    [en] = "Centers";
    [de] = "Zentren";
    [fr] = "Centres";
    [pt] = "Centro";
    [ru] = "По центру"
};
text.GroupMenu.Expand = {
    [en] = "Expand group";
    [de] = "Gruppe ausklappen";
    [fr] = "Déplier le groupe";
    [pt] = "Expandir grupo";
    [ru] = "?"
};
text.GroupMenu.Collapse = {
    [en] = "Collapse group";
    [de] = "Gruppe einklappen";
    [fr] = "Replier le groupe";
    [pt] = "Recolher";
    [ru] = "?"
};
text.GroupMenu.GroupSettings = {
    [en] = "Group settings";
    [de] = "Gruppenoptionen";
    [fr] = "Paramêtres du groupe";
    [pt] = "Configurações de grupo";
    [ru] = "Настройки группы"
};
text.GroupMenu.GroupSettingsMenu = {};
text.GroupMenu.GroupSettingsMenu.Rename = {
    [en] = "Rename...";
    [de] = "Umbenennen...";
    [fr] = "Renommer...";
    [pt] = "Renomear";
    [ru] = "Переименовать..."
};
text.GroupMenu.GroupSettingsMenu.BarsMoveTogether = {
    [en] = "Bars move together";
    [de] = "Leisten gemeinsam bewegen";
    [fr] = "Les barres bougent ensemble";
    [pt] = "Mover barras juntas";
    [ru] = "Перемещать панели вместе"
};
text.GroupMenu.Debug = {
    [en] = "Debug";
    [de] = "Debug";
    [fr] = "Déboguer";
    [pt] = "Debug";
    [ru] = "Отлаживать"
};
text.GroupMenu.Global = {
    [en] = "Global operations";
    [de] = "Globale Operationen";
    [fr] = "Opérations globales";
    [pt] = "Operações globais";
    [ru] = "Общие действия"
};
text.GroupMenu.GlobalMenu = text.GlobalMenu;

-- Bar context menu items
text.BarMenu = {};
text.BarMenu.Expand = {
    [en] = "Expand";
    [de] = "Ausklappen";
    [fr] = "Déplier";
    [pt] = "Expandir";
    [ru] = "?"
};
text.BarMenu.Collapse = {
    [en] = "Collapse";
    [de] = "Einklappen";
    [fr] = "Replier";
    [pt] = "Recolher";
    [ru] = "?"
};
text.BarMenu.Directory = {
    [en] = "Directory...";
    [de] = "Verzeichnis...";
    [fr] = "Répertoire...";
    [pt] = "Diretório";
    [ru] = "Список панелей..."
};
text.BarMenu.Find = {
    [en] = "Find";
    [de] = "Finden";
    [fr] = "Trouver";
    [pt] = "Localizar";
    [ru] = "Показать на экране"
};
text.BarMenu.Hide = {
    [en] = "Hide";
    [de] = "Ausblenden";
    [fr] = "Cacher";
    [pt] = "Esconder";
    [ru] = "Скрыть"
};
text.BarMenu.Position = {
    [en] = "Position";
    [de] = "Positionieren";
    [fr] = "Position";
    [pt] = "Posição";
    [ru] = "?"
};
text.BarMenu.PositionMenu = {};
text.BarMenu.PositionMenu.LockPosition = {
    [en] = "Lock position";
    [de] = "Verankern";
    [fr] = "Bloquer la position";
    [pt] = "Bloquear posição";
    [ru] = "Закрепить расположение"
};
text.BarMenu.PositionMenu.RelativeTo = {
    [en] = "Relative to";
    [de] = "Ausrichten an";
    [fr] = "Par rapport au";
    [pt] = "Relativo a";
    [ru] = "?"
};
text.BarMenu.PositionMenu.RelativeToMenu = {};
text.BarMenu.PositionMenu.RelativeToMenu.TopLeft = {
    [en] = "Upper, left corner of screen";
    [de] = "Obere linke Ecke des Bildschirms";
    [fr] = "Coin gauche, haut de l'écran";
    [pt] = "Canto supeior esquerdo da tela";
    [ru] = "?"
};
text.BarMenu.PositionMenu.RelativeToMenu.TopCenter = {
    [en] = "Midpoint of top edge of screen";
    [de] = "Mittelpunkt der Oberkante des Bildschirms";
    [fr] = "Centre du bord haut de l'écran";
    [pt] = "Centro da parte superior da tela";
    [ru] = "?"
};
text.BarMenu.PositionMenu.RelativeToMenu.TopRight = {
    [en] = "Upper, right corner of screen";
    [de] = "Obere rechte Ecke des Bildschirms";
    [fr] = "Coin droit, haut de l'écran";
    [pt] = "Canto superior direito da tela";
    [ru] = "?"
};
text.BarMenu.PositionMenu.RelativeToMenu.MiddleLeft = {
    [en] = "Midpoint of left edge of screen";
    [de] = "Mittelpunkt der linken Kante des Bildschirms";
    [fr] = "Centre du bord gauche de l'écran";
    [pt] = "Centro do lado esquerdo da tela";
    [ru] = "?"
};
text.BarMenu.PositionMenu.RelativeToMenu.MiddleCenter = {
    [en] = "Center of screen";
    [de] = "Mitte des Bildschirms";
    [fr] = "Centre de l'écran";
    [pt] = "Centro da tela";
    [ru] = "?"
};
text.BarMenu.PositionMenu.RelativeToMenu.MiddleRight = {
    [en] = "Midpoint of right edge of screen";
    [de] = "Mittelpunkt der rechten Kante des Bildschirms";
    [fr] = "Centre du bord droit de l'écran";
    [pt] = "Centro do lado direito da tela";
    [ru] = "?"
};
text.BarMenu.PositionMenu.RelativeToMenu.BottomLeft = {
    [en] = "Lower, left corner of screen";
    [de] = "Untere linke Ecke des Bildschirms";
    [fr] = "Coin gauche, bas de l'écran";
    [pt] = "Canto inferior esquerdo da tela";
    [ru] = "?"
};
text.BarMenu.PositionMenu.RelativeToMenu.BottomCenter = {
    [en] = "Midpoint of bottom edge of screen";
    [de] = "Mittelpunkt der Unterkante des Bildschirms";
    [fr] = "Centre du bord bas de l'écran";
    [pt] = "Centro da parte inferior da tela";
    [ru] = "?"
};
text.BarMenu.PositionMenu.RelativeToMenu.BottomRight = {
    [en] = "Lower, right corner of screen";
    [de] = "Untere rechte Ecke des Bildschirms";
    [fr] = "Coin droit, bas de l'écran";
    [pt] = "Canto inferior direito da tela";
    [ru] = "?"
};
text.BarMenu.EditSequence = {
    [en] = "Edit sequence...";
    [de] = "Sequenz bearbeiten...";
    [fr] = "Editer la séquence...";
    [pt] = "Editar sequência...";
    [ru] = "Изменить порядок..."
};
text.BarMenu.Clone = {
    [en] = "Clone";
    [de] = "Klonen";
    [fr] = "Dupliquer";
    [pt] = "Clonar";
    [ru] = "Скопировать"
};
text.BarMenu.Delete = {
    [en] = "Delete";
    [de] = "Löschen";
    [fr] = "Effacer";
    [pt] = "Excluir";
    [ru] = "Удалить"
};
text.BarMenu.Export = {
    [en] = "Export...";
    [de] = "Exportieren...";
    [fr] = "Exporter...";
    [pt] = "Exportar...";
    [ru] = "Экспорт..."
};
text.BarMenu.EventBehaviors = {
    [en] = "Event behaviours";
    [de] = "Verhalten bei Ereignissen";
    [fr] = "Comportement lors des évènements";
    [pt] = "Compartamento de eventos";
    [ru] = "Реакция на события (панель)"
};
text.BarMenu.Settings = {
    [en] = "Settings";
    [de] = "Einstellungen";
    [fr] = "Paramêtres";
    [pt] = "Configurações";
    [ru] = "Настройки"
};
text.BarMenu.SettingsMenu = {};
text.BarMenu.SettingsMenu.Orientation = {
    [en] = "Orientation";
    [de] = "Ausrichtung";
    [fr] = "Orientation";
    [pt] = "Orientação";
    [ru] = "Направление"
};
text.BarMenu.SettingsMenu.OrientationMenu = {};
text.BarMenu.SettingsMenu.OrientationMenu.Up = {
    [en] = "Up";
    [de] = "Aufwärts";
    [fr] = "Haut";
    [pt] = "Para cima";
    [ru] = "Вверх"
};
text.BarMenu.SettingsMenu.OrientationMenu.Down = {
    [en] = "Down";
    [de] = "Abwärts";
    [fr] = "Bas";
    [pt] = "Para baixo";
    [ru] = "Вниз"
};
text.BarMenu.SettingsMenu.OrientationMenu.Right = {
    [en] = "Right";
    [de] = "Rechts";
    [fr] = "Droit";
    [pt] = "Direita";
    [ru] = "Вправо"
};
text.BarMenu.SettingsMenu.OrientationMenu.Left = {
    [en] = "Left";
    [de] = "Links";
    [fr] = "Gauche";
    [pt] = "Esquerda";
    [ru] = "Влево"
};
text.BarMenu.SettingsMenu.Height = {
    [en] = "Height";
    [de] = "Höhe";
    [fr] = "Hauteur";
    [pt] = "Altura";
    [ru] = "Высота"
};
text.BarMenu.SettingsMenu.Width = {
    [en] = "Width";
    [de] = "Breite";
    [fr] = "Largeur";
    [pt] = "Largura";
    [ru] = "Ширина"
};
text.BarMenu.SettingsMenu.HeightWidthMenu = {};
text.BarMenu.SettingsMenu.HeightWidthMenu.Slot = {
    [en] = "<num> slot";
    [de] = "<num> Feld";
    [fr] = "<num> d'emplacement";
    [pt] = "<num> slot";
    [ru] = "Ячеек: <num>"
};
text.BarMenu.SettingsMenu.HeightWidthMenu.Slots = {
    [en] = "<num> slots";
    [de] = "<num> Felder";
    [fr] = "<num> d'emplacements";
    [pt] = "<num> slots";
    [ru] = "Ячеек: <num>"
};
text.BarMenu.SettingsMenu.Cursor = {
    [en] = "Cursor";
    [de] = "Cursor";
    [fr] = "Curseur";
    [pt] = "Cursor";
    [ru] = "Указатель"
};
text.BarMenu.SettingsMenu.CursorMenu = {};
text.BarMenu.SettingsMenu.CursorMenu.Style = {
    [en] = "Style";
    [de] = "Stil";
    [fr] = "Style";
    [pt] = "Estilo";
    [ru] = "Стиль"
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu = {};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.Disabled = {
    [en] = "Disabled";
    [de] = "Deaktiviert";
    [fr] = "Désactivé";
    [pt] = "Desativado";
    [ru] = "Отсутствует"
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.SmallSquareGlow = {
    [en] = "Small square glow";
    [de] = "Klein, quadratisch";
    [fr] = "Eclat carré petit";
    [pt] = "Brilho quadrado pequeno ";
    [ru] = "Квадрат, слабое свечение"
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.LargeSquareGlow = {
    [en] = "Large square glow";
    [de] = "Groß, quadratisch";
    [fr] = "Eclat carré large";
    [pt] = "Brilho quadrado grande";
    [ru] = "Квадрат, сильное свечение"
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.SmallRoundGlow = {
    [en] = "Small round glow";
    [de] = "Klein, rund";
    [fr] = "Eclat rond petit";
    [pt] = "Brilho redondo pequeno";
    [ru] = "Круг, слабое свечение"
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.MediumRoundGlow = {
    [en] = "Medium round glow";
    [de] = "Mittelgroß, rund";
    [fr] = "Eclat rond médium";
    [pt] = "Brilho redondo médio";
    [ru] = "Круг, среднее свечение"
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.LargeRoundGlow = {
    [en] = "Large round glow";
    [de] = "Groß, rund";
    [fr] = "Eclat rond large";
    [pt] = "Brilho redondo grande";
    [ru] = "Круг, сильное свечение"
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.PictureFrame = {
    [en] = "Picture frame";
    [de] = "Bilderrahmen";
    [fr] = "Cadre";
    [pt] = "Moldura";
    [ru] = "Рамка-изображение"
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.GlowingFrame = {
    [en] = "Glowing frame";
    [de] = "Glühender Rahmen";
    [fr] = "Cadre brillant";
    [pt] = "Moldura brilhante";
    [ru] = "Рамка со свечением";
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.OrnateFrame = {
    [en] = "Ornate frame 1";
    [de] = "Verzierter Rahmen 1";
    [fr] = "Cadre orné 1";
    [pt] = "Moldura ornamentada 1";
    [ru] = "Рамка с украшением 1";
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.OrnateFrame2 = {
    [en] = "Ornate frame 2";
    [de] = "Verzierter Rahmen 2";
    [fr] = "Cadre orné 2";
    [pt] = "Moldura ornamentada 2";
    [ru] = "Рамка с украшением 2";
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.OrnateFrame3 = {
    [en] = "Ornate frame 3";
    [de] = "Verzierter Rahmen 3";
    [fr] = "Cadre orné 3";
    [pt] = "Moldura ornamentada 3";
    [ru] = "Рамка с украшением 3";
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.GoldFrame = {
    [en] = "Golden Frame";
    [de] = "Goldener Rahmen";
    [fr] = "Cadre doré";
    [pt] = "Moldura dourada";
    [ru] = "Рамка золотая";
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.WireFrame = {
    [en] = "Wire Frame";
    [de] = "Drahtrahmen";
    [fr] = "Fil de fer";
    [pt] = "Moldura de fios";
    [ru] = "Рамка простая";
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.MetalFrame1 = {
    [en] = "Metal Frame 1";
    [de] = "Metallrahmen 1";
    [fr] = "Cadre métal 1";
    [pt] = "Moldura de metal 1";
    [ru] = "Рамка металлическая 1";
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.MetalFrame2 = {
    [en] = "Metal Frame 2";
    [de] = "Metallrahmen 2";
    [fr] = "Cadre métal 2";
    [pt] = "Moldura de metal 2";
    [ru] = "Рамка металлическая 2";
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.MetalFrame3 = {
    [en] = "Metal Frame 3";
    [de] = "Metallrahmen 3";
    [fr] = "Cadre métal 3";
    [pt] = "Moldura de metal 3";
    [ru] = "Рамка металлическая 3";
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.MetalFrame4 = {
    [en] = "Metal Frame 4";
    [de] = "Metallrahmen 4";
    [fr] = "Cadre métal 4";
    [pt] = "Moldura de metal 4";
    [ru] = "Рамка металлическая 4";
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.Orb = {
    [en] = "Orb";
    [de] = "Kugel";
    [fr] = "Sphère";
    [pt] = "Esfera";
    [ru] = "Шар";
};
text.BarMenu.SettingsMenu.CursorMenu.StyleMenu.HugeOrb = {
    [en] = "Huge Orb";
    [de] = "Riesige Kugel";
    [fr] = "Grosse sphère";
    [pt] = "Esfera grande";
    [ru] = "Шар большой";
};
text.BarMenu.SettingsMenu.CursorMenu.HomePosition = {
    [en] = "Home position";
    [de] = "Ausgangsposition";
    [fr] = "Position d'origine";
    [pt] = "Posição inicial";
    [ru] = "Начальная позиция"
};
text.BarMenu.SettingsMenu.CursorMenu.HomePositionMenu = {};
text.BarMenu.SettingsMenu.CursorMenu.HomePositionMenu.Slot = {
    [en] = "Slot <num>";
    [de] = "Feld <num>";
    [fr] = "Emplacement <num>";
    [pt] = "Slot <num>";
    [ru] = "Ячейка <num>"
};
text.BarMenu.SettingsMenu.Caption = {
    [en] = "Caption";
    [de] = "Beschriftung";
    [fr] = "Titre";
    [pt] = "Título";
    [ru] = "Название"
};
text.BarMenu.SettingsMenu.CaptionMenu = {};
text.BarMenu.SettingsMenu.CaptionMenu.Edit = {
    [en] = "Edit...";
    [de] = "Bearbeiten...";
    [fr] = "Editer...";
    [pt] = "Editar...";
    [ru] = "Изменить..."
};
text.BarMenu.SettingsMenu.CaptionMenu.CaptionVisible = {
    [en] = "Visible";
    [de] = "Sichtbar";
    [fr] = "Visible";
    [pt] = "Visível";
    [ru] = "видимый"
};
text.BarMenu.SettingsMenu.CaptionMenu.CaptionVisibleMenu = {};
text.BarMenu.SettingsMenu.CaptionMenu.CaptionVisibleMenu.Always = {
    [en] = "Always";
    [de] = "Immer";
    [fr] = "Toujours";
    [pt] = "Sempre";
    [ru] = "Всегда"
};
text.BarMenu.SettingsMenu.CaptionMenu.CaptionVisibleMenu.WhenMouseIsPresent = {
    [en] = "When mouse is present";
    [de] = "Wenn Maus vorhanden ist";
    [fr] = "Lorsque la souris est présent";
    [pt] = "Quando o mouse está presente";
    [ru] = "Когда мышь присутствует"
};
text.BarMenu.SettingsMenu.CaptionMenu.CaptionVisibleMenu.Never = {
    [en] = "Never";
    [de] = "Nie";
    [fr] = "Jamais";
    [pt] = "Nunca";
    [ru] = "Никогда"
};
text.BarMenu.SettingsMenu.CaptionMenu.CaptionClickable = {
    [en] = "Clickable";
    [de] = "Klickbare";
    [fr] = "Cliquable";
    [pt] = "Clicável";
    [ru] = "Кликабельны"
};
text.BarMenu.SettingsMenu.CaptionMenu.CaptionPosition = {
    [en] = "Position";
    [de] = "Position";
    [fr] = "Position";
    [pt] = "Posição";
    [ru] = "Расположить"
};
text.BarMenu.SettingsMenu.CaptionMenu.CaptionPositionMenu = {};
text.BarMenu.SettingsMenu.CaptionMenu.CaptionPositionMenu.Top = {
    [en] = "Top";
    [de] = "Oben";
    [fr] = "Haut";
    [pt] = "Em cima";
    [ru] = "Сверху"
};
text.BarMenu.SettingsMenu.CaptionMenu.CaptionPositionMenu.Bottom = {
    [en] = "Bottom";
    [de] = "Unten";
    [fr] = "Bas";
    [pt] = "Em baixo";
    [ru] = "Снизу"
};
text.BarMenu.SettingsMenu.CaptionMenu.CaptionPositionMenu.LeftSide = {
    [en] = "Left side";
    [de] = "Links";
    [fr] = "Coté gauche";
    [pt] = "Lado esquerdo";
    [ru] = "Слева"
};
text.BarMenu.SettingsMenu.CaptionMenu.CaptionPositionMenu.RightSide = {
    [en] = "Right side";
    [de] = "Rechts";
    [fr] = "Coté droit";
    [pt] = "Lado direito";
    [ru] = "Справа"
};
text.BarMenu.SettingsMenu.Animation = {
    [en] = "Animation";
    [de] = "Animation";
    [fr] = "Animation";
    [pt] = "Animação";
    [ru] = "Анимация"
};
text.BarMenu.SettingsMenu.HideAutomatics = {
    [en] = "Hide automatic slots";
    [de] = "Automatische Felder ausblenden";
    [fr] = "Cacher les emplacements automatiques";
    [pt] = "Esconder slots automáticos";
    [ru] = "Скрыть ячейки, срабатывающие автоматически"
};
text.BarMenu.SettingsMenu.HideInactiveBranches = {
    [en] = "Hide inactive branches";
    [de] = "Inaktive Zweige ausblenden";
    [fr] = "Cacher les branches inactives";
    [pt] = "Esconder ramificações inativas";
    [ru] = "Скрыть неактивыне условия порядка панели"
};
text.BarMenu.SettingsMenu.ContinuousExecution = {
    [en] = "Run continuously";
    [de] = "kontinuierlich ausführen";
    [fr] = "Exécuter en continu";
    [pt] = "Execução contínua";
    [ru] = "Выполнить непрерывно"
};
text.BarMenu.SettingsMenu.Color = {
    [en] = "Color...";
    [de] = "Farbe...";
    [fr] = "Couleur...";
    [pt] = "Cor...";
    [ru] = "Цвет..."
};
text.BarMenu.SettingsMenu.Transparency = {
    [en] = "Transparency";
    [de] = "Transparenz";
    [fr] = "Transparence";
    [pt] = "Transparência";
    [ru] = "?"
};
text.BarMenu.SettingsMenu.TransparencyMenu = {};
text.BarMenu.SettingsMenu.TransparencyMenu.UseGlobalSetting = {
    [en] = "Use global setting";
    [de] = "Globale Einstellungen verwenden";
    [fr] = "Utiliser les paramètres généraux";
    [pt] = "Usar configuraçõoes globais";
    [ru] = "?"
};
text.BarMenu.SettingsMenu.TransparencyMenu.default = {
    [en] = "global setting";
    [de] = "Globale Einstellungen";
    [fr] = "paramètres généraux";
    [pt] = "configuração global";
    [ru] = "?"
};
text.BarMenu.SettingsMenu.TransparencyMenu.FullyTransparent = {
    [en] = "0% (fully transparent)";
    [de] = "0% (ganz durchsichtig)";
    [fr] = "0% (Invisible)";
    [pt] = "0% (Invisível)";
    [ru] = "?"
};
text.BarMenu.SettingsMenu.TransparencyMenu.PartiallyTransparent = {
    [en] = "<pct>%";
    [de] = "<pct>%";
    [fr] = "<pct>%";
    [pt] = "<pct>%";
    [ru] = "?"
};
text.BarMenu.SettingsMenu.TransparencyMenu.FullyOpaque = {
    [en] = "100% (fully opaque)";
    [de] = "100% (voll deckend)";
    [fr] = "100% (Sans transparence)";
    [pt] = "100% (completamente visível)";
    [ru] = "?"
};
text.BarMenu.SettingsMenu.Scale = {
    [en] = "Scale";
    [de] = "Maßstab";
    [fr] = "Echelle";
    [pt] = "Tamanho";
    [ru] = "Масштаб"
};
text.BarMenu.SettingsMenu.ScaleMenu = {};
text.BarMenu.SettingsMenu.ScaleMenu.UseGlobalSetting = {
    [en] = "Use global setting";
    [de] = "Globale Einstellungen verwenden";
    [fr] = "Utiliser les paramètres généraux";
    [pt] = "Usar configurações globais";
    [ru] = "?"
};
text.BarMenu.SettingsMenu.AnimationMenu = {};
text.BarMenu.SettingsMenu.AnimationMenu.Instantaneous = {
    [en] = "Instantaneous";
    [de] = "Sofort";
    [fr] = "Instantané";
    [pt] = "Instantâneo";
    [ru] = "Мгновенная"
};
text.BarMenu.SettingsMenu.AnimationMenu.Disabled = {
    [en] = "Disabled";
    [de] = "Deaktiviert";
    [fr] = "Désactivé";
    [pt] = "Desativado";
    [ru] = "Отсутствует"
};
text.BarMenu.SettingsMenu.AnimationMenu.Fast = {
    [en] = "Fast";
    [de] = "Schnell";
    [fr] = "Rapide";
    [pt] = "Rápido";
    [ru] = "Быстрая"
};
text.BarMenu.SettingsMenu.AnimationMenu.Slow = {
    [en] = "Slow";
    [de] = "Langsam";
    [fr] = "Lent";
    [pt] = "Lento";
    [ru] = "Медленная"
};
text.BarMenu.SettingsMenu.AnimationMenu.VerySlow = {
    [en] = "Very slow";
    [de] = "Sehr langsam";
    [fr] = "Très lent";
    [pt] = "Muito lento";
    [ru] = "Очень медленная"
};
text.BarMenu.SettingsMenu.MouseWheel = {
    [en] = "Mouse wheel";
    [de] = "Mausrad";
    [fr] = "Molette de la souris";
    [pt] = "Roda do mouse";
    [ru] = "Колесико мыши"
}
text.BarMenu.SettingsMenu.MouseWheelMenu = {};
text.BarMenu.SettingsMenu.MouseWheelMenu.WheelDisabled = {
    [en] = "Disabled";
    [de] = "Aus";
    [fr] = "Désactivé";
    [pt] = "Desativado";
    [ru] = "Отсутствует"
};
text.BarMenu.SettingsMenu.MouseWheelMenu.WheelForwardFast = {
    [en] = "Fast";
    [de] = "Schnell";
    [fr] = "Rapide";
    [pt] = "Rápido";
    [ru] = "Быстрая"
};
text.BarMenu.SettingsMenu.MouseWheelMenu.WheelForwardSlow = {
    [en] = "Slow";
    [de] = "Langsam";
    [fr] = "Lent";
    [pt] = "Lento";
    [ru] = "Медленная"
};
text.BarMenu.SettingsMenu.MouseWheelMenu.WheelForwardVerySlow = {
    [en] = "Very slow";
    [de] = "Sehr langsam";
    [fr] = "Très lent";
    [pt] = "Muito lento";
    [ru] = "Очень медленная"
};
text.BarMenu.SettingsMenu.MouseWheelMenu.WheelReverseFast = {
    [en] = "Fast (reverse)";
    [de] = "Schnell (rückwärts)";
    [fr] = "Rapide (arrière)";
    [pt] = "Rápido (reverso)";
    [ru] = "Быстрая (reverse†)"
};
text.BarMenu.SettingsMenu.MouseWheelMenu.WheelReverseSlow = {
    [en] = "Slow (reverse)";
    [de] = "Langsam (rückwärts)";
    [fr] = "Lent (arrière)";
    [pt] = "Lento (reverso)";
    [ru] = "Медленная (reverse†)"
};
text.BarMenu.SettingsMenu.MouseWheelMenu.WheelReverseVerySlow = {
    [en] = "Very slow (reverse)";
    [de] = "Sehr langsam (rückwärts)";
    [fr] = "Très lent (arrière)";
    [pt] = "Muito lento (reverso)";
    [ru] = "Очень медленная (reverse†)"
};
text.BarMenu.Debug = text.GroupMenu.Debug;
text.BarMenu.Group = {
    [en] = "Group operations";
    [de] = "Gruppenoperationen";
    [fr] = "Opérations de groupe";
    [pt] = "Operações de grupo";
    [ru] = "Действия с группой"
};
text.BarMenu.GroupMenu = text.GroupMenu;
text.BarMenu.Global = {
    [en] = "Global operations";
    [de] = "Globale Operationen";
    [fr] = "Opérations globales";
    [pt] = "Operações globais";
    [ru] = "Общие действия"
};
text.BarMenu.GlobalMenu = text.GlobalMenu;

-- Caption editor items
text.CaptionEditor = {};
text.CaptionEditor.Title = {};
text.CaptionEditor.Title.BarCaption = {
    [en] = "Bar caption";
    [de] = "Leistenbeschriftung";
    [fr] = "Titre de la barre";
    [pt] = "Título da barra";
    [ru] = "Название панели"
};
text.CaptionEditor.Title.GroupName = {
    [en] = "Group name";
    [de] = "Gruppename";
    [fr] = "Nom du groupe";
    [pt] = "Nome do grupo";
    [ru] = "Название группы"
};
text.CaptionEditor.Font = {
    [en] = "Font";
    [de] = "Schriftart";
    [fr] = "Police";
    [pt] = "Fonte";
    [ru] = "Шрифт"
};
text.CaptionEditor.Color = {
    [en] = "Color...";
    [de] = "Farbe...";
    [fr] = "Couleur...";
    [pt] = "Cor...";
    [ru] = "Цвет..."
};

-- Import and Export window items
text.ExportWindow = {};
text.ExportWindow.Title = {
    [en] = "Exporting ‘‘<name>’’";
    [de] = "‚‚<name>‘‘ exportieren";
    [fr] = "Exportation « <nom> »";
    [pt] = "Exportando «<name>»";
    [ru] = "Экспорт «<name>»"
};
text.ExportWindow.OK = {
    [en] = "OK";
    [de] = "OK";
    [fr] = "Ok";
    [pt] = "OK";
    [ru] = "ОК"
};
text.ExportWindow.Compressed = {
    [en] = "Compressed";
    [de] = "Komprimiert";
    [fr] = "Compressé";
    [pt] = "Comprimido";
    [ru] = "Сжать"
};
text.ExportWindow.Compressing = {
    [en] = "Compressing...";
    [de] = "Komprimieren...";
    [fr] = "Compression...";
    [pt] = "Comprimindo...";
    [ru] = "Сжатие..."
};
text.ExportWindow.Encoding = {
    [en] = "Encoding...";
    [de] = "Codieren...";
    [fr] = "Encodage...";
    [pt] = "Codificação...";
    [ru] = "Кодирование..."
};
text.ExportWindow.Exporting = {
    [en] = "Exporting...";
    [de] = "Exportieren...";
    [fr] = "Exportation...";
    [pt] = "Exportando...";
    [ru] = "Экспорт..."
};
text.ExportWindow.ExportFailedTooBig = {
    [en] = "Export failed.  Cannot display more than 64 kB of data.  Try exporting a smaller number of objects.";
    [de] = "Exportieren fehlgeschlagen.  Maximal darstellbare Dateigröße 64 kB.  Versuchen Sie, eine geringere Anzahl Objekte zu exportieren.";
    [fr] = "L'export a échoué. Impossible d'afficher plus de 64kb de données. Essayer d'exporter un plus petit nombre d'objets.";
    [pt] = "A exportação falhou. Não é possível exibir mais de 64 kb de dados. Tente exportar um número menor de objetos.";
    [ru] = "Ошибка при экспорте. Нельзя показать больше 64 КБ данных. Попробуйте уменьшить количество объектов, выбранных для экспорта."
};
text.ExportWindow.UncompressedDataTooBig = {
    [en] = "Error:  Cannot display the uncompressed data, because it is larger than 64 kB.";
    [de] = "Fehler: Die unkomprimierten Daten können nicht angezeigt werden, weil sie größer als 64 kB sind.";
    [fr] = "Erreur: impossible d'afficher les données décompressées car elles pèsent plus de 64kb.";
    [pt] = "Erro: Não é possível exibir os dados não compactados, porque são maiores que 64 kb.";
    [ru] = "Ошибка. Нельзя показать данные в читаемом виде, т.к. их размер превышает 64 КБ."
};
text.ImportWindow = {};
text.ImportWindow.Title = {
    [en] = "Importing into ‘‘<group>’’";
    [de] = "Importieren in ‚‚<group>‘‘";
    [fr] = "Importer dans « <group> »";
    [pt] = "Importando em «<group>»";
    [ru] = "Импорт в «<group>»"
};
text.ImportWindow.PasteDataHere = {
    [en] = "Paste exported data here (Ctrl+V):";
    [de] = "Exportierte Daten hier einfügen (Strg+V):";
    [fr] = "Coller les données exportées ici (Ctrl+V):";
    [pt] = "Cole os dados exportados aqui (Ctrl+V):";
    [ru] = "Вставьте экспортированные данные (Ctrl+V):"
};
text.ImportWindow.Decompressing = {
    [en] = "Decompressing...";
    [de] = "Dekomprimieren...";
    [fr] = "Décompression...";
    [pt] = "?";
    [ru] = "Извлечение..."
};
text.ImportWindow.Decoding = {
    [en] = "Decoding...";
    [de] = "Dekodieren...";
    [fr] = "Décodage...";
    [pt] = "Descomprimir...";
    [ru] = "Декодирование..."
};
text.ImportWindow.Importing = {
    [en] = "Importing:";
    [de] = "Importieren:";
    [fr] = "Importation:";
    [pt] = "Importando:";
    [ru] = "Импортировано:"
};
text.ImportWindow.InvalidEncoding = {
    [en] = "Error: Invalid encoding!";
    [de] = "Fehler: Ungültige Codierung!";
    [fr] = "Erreur: encodage invalide!";
    [pt] = "Erro: Códificação inválida!";
    [ru] = "Ошибка в кодировке!"
};
text.ImportWindow.ParseError = {
    [en] = "Parse error: ";
    [de] = "Fehler analysieren:";
    [fr] = "Erreur d'analyse:";
    [pt] = "Erro de interpretação: ";
    [ru] = "Ошибка при чтении данных: "
};
text.ImportWindow.NothingToDo = {
    [en] = "Nothing to do!";
    [de] = "Nichts zu tun!";
    [fr] = "Rien à effectuer!";
    [pt] = "Nada para fazer!";
    [ru] = "Нечего импортировать!"
};

-- Sequence editor items
text.SequenceEditor = {};
text.SequenceEditor.Title = {
    [en] = "Editing ‘‘<name>’’";
    [de] = "‚‚<name>‘‘ editieren";
    [fr] = "Edition « <nom> »";
    [pt] = "Editando «<name>»";
    [ru] = "Изменение «<name>»"
};
text.SequenceEditor.MinWidth = {
    [en] = 470;
    [de] = 490;
    [fr] = 490;
    [pt] = 470;
    [ru] = 470
};
text.SequenceEditor.Instructions = {
    [en] = "Drag icons here from your inventory or skills.\nRight-click for other actions.";
    [de] = "Ziehe die Symbole von Inventargegenständen oder Fertigkeiten hier in die Felder. Rechtsklick für andere Aktionen.";
    [fr] = "Glisser ici les icônes du panneau de votre inventaire ou des compétences. Clic-droit pour les autres actions.";
    [pt] = "Arraste os icones aqui, de seu inventário ou skills.\nClique com botão direito do mouse para mais ações.";
    [ru] = "Перетащите сюда иконки предметов или умений.\nПКМ: дополнительные действия."
}
text.SequenceEditor.SequenceTab = {
    [en] = "Sequence";
    [de] = "Sequenz";
    [fr] = "Sequence";
    [pt] = "Sequência";
    [ru] = "Порядок"
}
text.SequenceEditor.SlotTab = {
    [en] = "Slot";
    [de] = "Feld";
    [fr] = "Emplacement";
    [pt] = "Slot";
    [ru] = "Ячейка"
}
text.SequenceEditor.SlotTabWidth = {
    [en] = 120;
    [de] = 120;
    [fr] = 160;
    [pt] = 120;
    [ru] = 120
}
text.SequenceEditor.SlotTabCardWidth = {
    [en] = 200;
    [de] = 220;
    [fr] = 220;
    [pt] = 200;
    [ru] = 200
}
text.SequenceEditor.StandardQuickslot = {
    [en] = "Standard quickslot";
    [de] = "Standardschnellzugriffsfeld";
    [fr] = "Emplacement rapide standard";
    [pt] = "Quickslot padrão";
    [ru] = "Ячейка быстрого доступа"
}
text.SequenceEditor.SpecialSlot = {
    [en] = "Special slot";
    [de] = "Spezialfeld";
    [fr] = "Emplacement spécial";
    [pt] = "Slot especial";
    [ru] = "Особая ячейка"
}
text.SequenceEditor.EventName = {
    [en] = "Event name";
    [de] = "Ereignisname";
    [fr] = "Nom de l'évènement";
    [pt] = "Nome do evento";
    [ru] = "Название события"
}
text.SequenceEditor.NewEvent = {
    [en] = "New event";
    [de] = "Neues Ereignis";
    [fr] = "Nouvel événement";
    [pt] = "Novo evento";
    [ru] = "?"
}
text.SequenceEditor.ChatCommand = {
    [en] = "Chat command";
    [de] = "Chatbefehl";
    [fr] = "Commande de discussion";
    [pt] = "Comando de chat";
    [ru] = "Команда чата"
}
text.SequenceEditor.ChangeIcon = {
    [en] = "Icon";
    [de] = "Symbol";
    [fr] = "Icône";
    [pt] = "Mudar ícone";
    [ru] = "Иконка"
}
text.SequenceEditor.DefaultIcon = {
    [en] = "Default";
    [de] = "Standardsymbol";
    [fr] = "Par defaut";
    [pt] = "Ícone padrão";
    [ru] = "?"
}
text.SequenceEditor.BlankIcon = {
    [en] = "Blank Icon";
    [de] = "leeres Symbol";
    [fr] = "Icône vide";
    [pt] = "Ícone vazio";
    [ru] = "?"
}
text.SequenceEditor.SkillIcon = {
    [en] = "Skill";
    [de] = "Fertigkeit";
    [fr] = "Compétence";
    [pt] = "Skill";
    [ru] = "?"
}
text.SequenceEditor.SpecificIconID = {
    [en] = "Specific";
    [de] = "spezifische";
    [fr] = "Spécifique";
    [pt] = "Específico";
    [ru] = "?"
}
text.SequenceEditor.Appearance = {
    [en] = "Appearance";
    [de] = "Aussehen";
    [fr] = "Apparence";
    [pt] = "Aparência";
    [ru] = "?"
}
text.SequenceEditor.TextOverlay = {
    [en] = "Text overlay";
    [de] = "Textüberlagerung";
    [fr] = "Texte en superposition";
    [pt] = "Texto sobreposto";
    [ru] = "Текст поверх"
}
text.SequenceEditor.Condition = {
    [en] = "Condition";
    [de] = "Bedingung";
    [fr] = "Condition";
    [pt] = "Condição";
    [ru] = "Условие"
}
text.SequenceEditor.True = {
    [en] = "true";
    [de] = "wahr";
    [fr] = "vraie";
    [pt] = "verdade";
    [ru] = "истина"
}
text.SequenceEditor.False = {
    [en] = "false";
    [de] = "falsch";
    [fr] = "fausse";
    [pt] = "falso";
    [ru] = "ложь"
}
text.SequenceEditor.ConditionTypes = {};
text.SequenceEditor.ConditionTypes.Always = {
    [en] = "(Always)";
    [de] = "(Immer)";
    [fr] = "(Toujours)";
    [pt] = "(Sempre)";
    [ru] = "(Всегда)"
}
text.SequenceEditor.ConditionTypes.Never = {
    [en] = "(Never)";
    [de] = "(Nie)";
    [fr] = "(Jamais)";
    [pt] = "(Nunca)";
    [ru] = "(Никогда)"
}
text.SequenceEditor.ConditionTypes.OtherEffect = {
    [en] = "(Other effect)";
    [de] = "(anderer Effekt)";
    [fr] = "(Autres effets)";
    [pt] = "(Outros efeitos)";
    [ru] = "(Другой эффект)"
}
text.SequenceEditor.ConditionTypes.OtherEffectHelp = {
    [en] = "This plugin only knows about the effects that you have observed while the plugin is running.  If the desired effect is not included in the list, you must do whatever is necessary to make the effect appear on your character, so the plugin can ‘‘discover’’ it.";
    [de] = "Dieses Plugin erkennt nur solche Effekte, die beobachtet wurden während das Plugin aktiv ist. Sollte der gewünschte Effekt nicht in der Liste aufgeführt sein, dann muss dieser Effekt auf dem eigenen Charakter ausgelöst werden, damit das Plugin ihn ‚‚entdecken‘‘ kann.";
    [fr] = "Ce plugin ne reconnait que les effets utilisés quand le plugin est actif. Si l'effet désiré n'est pas inclus dans la liste, à vous de faire ce qu'il est nécessaire pour le faire apparaitre sur votre personnage afin que le plugin puisse le « découvrir ».";
    [pt] = "Este plugin apenas conhece efeitos que você observou enquanto o plugin esta carregado. Se o efeito desejado não está incluido na lista, você precisa fazer o que for necessário para que o efeito apareça em seu personagem, então o plugin poderá «descobri-lo».";
    [ru] = "Плагин хранит историю эффектов, полученных во время его работы. Чтобы эффект появился в списке, следует его «открыть»."
}
text.SequenceEditor.ConditionTypes.PlayerEffectDisease = {
    [en] = "Debuff: Disease";
    [de] = "Debuff: Krankheit";
    [fr] = "Debuff: Maladie";
    [pt] = "Debuff: Doença";
    [ru] = "Отриц. эффект: Болезнь"
}
text.SequenceEditor.ConditionTypes.PlayerEffectDiseaseCurable = {
    [en] = "Debuff: Disease (curable)";
    [de] = "Debuff: Krankheit (heilbar)";
    [fr] = "Debuff: Maladie (guérissable)";
    [pt] = "Debuff: Doença (curável)";
    [ru] = "Отриц. эффект: Болезнь (излечима)"
}
text.SequenceEditor.ConditionTypes.PlayerEffectFear = {
    [en] = "Debuff: Fear";
    [de] = "Debuff: Furcht";
    [fr] = "Debuff: Peur";
    [pt] = "Debuff: Medo";
    [ru] = "Отриц. эффект: Страх"
}
text.SequenceEditor.ConditionTypes.PlayerEffectFearCurable = {
    [en] = "Debuff: Fear (curable)";
    [de] = "Debuff: Furcht (heilbar)";
    [fr] = "Debuff: Peur (guérissable)";
    [pt] = "Debuff: Medo (curável)";
    [ru] = "Отриц. эффект: Страх (излечима)"
}
text.SequenceEditor.ConditionTypes.PlayerEffectPoison = {
    [en] = "Debuff: Poison";
    [de] = "Debuff: Gift";
    [fr] = "Debuff: Poison";
    [pt] = "Debuff: Veneno";
    [ru] = "Отриц. эффект: Яд"
}
text.SequenceEditor.ConditionTypes.PlayerEffectPoisonCurable = {
    [en] = "Debuff: Poison (curable)";
    [de] = "Debuff: Gift (heilbar)";
    [fr] = "Debuff: Poison (guérissable)";
    [pt] = "Debuff: Veneno (curável)";
    [ru] = "Отриц. эффект: Яд (излечима)"
}
text.SequenceEditor.ConditionTypes.PlayerEffectWound = {
    [en] = "Debuff: Wound";
    [de] = "Debuff: Wunde";
    [fr] = "Debuff: Blessure";
    [pt] = "Debuff: Ferida";
    [ru] = "Отриц. эффект: Ранение"
}
text.SequenceEditor.ConditionTypes.PlayerEffectWoundCurable = {
    [en] = "Debuff: Wound (curable)";
    [de] = "Debuff: Wunde (heilbar)";
    [fr] = "Debuff: Blessure (guérissable)";
    [pt] = "Debuff: Ferida (curável)";
    [ru] = "Отриц. эффект: Ранение (излечима)"
}
text.SequenceEditor.ConditionTypes.PlayerEffectOther = {
    [en] = "Effect is present";
    [de] = "Effekt aktiv";
    [fr] = "L'effet est présent";
    [pt] = "Efeito presente";
    [ru] = "Эффект присутствует"
}
text.SequenceEditor.ConditionTypes.NotPlayerEffectOther = {
    [en] = "Effect not present";
    [de] = "Effekt nicht aktiv";
    [fr] = "L'effet n'est pas présent";
    [pt] = "Efeito ausente";
    [ru] = "Эффект отсутствует"
}
text.SequenceEditor.ConditionTypes.TargetEffectDisease = {
    [en] = "Target has debuff: Disease";
    [de] = "Debuff auf Ziel aktiv: Krankheit";
    [fr] = "La cible a un debuff: Maladie";
    [pt] = "Alvo tem o debuff: Doença";
    [ru] = "Эффект цели: Болезнь"
}
text.SequenceEditor.ConditionTypes.TargetEffectFear = {
    [en] = "Target has debuff: Fear";
    [de] = "Debuff auf Ziel aktiv: Furcht";
    [fr] = "La cible a un debuff: Peur";
    [pt] = "Alvo tem o debuff: Medo";
    [ru] = "Эффект цели: Страх"
}
text.SequenceEditor.ConditionTypes.TargetEffectPoison = {
    [en] = "Target has debuff: Poison";
    [de] = "Debuff auf Ziel aktiv: Gift";
    [fr] = "La cible a un debuff: Poison";
    [pt] = "Alvo tem o debuff: Veneno";
    [ru] = "Эффект цели: Яд"
}
text.SequenceEditor.ConditionTypes.TargetEffectWound = {
    [en] = "Target has debuff: Wound";
    [de] = "Debuff auf Ziel aktiv: Wunde";
    [fr] = "La cible a un debuff: Blessure";
    [pt] = "Alvo tem o debuff: Ferida";
    [ru] = "Эффект цели: Ранение"
}
text.SequenceEditor.ConditionTypes.TargetEffectOther = {
    [en] = "Target has effect";
    [de] = "Effekt auf dem Ziel";
    [fr] = "L'effet est présent sur la cible";
    [pt] = "Alvo tem o efeito";
    [ru] = "Эффект цели: присутствует"
}
text.SequenceEditor.ConditionTypes.NotTargetEffectOther = {
    [en] = "Target doesn't have effect";
    [de] = "Effekt auf dem Ziel nicht aktiv ";
    [fr] = "L'effet n'est pas présent sur la cible";
    [pt] = "Alvo não possui o efeito";
    [ru] = "Эффект цели: отсутствует"
}
text.SequenceEditor.ConditionTypes.SkillReady = {
    [en] = "Skill is ready";
    [de] = "Fertigkeit steht zur Verfügung";
    [fr] = "La compétence est prête";
    [pt] = "Skill pronta";
    [ru] = "Умение готово"
}
text.SequenceEditor.ConditionTypes.SkillNotReady = {
    [en] = "Skill not ready";
    [de] = "Fertigkeit steht nicht zur Verfügung";
    [fr] = "La compétence n'est pas prête";
    [pt] = "Skill não está pronta";
    [ru] = "Умение не готово"
}
text.SequenceEditor.ConditionTypes.SkillUsable = {
    [en] = "Skill is usable";
    [de] = "Fertigkeit ist verwendbar";
    [fr] = "La compétence est utilisable";
    [pt] = "A skill é utilizável";
    [ru] = "Умение может использоваться"
}
text.SequenceEditor.ConditionTypes.SkillNotUsable = {
    [en] = "Skill not usable";
    [de] = "Fertigkeit ist nicht verwendbar";
    [fr] = "La compétence n'est pas utilisable";
    [pt] = "A skill não é utilizável";
    [ru] = "Умение не может использоваться"
}
text.SequenceEditor.ConditionTypes.SkillTrained = {
    [en] = "Skill is trained";
    [de] = "Fertigkeit ist bekannt";
    [fr] = "Compétence connue";
    [pt] = "Skill treinada";
    [ru] = "Умение известна"
}
text.SequenceEditor.ConditionTypes.SkillNotTrained = {
    [en] = "Skill not trained";
    [de] = "Fertigkeit ist nicht bekannt";
    [fr] = "Compétence inconnue";
    [pt] = "Skill não treinada";
    [ru] = "Умение не известна"
}
text.SequenceEditor.ConditionTypes["PlayerInCombat"] = {
    [en] = "In combat";
    [de] = "Im Kampf";
    [fr] = "En combat";
    [pt] = "Em combate";
    [ru] = "?"
}
text.SequenceEditor.ConditionTypes["PlayerOutOfCombat"] = {
    [en] = "Not in combat";
    [de] = "Außerhalb des Kampfes";
    [fr] = "Hors des combats";
    [pt] = "Não está em combate";
    [ru] = "?"
}
text.SequenceEditor.ConditionTypes["PlayerMorale < x"] = {
    [en] = "Morale < x";
    [de] = "Moral < x";
    [fr] = "Moral < x";
    [pt] = "Moral < x";
    [ru] = "Боевой дух < x"
}
text.SequenceEditor.ConditionTypes["PlayerMorale < x%"] = {
    [en] = "Morale < x%";
    [de] = "Moral < x%";
    [fr] = "Moral < x%";
    [pt] = "?";
    [ru] = "Боевой дух < x%"
}
text.SequenceEditor.ConditionTypes["PlayerMorale > x"] = {
    [en] = "Morale > x";
    [de] = "Moral > x";
    [fr] = "Moral > x";
    [pt] = "Moral > x";
    [ru] = "Боевой дух > x"
}
text.SequenceEditor.ConditionTypes["PlayerMorale > x%"] = {
    [en] = "Morale > x%";
    [de] = "Moral > x%";
    [fr] = "Moral > x%";
    [pt] = "Moral > x%";
    [ru] = "Боевой дух > x%"
}
text.SequenceEditor.ConditionTypes["TargetIsFellow"] = {
    [en] = "Target is in Fellowship/Raid";
    [de] = "Ziel ist in Gefährtengruppe/Schlachtzug";
    [fr] = "?";
    [pt] = "Alvo está em Fellowship/Raid";
    [ru] = "?"
}
text.SequenceEditor.ConditionTypes["TargetNotFellow"] = {
    [en] = "Target not in Fellowship/Raid";
    [de] = "Ziel nicht in Gefährtengruppe/Schlachtzug";
    [fr] = "?";
    [pt] = "Alvo não está em Fellowship/Raid";
    [ru] = "?"
}
text.SequenceEditor.ConditionTypes["TargetMorale < x"] = {
    [en] = "Target Morale < x";
    [de] = "Moral des Ziels < x";
    [fr] = "Moral de la cible < x";
    [pt] = "Moral do Alvo < x";
    [ru] = "Боевой дух цели < x"
}
text.SequenceEditor.ConditionTypes["TargetMorale < x%"] = {
    [en] = "Target Morale < x%";
    [de] = "Moral des Ziels < x%";
    [fr] = "Moral de la cible < x%";
    [pt] = "Moral do Alvo < x%";
    [ru] = "Боевой дух цели < x%"
}
text.SequenceEditor.ConditionTypes["TargetMorale > x"] = {
    [en] = "Target Morale > x";
    [de] = "Moral des Ziels > x";
    [fr] = "Moral de la cible > x";
    [pt] = "Moral do Alvo > x";
    [ru] = "Боевой дух цели > x"
}
text.SequenceEditor.ConditionTypes["TargetMorale > x%"] = {
    [en] = "Target Morale > x%";
    [de] = "Moral des Ziels > x%";
    [fr] = "Moral de la cible > x%";
    [pt] = "Moral do Alvo > x%";
    [ru] = "Боевой дух цели > x%"
}
text.SequenceEditor.ConditionTypes["PlayerPower < x"] = {
    [en] = "Power < x";
    [de] = "Kraft < x";
    [fr] = "Puissance < x";
    [pt] = "Energia < x";
    [ru] = "Энергия < x"
}
text.SequenceEditor.ConditionTypes["PlayerPower < x%"] = {
    [en] = "Power < x%";
    [de] = "Kraft < x%";
    [fr] = "Puissance < x%";
    [pt] = "Energia < x%";
    [ru] = "Энергия < x%"
}
text.SequenceEditor.ConditionTypes["PlayerPower > x"] = {
    [en] = "Power > x";
    [de] = "Kraft > x";
    [fr] = "Puissance > x";
    [pt] = "Energia > x";
    [ru] = "Энергия > x"
}
text.SequenceEditor.ConditionTypes["PlayerPower > x%"] = {
    [en] = "Power > x%";
    [de] = "Kraft > x%";
    [fr] = "Puissance > x%";
    [pt] = "Energia > x%";
    [ru] = "Энергия > x%"
}
text.SequenceEditor.ConditionTypes["TargetPower < x"] = {
    [en] = "Target Power < x";
    [de] = "Kraft des Ziels < x";
    [fr] = "Puissance de la cible < x";
    [pt] = "Energia do Alvo < x";
    [ru] = "Энергия цели < x"
}
text.SequenceEditor.ConditionTypes["TargetPower < x%"] = {
    [en] = "Target Power < x%";
    [de] = "Kraft des Ziels < x%";
    [fr] = "Puissance de la cible < x%";
    [pt] = "Energia do Alvo < x%";
    [ru] = "Энергия цели < x%"
}
text.SequenceEditor.ConditionTypes["TargetPower > x"] = {
    [en] = "Target Power > x";
    [de] = "Kraft des Ziels > x";
    [fr] = "Puissance de la cible > x";
    [pt] = "Energia do Alvo > x";
    [ru] = "Энергия цели > x"
}
text.SequenceEditor.ConditionTypes["TargetPower > x%"] = {
    [en] = "Target Power > x%";
    [de] = "Kraft des Ziels > x%";
    [fr] = "Puissance de la cible > x%";
    [pt] = "Energia do Alvo > x%";
    [ru] = "Энергия цели > x%"
}
text.SequenceEditor.ConditionTypes["ChampionPlayerFervor < x"] = {
    [en] = "Champion Fervour < x";
    [de] = "Waffenmeister: Leidenschaft < x";
    [fr] = "Ferveur du Champion < x";
    [pt] = "Fervor do Champion < x";
    [ru] = "?"
}
text.SequenceEditor.ConditionTypes["ChampionPlayerFervor > x"] = {
    [en] = "Champion Fervour > x";
    [de] = "Waffenmeister: Leidenschaft > x";
    [fr] = "Ferveur du Champion > x";
    [pt] = "Fervor do Champion > x";
    [ru] = "?"
}
text.SequenceEditor.ConditionTypes["BeorningPlayerWrath < x%"] = {
    [en] = "Beorning Wrath < x%";
    [de] = "Beorninger: Wut < x%";
    [fr] = "Colère du Beornide < x%";
    [pt] = "Ira do Beorning < x%";
    [ru] = "Беорнинг: ярость < x%"
}
text.SequenceEditor.ConditionTypes["BeorningPlayerWrath > x%"] = {
    [en] = "Beorning Wrath > x%";
    [de] = "Beorninger: Wut > x%";
    [fr] = "Colère du Beornide > x%";
    [pt] = "Ira do Beorning > x%";
    [ru] = "Беорнинг: ярость > x%"
}
text.SequenceEditor.ConditionTypes["BeorningInBearForm"] = {
    [en] = "Beorning in Bear Form";
    [de] = "Beorninger: Bärenform";
    [fr] = "Beornide sous forme d'ours";
    [pt] = "Beorning em Forma de Urso";
    [ru] = "Беорнинг: медведь"
}
text.SequenceEditor.ConditionTypes["BeorningNotInBearForm"] = {
    [en] = "Beorning Not in Bear Form";
    [de] = "Beorninger: nicht in Bärenform";
    [fr] = "Beornide sous forme humaine";
    [pt] = "Beorning em Forma Humana";
    [ru] = "Беорнинг: человек"
}
text.SequenceEditor.ConditionTypes["HunterFocus < x"] = {
    [en] = "Hunter Focus < x";
    [de] = "Jäger Fokus < x";
    [fr] = "Concentration du Chasseur < x";
    [pt] = "Foco do Hunter < x";
    [ru] = "Охотник Фокус < x"
}
text.SequenceEditor.ConditionTypes["HunterFocus > x"] = {
    [en] = "Hunter Focus > x";
    [de] = "Jäger Fokus > x";
    [fr] = "Concentration du Chasseur > x";
    [pt] = "Foco do Hunter > x";
    [ru] = "Охотник Фокус > x"
}
text.SequenceEditor.ConditionTypes["RunekeeperAttunement < x"] = {
    [en] = "Runekeeper Attunement < x";
    [de] = "Runenbewahrer Einstimmung < x";
    [fr] = "Equilibrage du Gardien des runes < x";
    [pt] = "?";
    [ru] = "?"
}
text.SequenceEditor.ConditionTypes["RunekeeperAttunement > x"] = {
    [en] = "Runekeeper Attunement > x";
    [de] = "Runenbewahrer Einstimmung > x";
    [fr] = "Equilibrage du Gardien des runes > x";
    [pt] = "Attunement do Runekeeper > x";
    [ru] = "?"
}
text.SequenceEditor.ConditionTypes["RunekeeperCharged"] = {
    [en] = "Runekeeper is charged";
    [de] = "Runenbewahrer ist geladen";
    [fr] = "Gardien des runes chargé";
    [pt] = "Runekeeper está carregado";
    [ru] = "?"
}
text.SequenceEditor.ConditionTypes["RunekeeperNotCharged"] = {
    [en] = "Runekeeper not charged";
    [de] = "Runenbewahrer nicht geladen";
    [fr] = "Gardien des runes déchargé";
    [pt] = "Runekeeper não carregado";
    [ru] = "?"
}
text.SequenceEditor.ConditionTypes["ItemEquipped"] = {
    [en] = "Item is equipped";
    [de] = "Gegenstand ist ausgerüstet";
    [fr] = "L'objet est équipé";
    [pt] = "Item está equipado";
    [ru] = "Снаряжение используется"
}
text.SequenceEditor.ConditionTypes["ItemNotEquipped"] = {
    [en] = "Item not equipped";
    [de] = "Gegenstand ist nicht ausgerüstet";
    [fr] = "L'objet n'est pas équipé";
    [pt] = "Item não equipado";
    [ru] = "Снаряжение не используется"
}
text.SequenceEditor.ConditionTypes["ItemQuantity > x"] = {
    [en] = "Item quantity > x";
    [de] = "Gegenstandsmenge > x";
    [fr] = "Nombre d'objets > x";
    [pt] = "Quantidade de item > x";
    [ru] = "?"
}
text.SequenceEditor.ConditionTypes["ItemQuantity < x"] = {
    [en] = "Item quantity < x";
    [de] = "Gegenstandsmenge < x";
    [fr] = "Nombre d'objets < x";
    [pt] = "Quantidade de item < x";
    [ru] = "?"
}
text.SequenceEditor.ConditionTypes["StanceSelected"] = {
    [en] = "Stance";
    [de] = "Haltung";
    [fr] = "Posture";
    [pt] = "Stance";
    [ru] = "?"
}
text.SequenceEditor.Stance = {};
text.SequenceEditor.Stance["0"] = {
    [en] = "Melody (Minstrel) / None";
    [de] = "Melodie (Barde) / Keiner";
    [fr] = "Mélodie (Ménestrel) / Aucun";
    [pt] = "Melody (Minstrel / Nenhuma)";
    [ru] = "?"
};
text.SequenceEditor.Stance["1"] = {
    [en] = "Precision (Hunter) / Dissonance (Minstrel)";
    [de] = "Präzision (Jäger) / Dissonanz (Barde)";
    [fr] = "Précision (Chasseur) / Dissonance (Ménestrel)";
    [pt] = "Pecision (Hunter) / Dissonance (Minstrel)";
    [ru] = "?"
};
text.SequenceEditor.Stance["2"] = {
    [en] = "Strength (Hunter) / Resonance (Minstrel) / In the Fray (Warden)";
    [de] = "Stärke (Jäger) / Resonanz (Barde) / Im Gefecht (Hüter)";
    [fr] = "Force (Chasseur) / Résonance (Ménestrel) / Dans le feu de L'action (Sentinelle)";
    [pt] = "Strength (Hunter) / Resonance (Minstrel) / In the Fray (Warden)";
    [ru] = "?"
};
text.SequenceEditor.Stance["3"] = {
    [en] = "Endurance (Hunter) / Assailment (Warden)";
    [de] = "Ausdauer (Jäger) / Bestürmung (Hüter)";
    [fr] = "Endurance (Chasseur) / Assaut (Sentinelle)";
    [pt] = "Endurance (Hunter) / Assailment (Warden)";
    [ru] = "?"
};
text.SequenceEditor.ConditionTypes["LuaScript"] = {
    [en] = "~Lua Script~";
    [de] = "~Lua Script~";
    [fr] = "~Lua Script~";
    [pt] = "~Lua Script~";
    [ru] = "~Выражение Lua~"
}
text.SequenceEditor.Untrained = {
    [en] = "untrained";
    [de] = "unbekannt";
    [fr] = "inconnue";
    [pt] = "destreinado";
    [ru] = "?"
}
text.SequenceEditor.AnyEqItem = {
    [en] = "(Any item)";
    [de] = "(Irgendein Gegenstand)";
    [fr] = "(N'importe quel objet)";
    [pt] = "(Qualquer item)";
    [ru] = "(Любой предмет)"
}
text.SequenceEditor.AnyEqSlot = {
    [en] = "(Any slot)";
    [de] = "(Irgendein Feld)";
    [fr] = "(N'importe quel emplacement)";
    [pt] = "(Qualquer slot)";
    [ru] = "(Любой тип)"
}
text.SequenceEditor.ShortcutType = {
    [en] = "Type";
    [de] = "Eingeben";
    [fr] = "Type";
    [pt] = "Tipo";
    [ru] = "Тип"
}
text.SequenceEditor.ShortcutTypes = {}
text.SequenceEditor.ShortcutTypes.Alias = {
    [en] = "Alias";
    [de] = "Alias";
    [fr] = "Alias";
    [pt] = "Alias";
    [ru] = "Псевдоним"
}
text.SequenceEditor.ShortcutTypes.Hobby = {
    [en] = "Hobby";
    [de] = "Hobby";
    [fr] = "Loisir";
    [pt] = "Hobby";
    [ru] = "Хобби"
}
text.SequenceEditor.ShortcutTypes.Item = {
    [en] = "Item";
    [de] = "Gegenstand";
    [fr] = "Article";
    [pt] = "Item";
    [ru] = "Предмет"
}
text.SequenceEditor.ShortcutTypes.Pet = {
    [en] = "Pet";
    [de] = "Zierwerksbegleiter";
    [fr] = "Animal familier";
    [pt] = "Pet";
    [ru] = "Питомец"
}
text.SequenceEditor.ShortcutTypes.Skill = {
    [en] = "Skill";
    [de] = "Fertigkeit";
    [fr] = "Compétence";
    [pt] = "Skill";
    [ru] = "Умение"
}
text.SequenceEditor.ShortcutTypes.Emote = {
    [en] = "Emote";
    [de] = "Emote";
    [fr] = "Emote";
    [pt] = "Emote";
    [ru] = "эмоция"
}
text.SequenceEditor.ShortcutTypes.Undefined = {
    [en] = "Undefined";
    [de] = "undefiniert";
    [fr] = "Non-défini";
    [pt] = "Não definido";
    [ru] = "Н/Д"
}
text.SequenceEditor.ShortcutTypes.Undef = text.SequenceEditor.ShortcutTypes.Undefined;
text.SequenceEditor.Activation = {
    [en] = "Activation";
    [de] = "Aktivierung";
    [fr] = "Activation";
    [pt] = "Ativação";
    [ru] = "Срабатывание"
}
text.SequenceEditor.WithLeftClick = {
    [en] = "with left-click";
    [de] = "durch Linksklick";
    [fr] = "avec clic-gauche";
    [pt] = "com botão esquerdo";
    [ru] = "Левая кнопка мыши"
}
text.SequenceEditor.Automatic = {
    [en] = "automatic";
    [de] = "automatisch";
    [fr] = "automatique";
    [pt] = "automático";
    [ru] = "Автоматически"
}
text.SequenceEditor.AdvanceToNextSlot = {
    [en] = "Advance to next slot";
    [de] = "zum nächsten Feld übergehen";
    [fr] = "Avancer au prochain emplacement";
    [pt] = "Avance para o próximo slot";
    [ru] = "Переход к след. ячейке"
}
text.SequenceEditor.WhenItemEquipped = {
    [en] = "when item is equipped";
    [de] = "wenn der Gegenstand ausgerüstet ist";
    [fr] = "quand cet objet est équippé";
    [pt] = "quando o item está equipado";
    [ru] = "Если предмет экипирован"
}
text.SequenceEditor.WhenSkillExecuted = {
    [en] = "when skill is executed";
    [de] = "wenn die Fertigkeit ausgeführt ist";
    [fr] = "quand la compétence est exécutée";
    [pt] = "quando a skill é executada";
    [ru] = "?"
}
text.SequenceEditor.UseAlternateDetectMethod = {
    [en] = "Use secondary detection method";
    [de] = "Sekundäres Erkennungsverfahren verwenden";
    [fr] = "Util. méthode de détection secondaire†";
    [pt] = "Use metedo de detecção secundário";
    [ru] = "?"
}
text.SequenceEditor.RequireTarget = {
	[en] = "Require target";
	[de] = "Erfordern ein Ziel";
	[fr] = "Nécessite une cible";
    [pt] = "Alvo necessário";
	[ru] = "Требовать цель†";
}
text.SequenceEditor.OtherSequence = {
    [en] = "Other Sequence";
    [de] = "andere Sequenz";
    [fr] = "Autre sequence";
    [pt] = "Outra Sequência";
    [ru] = "Порядок панели"
}
text.SequenceEditor.Unlink = {
    [en] = "Unlink";
    [de] = "trennen";
    [fr] = "Délier";
    [pt] = "Desvincular";
    [ru] = "Перенести в эту"
}
text.SequenceEditor.UnlinkButtonWidth = {
    [en] = 75;
    [de] = 85;
    [fr] = 75;
    [pt] = 100;
    [ru] = 100
}
text.SequenceEditor.RightClickMenu = {};
text.SequenceEditor.RightClickMenu.CloneSlot = {
    [en] = "Clone slot";
    [de] = "Feld klonen";
    [fr] = "Dupliquer l'emplacement";
    [pt] = "Clonar slot";
    [ru] = "Скопировать ячейку"
};
text.SequenceEditor.RightClickMenu.InsertEmptySlot = {
    [en] = "Insert empty slot";
    [de] = "Leeres Feld einfügen";
    [fr] = "Insérer un emplacement vide";
    [pt] = "Inserir slot vazio";
    [ru] = "Вставить пустую ячейку"
};
text.SequenceEditor.RightClickMenu.DeleteSlot = {
    [en] = "Delete slot";
    [de] = "Feld löschen";
    [fr] = "Effacer l'emplacement";
    [pt] = "Deletar slot";
    [ru] = "Очистить ячейку"
};
text.SequenceEditor.RightClickMenu.CreateSpecialSlot = {
    [en] = "Insert special slot";
    [de] = "Spezielles Feld einfügen";
    [fr] = "Insérer un emplacement spécial";
    [pt] = "Inserir slot especial";
    [ru] = "Вставить особую ячейку"
};
text.SequenceEditor.RightClickMenu.SpecialSlotMenu = {};
text.SequenceEditor.RightClickMenu.SpecialSlotMenu.RemoveEquipment = {
    [en] = "Remove equipment";
    [de] = "Ausrüstung entfernen";
    [fr] = "Enlever l'equipement";
    [pt] = "Remover equipamento";
    [ru] = "Снять снаряжение"
};
text.SequenceEditor.RightClickMenu.SpecialSlotMenu.ChatCommand = {
    [en] = "Chat command";
    [de] = "Chatbefehl";
    [fr] = "Commande de discussion";
    [pt] = "Comando de chat";
    [ru] = "Команда чата"
}
text.SequenceEditor.RightClickMenu.SpecialSlotMenu.StopAnimating = {
    [en] = "Stop animating";
    [de] = "Animation stoppen";
    [fr] = "Arrêter l'animation";
    [pt] = "Parar animação";
    [ru] = "Остановить анимацию"
};
text.SequenceEditor.RightClickMenu.SpecialSlotMenu.GenerateEvent = {
    [en] = "Generate user event";
    [de] = "Benutzerdefiniertes Ereignis erstellen";
    [fr] = "Générer un évènement utilisateur";
    [pt] = "Gerar evento de usuário";
    [ru] = "Вызвать событие"
};
text.SequenceEditor.RightClickMenu.SpecialSlotMenu.SetUnequipDestination = {
    [en] = "Set unequip destination";
    [de] = "Ziel für das Ablegen von Ausrüstung festlegen";
    [fr] = "Définir la destination pour deséquiper";
    [pt] = "Definir destino de desequipamento";
    [ru] = "Место снаряжения в сумках";
};
text.SequenceEditor.RightClickMenu.SpecialSlotMenu.IfThen = {
    [en] = "Conditional (if...then...)";
    [de] = "Bedingt (wenn...dann...)";
    [fr] = "Conditionnel (si...alors...)";
    [pt] = "Condicional (se... entao...";
    [ru] = "Условие (если ... то ...)";
};
text.SequenceEditor.RightClickMenu.SpecialSlotMenu.Delay = {
    [en] = "Delay";
    [de] = "Verzögerung";
    [fr] = "Delai";
    [pt] = "Atraso";
    [ru] = "?";
};
text.SequenceEditor.RightClickMenu.SpecialSlotMenu.SelectTarget = {
    [en] = "Select target";
    [de] = "Ziel auswählen";
    [fr] = "Sélectionner la cible";
    [pt] = "Selecionar alvo";
    [ru] = "?";
};
text.SequenceEditor.RightClickMenu.SpecialSlotMenu.SaveTarget = {
    [en] = "Save target";
    [de] = "Ziel speichern";
    [fr] = "Enregistrer la cible";
    [pt] = "Salvar alvo";
    [ru] = "?";
};
text.SequenceEditor.RightClickMenu.SpecialSlotMenu.LuaScript = {
    [en] = "Lua Script";
    [de] = "Lua Script";
    [fr] = "Lua Script";
    [pt] = "Lua Script";
    [ru] = "Выражение Lua"
}
text.SequenceEditor.Target = {
    [en] = "Target";
    [de] = "Ziel";
    [fr] = "?";
    [pt] = "Alvo";
    [ru] = "?";
};
text.SequenceEditor.NoTarget = {
    [en] = "(None)";
    [de] = "(Keiner)";
    [fr] = "(Aucun)";
    [pt] = "(Nenhum))";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu = {};
text.SequenceEditor.TargetMenu.Self = {
    [en] = "Self";
    [de] = "Selbst";
    [fr] = "?";
    [pt] = "Si Próprio";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.Pet = {
    [en] = "Pet";
    [de] = "Zierwerksbegleiter";
    [fr] = "?";
    [pt] = "Pet";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.CurrentTarget = {
    [en] = "Current target (no change)";
    [de] = "Aktuelles Ziel (kein Wechsel)";
    [fr] = "?";
    [pt] = "Alvo atual (sem mudança)";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.CurrentTargetsTarget = {
    [en] = "Current target's target";
    [de] = "Ziel des aktuellen Ziels";
    [fr] = "?";
    [pt] = "Alvo do alvo atual";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.SavedTarget = {
    [en] = "Saved target";
    [de] = "Gespeichertes Ziel";
    [fr] = "?";
    [pt] = "Alvo salvo";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.RaidLeader = {
    [en] = "Raid leader";
    [de] = "Schlachtzugführer";
    [fr] = "?";
    [pt] = "Líder da Raid";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.RaidMemberByName = {
    [en] = "Raid member (by name)";
    [de] = "Raidteilnehmer (nach Namen)";
    [fr] = "?";
    [pt] = "Membro da Raid (por nome)";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.NextRaidMember = {
    [en] = "Next raid member";
    [de] = "Nächster Raidteilnehmer";
    [fr] = "?";
    [pt] = "Próximo membro da raid";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.FirstAssistee = {
    [en] = "Assistee 1";
    [de] = "Zielvorgeber 1";
    [fr] = "?";
    [pt] = "Alvo 1";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.FirstAssisteesTarget = {
    [en] = "Assistee 1 target";
    [de] = "Ziel von Zielvorgeber 1";
    [fr] = "?";
    [pt] = "Alvo do Alvo 1";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.SecondAssistee = {
    [en] = "Assistee 2";
    [de] = "Zielvorgeber 2";
    [fr] = "?";
    [pt] = "Alvo 2";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.SecondAssisteesTarget = {
    [en] = "Assistee 2 target";
    [de] = "Ziel von Zielvorgeber 1";
    [fr] = "?";
    [pt] = "Alvo do Alvo 2";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.ThirdAssistee = {
    [en] = "Assistee 3";
    [de] = "Zielvorgeber 3";
    [fr] = "?";
    [pt] = "Alvo 3";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.ThirdAssisteesTarget = {
    [en] = "Assistee 3 target";
    [de] = "Ziel von Zielvorgeber 3";
    [fr] = "?";
    [pt] = "Alvo do Alvo 3";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.FourthAssistee = {
    [en] = "Assistee 4";
    [de] = "Zielvorgeber 4";
    [fr] = "?";
    [pt] = "Alvo 4";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.FourthAssisteesTarget = {
    [en] = "Assistee 4 target";
    [de] = "Ziel von Zielvorgeber 4";
    [fr] = "?";
    [pt] = "Alvo do Alvo 4";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.NextAssistee = {
    [en] = "Next assistee";
    [de] = "Nächster Zielvorgeber";
    [fr] = "?";
    [pt] = "P";
    [ru] = "?";
};
text.SequenceEditor.TargetMenu.NextAssisteesTarget = {
    [en] = "Next assistee's target";
    [de] = "Ziel des nächsten Zielvorgebers";
    [fr] = "?";
    [pt] = "Próximo alvo do alvo";
    [ru] = "?";
};
text.SequenceEditor.TargetNumber = {
    [en] = "Target number";
    [de] = "Zielnummer";
    [fr] = "?";
    [pt] = "Número do alvo";
    [ru] = "?";
};
text.SequenceEditor.SaveTargetWarning = {
    [en] = "Please note: This feature works only for allies, not foes.";
    [de] = "Achtung: Diese Option funktioniert nur für Gefährten, nicht für Gegner.";
    [fr] = "Remarque : cette fonction ne fonctionne que pour les alliés, pas pour les ennemis.†";
    [pt] = "Nota: Esse recurso funciona apenas para aliados, não inimigos.";
    [ru] = "?";
};
text.SequenceEditor.SaveTargetWarningHeight = {
    [en] = 3;
    [de] = 4;
    [fr] = 3;
    [pt] = 3;
    [ru] = 3;
};
text.SequenceEditor.DelayPeriod = {
    [en] = "Period";
    [de] = "Zeit";
    [fr] = "Durée";
    [pt] = "Periodo";
    [ru] = "?";
};
text.SequenceEditor.Seconds = {
    [en] = "seconds";
    [de] = "Sekunden";
    [fr] = "secondes";
    [pt] = "segundos";
    [ru] = "секунд";
};
text.SequenceEditor.RightClickMenu.SpecialSlotMenu.IfThenElse = {
    [en] = "Conditional (if...then...else...)";
    [de] = "Bedingt (wenn...dann...sonst)";
    [fr] = "Conditionnel (si...alors...sinon...)";
    [pt] = "Condicianal (if...then...else...)";
    [ru] = "Условие (если ... то ... иначе ...)";
};
text.SequenceEditor.If = {
    [en] = "IF";
    [de] = "WENN";
    [fr] = "SI";
    [pt] = "IF";
    [ru] = "ЕСЛИ";
};
text.SequenceEditor.Else = {
    [en] = "ELSE";
    [de] = "SONST";
    [fr] = "SINON";
    [pt] = "ELSE";
    [ru] = "ИНАЧЕ";
};
text.SequenceEditor.EndIf = {
    [en] = "END-IF";
    [de] = "ENDE-WENN";
    [fr] = "FIN-SI";
    [pt] = "END-IF";
    [ru] = "КОНЕЦ ЕСЛИ";
};
text.SequenceEditor.RightClickMenu.SpecialSlotMenu.Include = {
    [en] = "Include other sequence";
    [de] = "Weitere Sequenz einbeziehen";
    [fr] = "Inclure une autre séquence";
    [pt] = "Incluir outra sequência";
    [ru] = "Порядок другой панели"
}
text.SequenceEditor.RemoveItem = {
    [en] = "Remove <item>";
    [de] = "<item> entfernen";
    [fr] = "Enlever <item>";
    [pt] = "Remover <item>";
    [ru] = "Снять: <item>"
};
text.SequenceEditor.PreferredBagSlot = {
    [en] = "Preferred bag slot(s)";
    [de] = "bevorzugtes Inventarfeld(er)";
    [fr] = "Emplacement(s) de sac préféré";
    [pt] = "Slot(s) preferido(s) da bolsa.";
    [ru] = "Желаемая ячейка сумок"
}
text.SequenceEditor.EquipmentType = {
    [en] = "Equipment type";
    [de] = "Ausrüstungstyp";
    [fr] = "Emplacement de sac préféré";
    [pt] = "Tipo de equipamento";
    [ru] = "Тип снаряжения"
}
text.SequenceEditor.EquipmentSlots = {};
text.SequenceEditor.EquipmentSlots.Back = {
    [en] = "backpack / cape";
    [de] = "Rucksack / Umhang";
    [fr] = "sac à dos / cape";
    [pt] = "mochila / capa";
    [ru] = "котомка / плащ"
};
text.SequenceEditor.EquipmentSlots.Boots = {
    [en] = "boots";
    [de] = "Stiefel / Schuhe";
    [fr] = "bottes";
    [pt] = "botas";
    [ru] = "обувь"
};
text.SequenceEditor.EquipmentSlots.Bracelet1 = {
    [en] = "left bracelet";
    [de] = "linkes Armband";
    [fr] = "bracelet gauche";
    [pt] = "bracelete esquerdo";
    [ru] = "левый браслет"
};
text.SequenceEditor.EquipmentSlots.Bracelet2 = {
    [en] = "right bracelet";
    [de] = "rechtes Armband";
    [fr] = "bracelet droit";
    [pt] = "bracelete direito";
    [ru] = "правый браслет"
};
text.SequenceEditor.EquipmentSlots.Bridle = {
    [en] = "bridle";
    [de] = "Zaumzeug";
    [fr] = "bride";
    [pt] = "rédea";
    [ru] = "уздечка"
};
text.SequenceEditor.EquipmentSlots.Chest = {
    [en] = "shirt";
    [de] = "Hemd";
    [fr] = "buste";
    [pt] = "camisa";
    [ru] = "нагрудник"
};
text.SequenceEditor.EquipmentSlots.Class = {
    [en] = "class item";
    [de] = "Klassengegenstand";
    [fr] = "objet de classe";
    [pt] = "item de classe";
    [ru] = "классовый предмет"
};
text.SequenceEditor.EquipmentSlots.CraftTool = {
    [en] = "crafting tool";
    [de] = "Werkzeug";
    [fr] = "outil d'artisanat";
    [pt] = "ferramenta de profissão";
    [ru] = "ремесл. инструмент"
};
text.SequenceEditor.EquipmentSlots.Earring1 = {
    [en] = "left earring";
    [de] = "linker Ohrring";
    [fr] = "boucle d'oreille gauche";
    [pt] = "brinco esquerdo";
    [ru] = "левая серьга"
};
text.SequenceEditor.EquipmentSlots.Earring2 = {
    [en] = "right earring";
    [de] = "rechter Ohrring";
    [fr] = "boucle d'oreille droite";
    [pt] = "brinco direito";
    [ru] = "правая серьга"
};
text.SequenceEditor.EquipmentSlots.Gloves = {
    [en] = "gloves";
    [de] = "Handschuhe";
    [fr] = "gants";
    [pt] = "luvas";
    [ru] = "перчатки"
};
text.SequenceEditor.EquipmentSlots.Head = {
    [en] = "headgear";
    [de] = "Kopfbedeckung";
    [fr] = "équipement de tête";
    [pt] = "elmo";
    [ru] = "головной убор"
};
text.SequenceEditor.EquipmentSlots.Instrument = {
    [en] = "musical instrument";
    [de] = "Musikinstrument";
    [fr] = "instrument de musique";
    [pt] = "instrumento musical";
    [ru] = "муз. инструмент"
};
text.SequenceEditor.EquipmentSlots.Legs = {
    [en] = "legwear";
    [de] = "Beinkleider";
    [fr] = "jambière";
    [pt] = "calças";
    [ru] = "штаны"
};
text.SequenceEditor.EquipmentSlots.Necklace = {
    [en] = "necklace";
    [de] = "Halskette";
    [fr] = "collier";
    [pt] = "colar";
    [ru] = "ожерелье"
};
text.SequenceEditor.EquipmentSlots.Pocket = {
    [en] = "pocket item";
    [de] = "Beutelitem";
    [fr] = "objet de poche";
    [pt] = "item de bolso";
    [ru] = "предмет в кармане"
};
text.SequenceEditor.EquipmentSlots.PrimaryWeapon = {
    [en] = "primary weapon";
    [de] = "Hauptwaffe";
    [fr] = "arme principale";
    [pt] = "arma primária";
    [ru] = "основное оружие"
};
text.SequenceEditor.EquipmentSlots.RangedWeapon = {
    [en] = "ranged weapon";
    [de] = "Fernkampfwaffe";
    [fr] = "arme à distance";
    [pt] = "arma à distância";
    [ru] = "оружие д. боя"
};
text.SequenceEditor.EquipmentSlots.Ring1 = {
    [en] = "left ring";
    [de] = "linker Ring";
    [fr] = "anneau gauche";
    [pt] = "anel esquerdo";
    [ru] = "левое кольцо"
};
text.SequenceEditor.EquipmentSlots.Ring2 = {
    [en] = "right ring";
    [de] = "rechter Ring";
    [fr] = "anneau droit";
    [pt] = "anel direito";
    [ru] = "правое кольцо"
};
text.SequenceEditor.EquipmentSlots.SecondaryWeapon = {
    [en] = "secondary weapon";
    [de] = "Zweitwaffe";
    [fr] = "arme secondaire";
    [pt] = "arma secundária";
    [ru] = "доп. оружие"
};
text.SequenceEditor.EquipmentSlots.Shield = {
    [en] = "shield";
    [de] = "Schild";
    [fr] = "bouclier";
    [pt] = "escudo";
    [ru] = "щит"
};
text.SequenceEditor.EquipmentSlots.Shoulder = {
    [en] = "shoulders";
    [de] = "Schultern";
    [fr] = "épaules";
    [pt] = "ombreiras";
    [ru] = "наплечники"
};

-- "Event behaviours" submenu appearing in both the Group and Bar right-click menus
text.EventBehaviorsMenu = {};
text.EventBehaviorsMenu.EnableEvents = {
    [en] = "Enable";
    [de] = "Aktivieren";
    [fr] = "Activer";
    [pt] = "Ativado";
    [ru] = "Включить"
}
text.EventBehaviorsMenu.DisableEvents = {
    [en] = "Disable";
    [de] = "Deaktivieren";
    [fr] = "Désactiver";
    [pt] = "Desativado";
    [ru] = "Отключить"
}
text.EventBehaviorsMenu.Remove = {
    [en] = "Remove";
    [de] = "Entfernen";
    [fr] = "Enlever";
    [pt] = "Remover";
    [ru] = "Удалить"
}
text.EventBehaviorsMenu.CurrentBehaviors = {
    [en] = "Current behaviours";
    [de] = "Aktuelles Verhalten";
    [fr] = "Comportement actuel";
    [pt] = "Comportamentos atuais";
    [ru] = "Текущие реакции"
}
text.EventBehaviorsMenu.AddBehavior = {
    [en] = "Add behaviour";
    [de] = "Verhaltensregel hinzufügen";
    [fr] = "Ajouter un comportement";
    [pt] = "Adicionar comportamento";
    [ru] = "Добавить реакцию"
}
-- Actions
text.EventBehaviorsMenu.Actions = {};
text.EventBehaviorsMenu.Actions.ShowGroup = {
    [en] = "Show group";
    [de] = "Gruppe anzeigen";
    [fr] = "Montrer le groupe";
    [pt] = "Mostrar grupo";
    [ru] = "Показать группу"
}
text.EventBehaviorsMenu.Actions.HideGroup = {
    [en] = "Hide group";
    [de] = "Gruppe ausblenden";
    [fr] = "Cacher le groupe";
    [pt] = "Esconder grupo";
    [ru] = "Скрыть группу"
}
text.EventBehaviorsMenu.Actions.ResetGroup = {
    [en] = "Reset group";
    [de] = "Gruppe zurücksetzen";
    [fr] = "Réinitialiser le groupe";
    [pt] = "Redefinir grupo";
    [ru] = "Сбросить группу"
}
text.EventBehaviorsMenu.Actions.ExpandGroup = {
    [en] = "Expand group";
    [de] = "Gruppe ausklappen";
    [fr] = "Déplier le groupe";
    [pt] = "Expandir grupo";
    [ru] = "?"
}
text.EventBehaviorsMenu.Actions.CollapseGroup = {
    [en] = "Collapse group";
    [de] = "Gruppe einklappen";
    [fr] = "Replier le groupe";
    [pt] = "Recolher grupo";
    [ru] = "?"
}
text.EventBehaviorsMenu.Actions.SetGroupTransparency = {
    [en] = "Set transparency for all bars to";
    [de] = "Transparenz für alle Leisten einstellen auf";
    [fr] = "Définir la transparence pour toutes les barres à";
    [pt] = "Definir transparência para todas as barras";
    [ru] = "?"
}
text.EventBehaviorsMenu.Actions.SetTransparency = {
    [en] = "Set transparency to";
    [de] = "Transparenz einstellen auf";
    [fr] = "Définir la transparence à";
    [pt] = "Definir transparência para";
    [ru] = "?"
}
text.EventBehaviorsMenu.Actions.ShowBar = {
    [en] = "Show bar";
    [de] = "Leiste anzeigen";
    [fr] = "Montrer la barre";
    [pt] = "Mostrar barra";
    [ru] = "Показать панель"
}
text.EventBehaviorsMenu.Actions.HideBar = {
    [en] = "Hide bar";
    [de] = "Leiste ausblenden";
    [fr] = "Cacher la barre";
    [pt] = "Esconder barra";
    [ru] = "Скрыть панель"
}
text.EventBehaviorsMenu.Actions.ResetBar = {
    [en] = "Reset bar";
    [de] = "Leiste zurücksetzen";
    [fr] = "Réinitialiser la barre";
    [pt] = "Redefinir barra";
    [ru] = "Сбросить панель"
}
text.EventBehaviorsMenu.Actions.ExpandBar = {
    [en] = "Expand bar";
    [de] = "Leiste ausklappen";
    [fr] = "Déplier la barre";
    [pt] = "Expandir barra";
    [ru] = "?"
}
text.EventBehaviorsMenu.Actions.CollapseBar = {
    [en] = "Collapse bar";
    [de] = "Leiste einklappen";
    [fr] = "Replier la barre";
    [pt] = "Recolher barra";
    [ru] = "?"
}
text.EventBehaviorsMenu.Actions.MoveToCursor = {
    [en] = "Move bar under mouse cursor";
    [de] = "Leiste unter dem Mauszeiger bewegen";
    [fr] = "Bouger la barre sous le curseur de la souris";
    [pt] = "Mover barra para posição do ponteiro do mouse";
    [ru] = "Переместить панель к указателю мыши"
}
text.EventBehaviorsMenu.Actions.StartExecuting = {
    [en] = "Start executing";
    [de] = "Ausführung starten";
    [fr] = "Lancer l'exécution";
    [pt] = "Comece a executar";
    [ru] = "?"
}
text.EventBehaviorsMenu.Actions.StopExecuting = {
    [en] = "Stop executing";
    [de] = "Ausführung stoppen";
    [fr] = "Arrêter l'exécution";
    [pt] = "Pare de executar";
    [ru] = "?"
}
text.EventBehaviorsMenu.Triggers = {};
text.EventBehaviorsMenu.Triggers.AtStartup = {
    [en] = "at startup";
    [de] = "beim Start";
    [fr] = "au démarage";
    [pt] = "na inicialização";
    [ru] = "при загрузке плагина"
}
text.EventBehaviorsMenu.Triggers.WhenTargetChanges = {
    [en] = "when target changes";
    [de] = "wenn sich das Ziel ändert";
    [fr] = "quand la cible change";
    [pt] = "quando o alvo mudar";
    [ru] = "?"
}
text.EventBehaviorsMenu.Triggers.WhenCombatBegins = {
    [en] = "when combat begins";
    [de] = "wenn der Kampf beginnt";
    [fr] = "quand le combat commence";
    [pt] = "quando o combate começa";
    [ru] = "при начале боя"
}
text.EventBehaviorsMenu.Triggers.WhenCombatEnds = {
    [en] = "when combat ends";
    [de] = "wenn der Kampf endet";
    [fr] = "quand le combat finit";
    [pt] = "quando o combate termina";
    [ru] = "при завершении боя"
}
text.EventBehaviorsMenu.Triggers.WhenEventOccurs = {
    [en] = "when user event occurs";
    [de] = "bei Eintreten eines benutzerdefinierten Ereignisses";
    [fr] = "quand un évènement survient";
    [pt] = "quando um evento do usuário ocorrer";
    [ru] = "при вызове события"
}
text.EventBehaviorsMenu.NoEventsDefined = {
    [en] = "(No events defined)";
    [de] = "(kein Ereignis definiert)";
    [fr] = "(pas d'évènement défini)";
    [pt] = "(nenhum evento definido)";
    [ru] = "?"
}
text.EventBehaviorsMenu.Triggers.WhenMouseArrives = {
    [en] = "when mouse arrives";
    [de] = "bei Ankunft der Maus";
    [fr] = "quand la souris se rapproche";
    [pt] = "quando o mouse chega";
    [ru] = "если указатель мыши появился в пределах панели"
}
text.EventBehaviorsMenu.Triggers.WhenMouseDeparts = {
    [en] = "when mouse departs";
    [de] = "bei Entfernen der Maus";
    [fr] = "quand la souris s'écarte";
    [pt] = "quando o mouse sai";
    [ru] = "если указатель мыши покинул пределы панели"
}
text.EventBehaviorsMenu.Triggers.WhenTraitTreeChanges = {
    [en] = "when trait tree changes";
    [de] = "wenn sich der Eigenschaftsbaum ändert";
    [fr] = "quand l'arbre de traits change";
    [pt] = "quando a Trait Tree muda";
    [ru] = "?"
}
text.EventBehaviorsMenu.Triggers.WhenStanceChanges = {
    [en] = "when stance changes";
    [de] = "wenn sich die Haltung ändert";
    [fr] = "quand la posture change";
    [pt] = "quando a Stance muda";
    [ru] = "?"
}

-- Add translations to the global database (see Thurallor.Common.Utils.Locale.lua)
L:AddText(text);
