ImportWindow = class(Turbine.UI.Lotro.Window);

function ImportWindow:Constructor(title, object)
    Turbine.UI.Lotro.Window.Constructor(self);
    self:SetVisible(true);
    self:SetSize(320, 90);
    self:SetText(title);
    self.object = object;
    CenterWindow(self);
    self:SetZOrder(2147483647);
        
    local prevContext = L:SetContext("/ImportWindow");
    local label = Turbine.UI.Label();
    self.label = label;
    label:SetParent(self);
    label:SetFont(Turbine.UI.Lotro.Font.TrajanPro14);
    label:SetText(L:GetText("PasteDataHere"));
    label:SetSize(300, 16);
    label:SetPosition(10, 45);
    
    local textBox = Turbine.UI.Lotro.TextBox();
    self.textBox = textBox;
    textBox:SetParent(self);
    textBox:SetPosition(10, 61);
    textBox:SetSize(300, 20);
    textBox.TextChanged = function()
        self.object:Import(self.textBox:GetText());
        self.textBox.TextChanged = nil;
        self:Close();
    end
    
    L:SetContext(prevContext);
    self:Activate();
    self.textBox:Focus();
end
