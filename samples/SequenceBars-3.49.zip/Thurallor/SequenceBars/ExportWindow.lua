ExportWindow = class();

function ExportWindow:Constructor(title, exportData)
    local prevContext = L:SetContext("/ExportWindow");
    self.uncompressedData = PrettyPrint(exportData, "");
    self.compactData = Serialize(exportData);

    self.ok = L:GetText("OK");
    self.window = Alert(title, "", self.ok);
    self.window:SetSize(423, 300);
    self.window:SetMinimumSize(423, 300);
    CenterWindow(self.window);
    self.window:SetZOrder(2147483647);
    self.okButton = self.window.buttons[self.ok];
    self.okButton:SetEnabled(false);
    self.okButton.Click = function()
        self.window:Close();
    end
    
    self.compressed = Turbine.UI.Lotro.CheckBox();
    self.compressed:SetParent(self.window);
    self.compressed:SetSize(100, 20);
    self.compressed:SetFont(Turbine.UI.Lotro.Font.TrajanPro14);
    self.compressed:SetText(L:GetText("Compressed"));
    self.compressed:SetEnabled(false);
    self.compressed.CheckedChanged = function(control)
        if (control:IsChecked()) then
            self.window.label:SetText(self.compressedData);
        else
            if (#self.uncompressedData > 65535) then
                Puts(L:GetText("/ExportWindow/UncompressedDataTooBig"));
                control:SetChecked(true);
            else
                self.window.label:SetText(self.uncompressedData);
            end
        end
    end
    
    -- Compress the data in the next Update cycle.
    self.window:SetWantsUpdates(true);
    self.window.updateCount = 0;
    self.window.Update = function(w)
        w.updateCount = w.updateCount + 1;
        if (w.updateCount == 1) then
            w.label:SetText(L:GetText("/ExportWindow/Compressing"));
            Puts(L:GetText("/ExportWindow/Compressing"));
        elseif (w.updateCount == 3) then
            w.compressor = Thurallor.Utils.LibCompress();
        elseif (w.updateCount == 4) then
            self.compressedData = w.compressor:Compress(self.compactData);
        elseif (w.updateCount == 5) then
            w.label:SetText(w.label:GetText() .. "\n" .. L:GetText("/ExportWindow/Encoding"));
            Puts(L:GetText("/ExportWindow/Encoding"));
        elseif (w.updateCount == 7) then
            self.compressedData = Bin2Text(self.compressedData);
--local ratio = (1 - #self.compressedData / #self.uncompressedData) * 100;
--Puts("Compressed " .. tostring(#self.uncompressedData) .. " bytes by " .. string.format("%.0f%%", ratio) .. " to " .. tostring(#self.compressedData) .. " bytes.");
            if (#self.compressedData > 65535) then
                Puts(L:GetText("/ExportWindow/ExportFailedTooBig"));
                w:Close();
            end
        elseif (w.updateCount == 8) then
            self.compressed:SetChecked(true);
        elseif (w.updateCount == 9) then
            w.compressor = nil;
            self.compressed:SetEnabled(true);
            self.okButton:SetEnabled(true);
            self.window:Activate();
            self.window.label:SelectAll();
            self.window.label:Focus();
            w:SetWantsUpdates(false);
        end
    end

    AddCallback(self.window, "Closing", function()
        if (self.Closing) then
            self:Closing();
        end
    end);

    AddCallback(self.window, "SizeChanged", function()
        self:SizeChanged();
    end);
    self:SizeChanged();
    
    L:SetContext(prevContext);
end

function ExportWindow:SizeChanged()
    local left, top = self.window.buttons[self.ok]:GetPosition();
    self.compressed:SetPosition(left - 120, top);
end

function ExportWindow:Close()
    self.window:Close();
end
