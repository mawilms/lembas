Gears = class(Slot);

function Gears:Constructor(running)
    Turbine.UI.Control.Constructor(self);
    self:SetMouseVisible(false);
    self:SetSize(36, 36);
--    self:SetBlendMode(Turbine.UI.BlendMode.AlphaBlend);
    self:SetZOrder(1);
    self:SetMouseVisible(false);

    local outer = Turbine.UI.Control();
    outer:SetParent(self);
    outer:SetSize(32, 32);
    outer:SetPosition(3, 3);
    
    local inner = Turbine.UI.Control();
    inner:SetParent(outer);
    inner:SetSize(288, 32);
    inner:SetBackground(resources.Gears);
    inner:SetBlendMode(Turbine.UI.BlendMode.AlphaBlend);
    self.background = inner;
    
    local overlay = Turbine.UI.Control();
    overlay:SetParent(outer);
    overlay:SetBlendMode(Turbine.UI.BlendMode.Overlay);
    overlay:SetSize(32, 32);
    function overlay.MouseEnter()
        DoCallbacks(self, "MouseEnter");
    end
    function overlay.MouseLeave()
        DoCallbacks(self, "MouseLeave");
    end
    function overlay.MouseClick(sender, args)
        DoCallbacks(self, "MouseClick", args);
    end
    self.overlay = overlay;
    
    self:SetRunning(running);
end

function Gears:SetRunning(running)
    if (self.Log) then
        if (running) then
            DoCallbacks(self, "Log", {"starting continuous execution", "BAR"});
        else
            DoCallbacks(self, "Log", {"halting continuous execution", "BAR"});
        end
    end
    self.running = running;
    self:SetWantsUpdates(running);
    self:UpdateOverlay();
end

function Gears:SetParent(parent)
    if (self.parent ~= parent) then
        self.parent = parent;    
        Turbine.UI.Control.SetParent(self, parent);
    end
end

function Gears:SetDelaying(delaying)
    self.delaying = delaying;
end

function Gears:Update()
    if (not self.delaying) then
        local left = -self.background:GetLeft();
        left = (left + 32) % 288;
        self.background:SetLeft(-left);
        DoCallbacks(self, "Tick");
    end
end

function Gears:UpdateOverlay()
    if (self.mouseInside) then
        if (self.running) then
            self.overlay:SetBackground(resources.Icon.Pause);
        else
            self.overlay:SetBackground(resources.Icon.Play);
        end
    else
        self.overlay:SetBackground(nil);
    end
end

function Gears:MouseEnter()
    self.mouseInside = true;
    self:UpdateOverlay();
end

function Gears:MouseLeave()
    self.mouseInside = false;
    self:UpdateOverlay();
end

function Gears:MouseClick(args)
    if (args.Button == Turbine.UI.MouseButton.Left) then
        self:SetRunning(not self.running);
        if (self.running) then
            DoCallbacks(self, "PlayPressed");
        else
            DoCallbacks(self, "PausePressed");
        end
    end
end
